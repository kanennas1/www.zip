
var tyx=false;

window.addEventListener("DOMContentLoaded", () => {
 // (A) PLAYER INIT
 // (A1) PLAYLIST - CHANGE TO YOUR OWN!

 let playlist = playlist1;


 // (A2) AUDIO PLAYER & GET HTML CONTROLS
 const audio = new Audio(),
 aPlay = document.getElementById("aPlay"),

 aPlayIco = document.getElementById("aPlayIco"),
 aPrevIco =  document.getElementById("aPrevIco"),

 aJuke = document.getElementById("aJuke"),
 aNow = document.getElementById("aNow"),
 aTime = document.getElementById("aTime"),
 aSeek = document.getElementById("aSeek"),
 aVolume = document.getElementById("aVolume"),

 aVolIco = document.getElementById("aVolIco"),
 aNextIco = document.getElementById("aNextIco"),

 aList = document.getElementById("aList");

 // (A3) BUILD PLAYLIST
 for (let i in playlist) {
 let row = document.createElement("p");
 row.className = "aRow";
 if((i % 2)==0){row.style.backgroundColor='#000000'}else{row.style.backgroundColor='#323232'} 
 row.innerHTML = playlist[i]["name"]; 
 row.addEventListener("click", () => audPlay(i));
 playlist[i]["row"] = row;
 aList.appendChild(row);
 }

 // (B) PLAY MECHANISM
 // (B1) FLAGS
 var audNow = 0, // current song
 audStart = false, // auto start next song

 // (B2) PLAY SELECTED SONG
 audPlay = (idx, nostart) => {
 audNow = idx;
 aList.scrollTo({top:  24 * idx, left: 0, behavior: "smooth"});
 audStart = nostart ? false : true;
 audio.src = encodeURI(playlist[idx]["src"]);
 for (let i in playlist) {
 if (i == idx) { playlist[i]["row"].classList.add("now");}
 else { playlist[i]["row"].classList.remove("now"); }
 }
 };

 // (B3) AUTO START WHEN SUFFICIENTLY BUFFERED
 audio.addEventListener("canplay", () => { if (audStart) {
 audio.play();
 audStart = false;
 }});

 // (B4) AUTOPLAY NEXT SONG IN THE PLAYLIST
 audio.addEventListener("ended", () => {
 audNow++;
 if(tyx){audNow = Math.round(playlist.length * Math.random());}
 if (audNow >= playlist.length) { audNow = 0; }
 audPlay(audNow);
 });

function playnext(){ 
 audNow++;
 if(tyx){audNow = Math.round(playlist.length * Math.random());}
 if (audNow >= playlist.length) { audNow = 0; }
 audPlay(audNow);
 }

function playprev(){ 
 audNow--;
 if(tyx){audNow = Math.round(playlist.length * Math.random());}
 if (audNow <0) { audNow =  playlist.length - 1; }
 audPlay(audNow);
 }

 // (B5) INIT SET FIRST SONG
 audPlay(0, true);

 // (CX) CLICK TO normal/Random
 aJuke.addEventListener("click", () => { alert(audio.src);
 if(tyx){ aJuke.innerHTML = "start" }else{ aJuke.innerHTML="shuffle" } 
 tyx = !tyx;
 });

 aList.addEventListener("contextmenu", () => {alert(audio.src)});

 // (C) PLAY/PAUSE BUTTON
 // (C1) AUTO SET PLAY/PAUSE TEXT
 audio.addEventListener("play", () => aPlayIco.innerHTML = "pause");
 audio.addEventListener("pause", () => aPlayIco.innerHTML = "play_arrow");

 // (C2) CLICK TO PLAY/PAUSE
 aPlay.addEventListener("click", () => {
 if (audio.paused) { audio.play(); }
 else { audio.pause(); } 
 });

 // (X) CLICK TO PLAY-PREV
 aPrevIco.addEventListener("click", () => {
 playprev();
 });

 aNextIco.addEventListener("click", () => {
 playnext();
 });

 // (D) TRACK PROGRESS
 // (D1) SUPPORT FUNCTION - FORMAT HH:MM:SS
 var timeString = secs => {
 // (D1-1) HOURS, MINUTES, SECONDS
 let ss = Math.floor(secs),
 hh = Math.floor(ss / 3600),
 mm = Math.floor((ss - (hh * 3600)) / 60);
 ss = ss - (hh * 3600) - (mm * 60);

 // (D1-2) RETURN FORMATTED TIME
 if (hh>0) { mm = mm<10 ? "0"+mm : mm; }
 ss = ss<10 ? "0"+ss : ss;
 return hh>0 ? `${hh}:${mm}:${ss}` : `${mm}:${ss}` ;
 };

 // (D2) INIT SET TRACK TIME
 audio.addEventListener("loadedmetadata", () => {
 aNow.innerHTML = timeString(0);
 if(audio.duration!=Infinity){aTime.innerHTML = timeString(audio.duration);}else{aTime.innerHTML = 'LIVE'}
 });

 // (D3) UPDATE TIME ON PLAYING
 audio.addEventListener("timeupdate", () => aNow.innerHTML = timeString(audio.currentTime));

 // (E) SEEK BAR
 audio.addEventListener("loadedmetadata", () => {
 // (E1) SET SEEK BAR MAX TIME
 aSeek.max = Math.floor(audio.duration);

 // (E2) USER CHANGE SEEK BAR TIME
 var aSeeking = false; // user is now changing time
 aSeek.addEventListener("input", () => aSeeking = true); // prevents clash with (e3)
 aSeek.addEventListener("change", () => {
 audio.currentTime = aSeek.value;
 if (!audio.paused) { audio.play(); }
 aSeeking = false;
 });

 // (E3) UPDATE SEEK BAR ON PLAYING
 audio.addEventListener("timeupdate", () => {
 if (!aSeeking) { aSeek.value = Math.floor(audio.currentTime); }
 });
 });

 // (F) VOLUME
 aVolIco.addEventListener("click", () => {
 audio.volume = audio.volume==0 ? 1 : 0 ;
 aVolume.value = audio.volume;
 aVolIco.innerHTML = (aVolume.value==0 ? "volume_mute" : "volume_up"); 
 });
 aVolume.addEventListener("change", () => {
 audio.volume = aVolume.value;
 aVolIco.innerHTML = (aVolume.value==0 ? "volume_mute" : "volume_up");
 });

 // (G) ENABLE/DISABLE CONTROLS
 audio.addEventListener("canplay", () => {
 aPlay.disabled = false;
 aVolume.disabled = false;
 aSeek.disabled = false;
 });
 audio.addEventListener("waiting", () => {
 aPlay.disabled = true;
 aVolume.disabled = true;
 aSeek.disabled = true;
 });
});
