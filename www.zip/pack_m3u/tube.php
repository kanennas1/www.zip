<?php
// index.php - merged extractor + UI
// Modified: client-side drop handling normalizes music.youtube -> www.youtube

// Features
define("ALLOW_SOURCE", true);
define("ALLOW_API", true);
define("ALLOW_TITLE", false); // not used; client-side noembed is used for titles

// Allow basic CORS for browser clients (safe when UI and API are same origin)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
 exit(0);
}

if (ALLOW_SOURCE && isset($_GET['source'])) {
 highlight_file(__FILE__);
 exit(0);
}

$isApi = ALLOW_API && !empty($_GET['API']) && $_GET['API'] === '1';
$err = null;
$url = null;
$urls = null;

// URL validation and Link extraction
if (!empty($_GET['url'])) {
 $url = $_GET['url'];
 if (isURL($url)) {
 $content = HTTP($url);
 if ($content !== null) {
 $urls = findYoutube($content, $url);
 if (!is_array($urls) || count($urls) === 0) {
 $err = 'Unable to extract youtube links from the given page';
 }
 } else {
 $err = 'Unable to make a HTTP request to the given site';
 }
 } else {
 $err = 'The submitted value is not an URL';
 }
}

// Helpers

function isURL($x) {
 return !!filter_var($x, FILTER_VALIDATE_URL) && !!preg_match('#https?://#i', strtolower($x));
}

function HTTP($x) {
 if (!isURL($x)) return null;
 if (function_exists('curl_version')) {
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $x);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_TIMEOUT, 15);
 curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; Extractor/1.0)');
 $res = curl_exec($ch);
 $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
 curl_close($ch);
 if ($res !== false && $httpcode >= 200 && $httpcode < 400) return $res;
 }
 if (ini_get('allow_url_fopen')) {
 $context = stream_context_create([
 'http' => ['timeout' => 15, 'header' => "User-Agent: Extractor/1.0\r\n"]
 ]);
 $res = @file_get_contents($x, false, $context);
 if ($res !== false) return $res;
 }
 return null;
}

function getMatches($content, $regex) {
 preg_match_all($regex, $content, $matches);
 if ($matches && count($matches) > 1) {
 return array_unique($matches[1]);
 }
 return array();
}

function decodeId($id) {
 if (is_string($id) && strlen($id) === 11) {
 return base64_decode(str_replace('-', '+', str_replace('_', '/', $id)) . '=');
 }
 return null;
}
function encodeId($id) {
 if (is_string($id) && strlen($id) === 8) {
 return str_replace('/', '_', str_replace('+', '-', substr(base64_encode($id), 0, 11)));
 }
 return null;
}

function findYoutube($html, $sourceUrl = '') {
 $URLs = [];

 // common watch links
 $matches = getMatches($html, '#watch/?\?v=([\w\-]{11})#i');
 $matches = array_merge($matches, getMatches($html, '#https?://youtu\.be/([\w\-]{11})#i'));
 $matches = array_merge($matches, getMatches($html, '#data-video-id=["\']?([\w\-]{11})#i'));
 $matches = array_unique($matches);

 foreach ($matches as $id) {
 $idEnc = encodeId(decodeId($id)) ?: $id;
 $URLs[] = "https://www.youtube.com/watch?v=$idEnc";
 }

 // also scan for watch occurrences (playlist page fragments, JSON)
 $playlistMatches = getMatches($html, '#/watch\?v=([\w\-]{11})#i');
 foreach ($playlistMatches as $id) {
 $idEnc = encodeId(decodeId($id)) ?: $id;
 $url = "https://www.youtube.com/watch?v=$idEnc";
 if (!in_array($url, $URLs)) $URLs[] = $url;
 }

 // If no matches but source looks like a playlist, try to extract videoId fields from JSON blobs
 if (empty($URLs) && (stripos($sourceUrl, 'youtube.com/playlist') !== false || stripos($sourceUrl, 'list=') !== false)) {
 preg_match_all('/"videoId"\s*:\s*"([A-Za-z0-9_-]{11})"/i', $html, $jm);
 if (!empty($jm[1])) {
 foreach (array_unique($jm[1]) as $id) {
 $url = "https://www.youtube.com/watch?v=$id";
 if (!in_array($url, $URLs)) $URLs[] = $url;
 }
 }
 }

 $URLs = array_values(array_unique($URLs));
 return $URLs;
}

function getTitle($url) {
 $content = HTTP($url);
 if ($content) {
 if (preg_match('#<title>([^<]*)</title>#i', $content, $matches)) {
 return trim($matches[1]);
 }
 }
 return $url;
}

// API mode: return plain text URLs, one per line
if (!$err && is_array($urls) && $isApi) {
 header('Content-Type: text/plain; charset=utf-8');
 echo implode("\r\n", $urls);
 exit(0);
}

// Serve UI below (normal browser page)
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="utf-8" />
  <title>Δημιουργία Playlist M3U</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    :root {
      --bg: #333;
      --panel: rgba(34,34,34,0.6);
      --muted: #99c;
      --accent1: #3aa0ff;
      --accent2: #0066cc;
      --bg-img: radial-gradient(circle at center,#000 0%,#006400 40%,#000 100%);
      --bg-opacity: .4;
      --pad: 10px;
    }

    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      background: #111;
      color: #ddd;
      font: 13px/1.4 system-ui, sans-serif;
      box-sizing: border-box;
    }

    body {
      padding: var(--pad);
    }

    .frame {
      position: relative;
      width: auto; height: 600px;
      min-width:360px;
      max-height: calc(100vh - 20px);
      margin: auto;
      border-radius: 12px;
      overflow: hidden;
      background: var(--bg);
      box-shadow: 0 10px 30px rgba(0,0,0,.6),
                  inset 0 1px 0 rgba(255,255,255,.02);
    }

    .frame::before {
      content: "";
      position: absolute;
      inset: 0;
      background-image: var(--bg-img);
      background-repeat: repeat;
      background-position: top;
      background-size: 100% 50%;
      opacity: var(--bg-opacity);
      filter: blur(.6px) saturate(.95);
      pointer-events: none;
    }

    .page {
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 10px;
      height: 100%;
      padding: var(--pad);
      box-sizing: border-box;
      z-index: 1;
    }

    .column {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
    }

    @media (min-width: 550px) and (max-height: 400px) {
      .page {
        flex-direction: row;
      }

      .column-left,
      .column-right {
        flex: 1;
        display: flex;
        flex-direction: column;
      }

      .column-right textarea {
        flex: 1;
        min-height: 0;
      }

      .controls {
        margin-top: var(--pad);
      }
    }

    #dropbox {
      border: 1px solid rgba(255,255,255,.06);
      padding: 20px;
      background: var(--panel);
      border-radius: 8px;
      color: #eee;
      font: 13px monospace;
      backdrop-filter: blur(2px) saturate(.95);
      background-image:
        radial-gradient(circle at center, rgba(0,100,0,0.6) 0%, transparent 70%),
        radial-gradient(circle at center, rgba(0,200,100,0.4) 0%, transparent 60%);
      background-repeat: no-repeat;
      background-position: center;
      background-size: 200px 200px, 150px 150px;
      box-shadow: 0 4px 12px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.03);
      flex: 1;
      min-height: 0;
      overflow: auto;
    }

    #dropbox h3 {
      margin: 0 0 8px;
    }

    #output {
      width: 100%;
      flex: 1;
      min-height: 0;
      white-space: pre-wrap;
      padding: 10px;
      font: 13px monospace;
      color: #eee;
      background: var(--panel);
      border: 1px solid rgba(255,255,255,.06);
      border-radius: 8px;
      resize: none;
      box-sizing: border-box;
      backdrop-filter: blur(2px) saturate(.95);
      overflow: auto;
      background-image:
        radial-gradient(circle at center, rgba(0,100,0,0.6) 0%, transparent 70%),
        radial-gradient(circle at center, rgba(0,200,100,0.4) 0%, transparent 60%);
      background-repeat: no-repeat;
      background-position: center;
      background-size: 200px 200px, 150px 150px;
    }

    .controls {
      display: flex;
      gap: 8px;
      margin-top: 8px;
    }

    .btn {
      flex: 1;
      padding: 5px 10px;
      border-radius: 5px;
      border: 1px solid rgba(255,255,255,.08);
      background: linear-gradient(145deg, rgba(255,255,255,.05), rgba(0,0,0,.2));
      color: #eef;
      font-weight: 600;
      font-size: 13px;
      cursor: pointer;
      transition: .3s;
      box-shadow: 0 4px 12px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.03);
      backdrop-filter: blur(3px) saturate(1.2);
      max-width: 150px;
    }

    .btn.primary {
      background: linear-gradient(180deg, var(--accent1), var(--accent2));
      border-color: rgba(255,255,255,.1);
      color: #fff;
    }

    .btn.secondary {
      background: linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
      color: var(--muted);
      border-color: rgba(170,200,255,.1);
    }

    .btn:hover {
      background: linear-gradient(145deg, rgba(255,255,255,.08), rgba(0,0,0,.3));
      transform: translateY(-1px);
    }

    .btn:active {
      transform: translateY(1px);
      box-shadow: 0 2px 6px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.02);
    }

    .btn:focus,
    textarea:focus {
      outline: 2px solid rgba(58,160,255,.25);
      outline-offset: 0;
    }

    .small {
      font-size: 90%;
      color: var(--muted);
    }
  </style>
</head>
<body>
  <div class="frame">
    <div class="page">
      <div class="column column-left">
        <div id="dropbox">
          <h3>Ρίξε εδώ YouTube URLs / Playlists</h3>
          <div class="small">Το πρόγραμμα εξάγει YouTube URLs server-side και χρησιμοποιεί noembed client-side για τίτλους όταν δημιουργείτε το M3U.</div>
        </div>
      </div>

      <div class="column column-right">
        <textarea id="output" readonly></textarea>
        <div class="controls">
          <button id="btnGen" class="btn primary">Generate M3U</button>
          <button id="btnExp" class="btn secondary">Export M3U</button>
        </div>
      </div>
    </div>
  </div>
 <script>
// FULL modified JavaScript (replace your existing <script> contents with this)
const API = './tube.php'; // this same file (change name if you saved differently)
const NOEMBED_BASE = 'https://noembed.com/embed?url=';
const dropbox = document.getElementById('dropbox');
const output = document.getElementById('output');
const btnGen = document.getElementById('btnGen');
const btnExp = document.getElementById('btnExp');

let playlist = [];

function normalizeUrl(u) { return u.trim(); }

function parseExtractorText(txt) {
  return txt.split(/\r?\n/).map(s => s.trim()).filter(Boolean).map(u => ({ title: null, url: u }));
}

async function fetchExtractor(url) {
  const params = new URLSearchParams();
  params.set('API', '1');
  params.set('url', url);
  const res = await fetch(API + '?' + params.toString());
  if (!res.ok) throw new Error('Extractor request failed: ' + res.status);
  const txt = await res.text();
  return parseExtractorText(txt);
}

async function fetchTitleNoembed(videoUrl) {
  try {
    const res = await fetch(NOEMBED_BASE + encodeURIComponent(videoUrl));
    if (!res.ok) throw new Error('noembed failed');
    const json = await res.json();
    return json && json.title ? json.title : videoUrl;
  } catch {
    return videoUrl;
  }
}

// dedupe helper
function dedupePlaylist(arr) {
  const seen = new Set();
  const out = [];
  for (const it of arr) {
    const u = it.url;
    if (!seen.has(u)) {
      seen.add(u);
      out.push(it);
    }
  }
  return out;
}

// Helper: parse .url file content and return the URL or null
function parseWindowsUrlFileText(text) {
  // INI-like format; look for a line starting with URL=
  const m = text.match(/^\s*URL\s*=\s*(.+)\s*$/im);
  if (m && m[1]) return m[1].trim();
  return null;
}

// Helper: read a File object as text and attempt to extract URL (for .url files)
function extractUrlFromFile(file) {
  return new Promise((resolve) => {
    const name = file.name || '';
    if (!/\.url$/i.test(name)) {
      resolve(null);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result;
      const url = parseWindowsUrlFileText(text);
      resolve(url);
    };
    reader.onerror = () => resolve(null);
    reader.readAsText(file);
  });
}

function fixYouTubeMusicUrl(input) {
  let s = input.trim();

  // If input is like "music.youtube.com/..." without scheme, add https://
  if (/^music\.youtube(\.com)?(\/|$)/i.test(s)) {
    s = 'https://' + s;
  }

  // Replace any scheme+music.youtube or scheme+music.youtube.com with https://www.youtube.com
  s = s.replace(/^https?:\/\/music\.youtube(\.com)?/i, 'https://www.youtube.com');

  // Also handle cases like: https://music.youtube.com -> https://www.youtube.com
  s = s.replace(/^https?:\/\/music\.youtube\.com/i, 'https://www.youtube.com');

  // If still missing scheme but starts with www.youtube, add https://
  if (/^www\.youtube(\.com)?(\/|$)/i.test(s)) {
    s = s.replace(/^www\./i, 'https://');
  }

  // If input looks like youtu.be short link, leave as is; if it's a plain URL with no scheme but contains youtube, add https
  if (!/^https?:\/\//i.test(s) && /youtube|youtu\.be/i.test(s)) {
    s = 'https://' + s;
  }

  return s;
}

// Unified drop handler supporting files and plain text
dropbox.addEventListener('dragover', e => { e.preventDefault(); dropbox.style.background = '#e8ffe8'; });
dropbox.addEventListener('dragleave', () => { dropbox.style.background = ''; });

dropbox.addEventListener('drop', async e => {
  e.preventDefault();
  dropbox.style.background = '';

  const dataCandidates = [];

  // 1) If files were dropped, try to extract URLs from .url files
  if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
    const files = Array.from(e.dataTransfer.files).slice(0, 10); // limit to avoid overload
    for (const f of files) {
      try {
        const extracted = await extractUrlFromFile(f);
        if (extracted) dataCandidates.push(extracted);
      } catch (err) {
        console.warn('Error reading file', f.name, err);
      }
    }
  }

  // 2) Also accept plain text (e.g., dragging URL text)
  let dataRaw = '';
  try {
    dataRaw = (e.dataTransfer && e.dataTransfer.getData) ? e.dataTransfer.getData('text/plain').trim() : '';
  } catch {
    dataRaw = '';
  }
  if (dataRaw) dataCandidates.push(dataRaw);

  if (dataCandidates.length === 0) {
    output.value += 'No usable URL found in drop\n\n';
    return;
  }

  // Process each found candidate (most likely just one). Limit total processed per drop.
  const MAX_PER_DROP = 20;
  for (let idx = 0; idx < Math.min(dataCandidates.length, MAX_PER_DROP); idx++) {
    const raw = dataCandidates[idx];
    const data = fixYouTubeMusicUrl(raw);
    output.value += `Processing: ${data}\n`;
    try {
      const items = await fetchExtractor(data);
      if (!items || items.length === 0) {
        playlist.push({ title: null, url: normalizeUrl(data) });
        output.value += `Added single URL: ${data}\n\n`;
      } else {
        for (const it of items) {
          playlist.push({ title: null, url: it.url });
          output.value += `${it.url}\n`;
        }
        output.value += `Added ${items.length} items from extractor\n\n`;
      }
    } catch (err) {
      console.error(err);
      output.value += `Error processing: ${data}\n\n`;
    }
  }
});

// Generate M3U: dedupe first, then fetch titles via noembed in small batches to avoid rate limits
btnGen.addEventListener('click', async () => {
  if (playlist.length === 0) { output.value = 'Playlist is empty'; return; }

  output.value = 'Preparing playlist and deduplicating...\n\n';
  playlist = dedupePlaylist(playlist);

  // batch size for concurrent noembed requests
  const BATCH = 6;
  const itemsWithTitles = [];

  for (let i = 0; i < playlist.length; i += BATCH) {
    const batch = playlist.slice(i, i + BATCH);
    output.value = `Fetching titles ${i + 1}-${Math.min(i + BATCH, playlist.length)} of ${playlist.length}...\n`;
    const promises = batch.map(it => fetchTitleNoembed(it.url).then(title => ({ title, url: it.url })).catch(() => ({ title: it.url, url: it.url })));
    const results = await Promise.all(promises);
    results.forEach(r => itemsWithTitles.push(r));
    // small delay to be polite (helps avoid some rate limits)
    await new Promise(res => setTimeout(res, 150));
  }

  // build M3U
  let m3u = '#EXTM3U\n';
  for (const it of itemsWithTitles) {
    const safeTitle = (it.title || it.url).replace(/\r?\n/g, ' ').replace(/,/g, ' ');
    m3u += `#EXTINF:-1,${safeTitle}\n${it.url}\n`;
  }

  output.value = m3u;
});

btnExp.addEventListener('click', () => {
  if (!output.value) { output.value = 'No M3U content to export'; return; }
  const blob = new Blob([output.value], { type: 'audio/x-mpegurl' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'playlist.m3u';
  a.click();
  URL.revokeObjectURL(a.href);
});
 </script>
</body>
</html>
