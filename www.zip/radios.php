<?php
// radios.php enhanced debug version
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

$LOGFILE = __DIR__ . '/radios_debug.log';
file_put_contents($LOGFILE, "[".date('c')."] START\n", FILE_APPEND);

// settings
$OWNER = 'junguler';
$REPO = 'm3u-radio-music-playlists';
$BRANCH = 'main';
$FOLDER = '+checked+';
$OUT_M3U = __DIR__ . '/combined.m3u';
$OUT_JSON = __DIR__ . '/stations.json';
$USER_AGENT = 'PHP radios.php debug';
$GITHUB_TOKEN = ''; // αν έχεις token βάλε το εδώ
$TIMEOUT = 20;

function logmsg($s) {
    global $LOGFILE;
    $line = "[".date('c')."] " . $s . "\n";
    echo $line;
    file_put_contents($LOGFILE, $line, FILE_APPEND);
}

logmsg("PHP allow_url_fopen = " . (ini_get('allow_url_fopen') ? 'On' : 'Off'));
if (!ini_get('allow_url_fopen')) {
    logmsg("Warning: allow_url_fopen is Off. Enable it in php.ini or use cURL implementation.");
}

function http_get($url, $userAgent, $token = '', $timeout = 20) {
    $headers = "User-Agent: {$userAgent}\r\nAccept: application/vnd.github.v3+json\r\n";
    if (!empty($token)) $headers .= "Authorization: token {$token}\r\n";
    $opts = ["http" => ["method"=>"GET","header"=>$headers,"timeout"=>$timeout]];
    $ctx = stream_context_create($opts);
    $content = @file_get_contents($url, false, $ctx);
    return $content === false ? null : $content;
}

function github_api_list_recursive($owner, $repo, $folder, $branch, $userAgent, $token = '', $timeout = 20) {
    $base = "https://api.github.com/repos/{$owner}/{$repo}/contents/";
    $results = [];
    $stack = [$folder];
    while (!empty($stack)) {
        $cur = array_pop($stack);
        $api = $base . rawurlencode($cur) . "?ref={$branch}";
        $json = http_get($api, $userAgent, $token, $timeout);
        if ($json === null) {
            file_put_contents($GLOBALS['LOGFILE'], "[".date('c')."] Failed API call for {$cur}\n", FILE_APPEND);
            continue;
        }
        $data = json_decode($json, true);
        if (!is_array($data)) continue;
        foreach ($data as $item) {
            if (!isset($item['type'])) continue;
            if ($item['type'] === 'file') $results[] = $item;
            elseif ($item['type'] === 'dir') $stack[] = $item['path'];
        }
        usleep(100000);
    }
    return $results;
}

function parse_playlist_text($text) {
    $lines = preg_split("/\r\n|\n|\r/", $text);
    $lastTitle = '';
    $out = [];
    foreach ($lines as $raw) {
        $line = trim($raw);
        if ($line === '') continue;
        if (preg_match('/^#EXTINF:/i', $line)) {
            $parts = explode(',', $line, 2);
            $lastTitle = isset($parts[1]) ? trim($parts[1]) : '';
            continue;
        }
        if (strpos($line, '#') === 0) continue;
        if (preg_match('/^[a-z0-9.+-]+:\/\//i', $line) || preg_match('/^[a-z0-9.+-]+:/i', $line)) {
            $out[] = ['url'=>$line,'title'=>$lastTitle];
            $lastTitle = '';
        }
    }
    return $out;
}

function normalize_url($u) {
    $u = trim($u);
    if ($u === '') return '';
    $u = preg_replace('/#.*$/','',$u);
    $u = preg_replace('/\?.*$/','',$u);
    if (!preg_match('/^[a-z]+:\/\//i',$u)) $u = 'http://' . $u;
    return $u;
}

// run
logmsg("Listing files in GitHub folder: {$FOLDER}");
$list = github_api_list_recursive($OWNER,$REPO,$FOLDER,$BRANCH,$USER_AGENT,$GITHUB_TOKEN,$TIMEOUT);
if ($list === null) {
    logmsg("Failed to list GitHub folder.");
    exit;
}
logmsg("Total items found: " . count($list));
if (count($list) > 0) {
    logmsg("Sample item: " . json_encode($list[0]));
}

// filter playlist files
$playlist_items = [];
foreach ($list as $item) {
    if (!isset($item['path'])) continue;
    if (preg_match('/\.(m3u|m3u8|pls|txt|asx)$/i', $item['path'])) $playlist_items[] = $item;
}
logmsg("Playlist files to download: " . count($playlist_items));

$rawEntries = [];
foreach ($playlist_items as $item) {
    $path = $item['path'];
    logmsg("Downloading: {$path}");
    $raw = null;
    if (!empty($item['download_url'])) {
        $raw = http_get($item['download_url'],$USER_AGENT,$GITHUB_TOKEN,$TIMEOUT);
    } else {
        $rawUrl = "https://raw.githubusercontent.com/{$OWNER}/{$REPO}/{$BRANCH}/" . rawurlencode($path);
        $raw = http_get($rawUrl,$USER_AGENT,$GITHUB_TOKEN,$TIMEOUT);
    }
    if ($raw === null) {
        logmsg("Failed to fetch: {$path}");
        usleep(150000);
        continue;
    }
    $entries = parse_playlist_text($raw);
    foreach ($entries as $e) $rawEntries[] = ['url'=>$e['url'],'title'=>$e['title'],'source'=>$path];
    logmsg("Parsed {$path} -> " . count($entries) . " entries");
    usleep(150000);
}

logmsg("Total raw entries: " . count($rawEntries));

// debug dump first 5 raw entries
if (count($rawEntries) > 0) {
    logmsg("Sample raw entries:");
    $sample = array_slice($rawEntries,0,5);
    foreach ($sample as $s) logmsg(json_encode($s));
}

// dedupe
$map = [];
foreach ($rawEntries as $it) {
    $key = normalize_url($it['url']);
    if ($key === '') continue;
    if (!isset($map[$key])) $map[$key] = ['url'=>$key,'title'=>$it['title'],'sources'=>[$it['source']]];
    else {
        if ($map[$key]['title']==='' && $it['title']!=='') $map[$key]['title'] = $it['title'];
        if (!in_array($it['source'],$map[$key]['sources'])) $map[$key]['sources'][] = $it['source'];
    }
}

$stations = array_values($map);
logmsg("Unique stations after dedupe: " . count($stations));

// if empty, write fallback sample to verify write permissions
if (count($stations) === 0) {
    logmsg("No stations found after dedupe. Writing fallback sample to test write.");
    $sample = [
        ['url'=>'http://stream.example.com/stream','title'=>'Sample Radio 1','sources'=>['fallback']],
        ['url'=>'http://stream2.example.com/stream','title'=>'Sample Radio 2','sources'=>['fallback']]
    ];
    file_put_contents($OUT_JSON, json_encode($sample, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    $lines = ["#EXTM3U"];
    foreach ($sample as $s) {
        $lines[] = "#EXTINF:-1," . str_replace(["\r","\n"],' ',$s['title']);
        $lines[] = $s['url'];
    }
    file_put_contents($OUT_M3U, implode("\n",$lines));
    logmsg("Wrote fallback files to test write: {$OUT_M3U}, {$OUT_JSON}");
    logmsg("Check file permissions and re-run after fixing source issues.");
    exit;
}

// write real outputs
$lines = ["#EXTM3U"];
foreach ($stations as $s) {
    $title = $s['title'] !== '' ? $s['title'] : $s['url'];
    $lines[] = "#EXTINF:-1," . str_replace(["\r","\n"],' ',$title);
    $lines[] = $s['url'];
}
file_put_contents($OUT_M3U, implode("\n",$lines));
file_put_contents($OUT_JSON, json_encode($stations, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
logmsg("Wrote {$OUT_M3U} and {$OUT_JSON}");
logmsg("Finished.");
?>
