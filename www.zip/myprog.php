<?php
declare(strict_types=1);

// ---------- CONFIG ----------
const TIMEZONE = 'Europe/Athens';
date_default_timezone_set(TIMEZONE);

// ---------- HELPERS ----------
function serve_maps_and_exit(): void {
    readfile("prog/maps.html");
    exit;
}

function fetchContent(string $url): string {
    $content = @file_get_contents($url);
    return $content !== false ? $content : '';
}

// ---------- ROUTES ----------
if (isset($_GET['sky'])) {
    $html = fetchContent($_GET['sky']); // $sky είναι URL
    if (!$html) exit;

    $needle = "livee.m3u8?a=";
    $start = strpos($html, $needle);

    if ($start !== false) {
        $from = substr($html, $start);

        // Κόβει στο τέλος του URL (μέχρι quote/whitespace)
        $end = strcspn($from, "\"' \r\n\t");
        $urlPart = substr($from, 0, $end); // livee.m3u8?a=XXXX

        // Πάρε το query μετά από "a="
        $aPos = strpos($urlPart, "a=");
        if ($aPos !== false) {
            $query = substr($urlPart, $aPos + 2); // μετά το a=
            echo "https://hd-auth.skylinewebcams.com/live.m3u8?a=" . $query;
            exit;
        }
    }
    exit;
}

if (isset($_GET['gic'])) {
    $url = 'https://www.ipcamlive.com/' . $_GET['gic'];
    $content = fetchContent($url);
    if (!$content) exit;

    $start = strpos($content, "https://s");
    $end = strpos($content, "snapshot", $start);
    if ($start !== false && $end !== false) {
        echo substr($content, $start, $end - $start) . "stream.m3u8";
    }
    exit;
}

if (isset($_GET['time'])) {
    session_start();
    $maxCalls = 5;
    $window = 60;
    $now = time();

    if (!isset($_SESSION['time_api']['start']) || ($now - $_SESSION['time_api']['start'] > $window)) {
        $_SESSION['time_api'] = ['start' => $now, 'count' => 0];
    }

    $_SESSION['time_api']['count']++;
    if ($_SESSION['time_api']['count'] > $maxCalls) {
        $retryAfter = $window - ($now - $_SESSION['time_api']['start']);
        header('HTTP/1.1 429 Too Many Requests');
        header('Retry-After: ' . $retryAfter);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'error' => 'Rate limit exceeded',
            'retry_after' => $retryAfter
        ]);
        exit;
    }

    header('Cache-Control: private, max-age=2');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'serverTimeMs' => round(microtime(true) * 1000),
        'timezone' => TIMEZONE
    ]);
    exit;
}

if (isset($_GET['katalogos'])) {
    function myScanDir(string $dir, int &$totalSize, array &$outArray, string $baseRealPath, int $baseDirLen): void {
        $realDir = realpath($dir);
        if ($realDir === false || strpos($realDir, $baseRealPath) !== 0) {
            throw new RuntimeException("Directory traversal attempt or unreadable path: $dir");
        }

        $entries = scandir($dir);
        if ($entries === false) {
            throw new RuntimeException("Unable to open directory: $dir");
        }

        $dirs = [];
        $files = [];
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $full = $dir . DIRECTORY_SEPARATOR . $entry;
            if (is_dir($full)) {
                $dirs[] = $full;
            } elseif (is_file($full)) {
                $files[] = $full;
            }
        }

        natsort($dirs);
        natsort($files);

        foreach ($dirs as $subdir) {
            myScanDir($subdir, $totalSize, $outArray, $baseRealPath, $baseDirLen);
        }

        $outArray[] = ['type' => 'sep'];

        foreach ($files as $file) {
            if (basename($file) === 'off') continue;
            $rel = substr($file, $baseDirLen);
            $path = ltrim($rel, DIRECTORY_SEPARATOR);
            $size = filesize($file) ?: 0;
            $totalSize += $size;
            $modTime = date("d/m/y H:i", filemtime($file));
            $segments = explode(DIRECTORY_SEPARATOR, $path);
            $encoded = implode('/', array_map('rawurlencode', $segments));
            $outArray[] = [
                'type' => 'file',
                'path' => $path,
                'encoded' => $encoded,
                'size' => $size,
                'modTime' => $modTime
            ];
        }
    }

    $root = __DIR__;
    $totalSize = 0;
    $fileList = [];
    $baseRealPath = realpath($root);
    $baseDirLen = strlen((string)$baseRealPath) + 1;

    try {
        myScanDir($root, $totalSize, $fileList, (string)$baseRealPath, $baseDirLen);
    } catch (Throwable $e) {
        http_response_code(500);
        echo "<h1>Σφάλμα:</h1><p>" . htmlspecialchars($e->getMessage()) . "</p>";
        exit;
    }

    ?>
    <!DOCTYPE html>
    <html lang="el">
    <head>
        <meta charset="UTF-8">
        <title>INDEX of <?= htmlspecialchars($root, ENT_QUOTES) ?>/</title>
        <style>
            body { font-family: Helvetica, sans-serif; margin:5px; background:#eee; max-height:calc(100vh - 50px); overflow:auto;}
            a { color:#003300; text-decoration:none; }
            a:hover { color:blue; }
            table { width:100%; border-collapse:collapse; font-size:12px; }
            th, td { border:1px solid #ddd; padding:4px; }
            th { background:#e0ffff; }
            tr:nth-child(even) { background:#f9f9f9; }
            tr:hover { background:#ffffed; }
            .directory td { font-weight:bold; color:darkblue; }
            .separator td { padding:0; border:none; background:#ccc; height:6px; }
            #openCatalog {
                font-size:13px;
                color:darkred;
                font-weight:700;
                border:1px solid blue;
                padding:5px;
                border-radius:5px;
                box-shadow:2px 2px 5px rgba(0,0,0,0.5);
                cursor:pointer;
                display:inline-block;
            }
        </style>
    </head>
    <body>
        <button id="myAudio">close = (ALT-S)</button><br><br>
        <div style="margin-bottom:15px;">
            <span id="openCatalog">open this CATALOG in a new window</span>
        </div>
        <p>
            Root: <em><?= htmlspecialchars($root, ENT_QUOTES) ?>/</em><br>
            Files: <?= count($fileList) ?> | Total size: <?= number_format($totalSize) ?> bytes
        </p>
        <table>
            <thead>
                <tr>
                    <th>Path / filename</th>
                    <th style="text-align:center">Size (bytes)</th>
                    <th style="text-align:center">Last Modified</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($fileList as $row): ?>
                    <?php if ($row['type'] === 'sep'): ?>
                        <tr class="separator"><td colspan="3"></td></tr>
                    <?php else: ?>
                        <tr class="directory">
                            <td><a href="<?= htmlspecialchars($row['encoded'], ENT_QUOTES) ?>" target="_blank"><?= htmlspecialchars($row['path'], ENT_QUOTES) ?></a></td>
                            <td style="text-align:right"><?= number_format($row['size']) ?></td>
                            <td style="text-align:center"><?= $row['modTime'] ?></td>
                        </tr>
                    <?php endif ?>
                <?php endforeach ?>
            </tbody>
        </table>
        <script>
            document.getElementById('openCatalog')?.addEventListener('click', () => {
                const catalogWin = window.open('?katalogos=1&noaudio=1', '_blank');
                catalogWin?.addEventListener('load', () => {
                    catalogWin.document.getElementById('myAudio')?.remove();
                });
                document.getElementById('myAudio')?.remove();
                document.body.innerHTML = 'Running in a new window you can close this';
            });
        </script>
    </body>
    </html>
    <?php
    exit;
}

// ---------- DEFAULT ----------
serve_maps_and_exit();
