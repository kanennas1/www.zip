<?php
// whoami.php
// Self-contained script για εμφάνιση δημόσιας IP του επισκέπτη,
// λειτουργεί σωστά πίσω από proxy / CDN (Cloudflare κ.ά.).

declare(strict_types=1);

// --- Security / privacy headers (no caching, limited CORS) ---
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, private, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'");
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

// Προαιρετικά: επιτρέπουμε CORS μόνο στο ίδιο origin.
// Αν χρειάζεται να το αφήσεις ανοιχτό για συγκεκριμένα origins, προσαρμόζεις τον έλεγχο.
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$hostWithScheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
if ($origin === $hostWithScheme) {
    header("Access-Control-Allow-Origin: $origin");
}
header('Vary: Origin');

// --- Utility functions ---
function is_public_ip(string $ip): bool {
    // Επιστρέφει true αν το $ip είναι έγκυρο και δημόσιο (όχι private/reserved/loopback)
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;
    // FILTER_FLAG_NO_PRIV_RANGE and FILTER_FLAG_NO_RES_RANGE => only public
    return (bool)filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}

function pick_client_ip(): string {
    // Προτεραιότητα headers που χρησιμοποιούνται από CDN/proxies:
    // 1. CF-Connecting-IP (Cloudflare)
    // 2. True-Client-IP (κάποια proxies)
    // 3. X-Forwarded-For (λίστα, παίρνουμε το πρώτο public entry από αριστερά)
    // 4. REMOTE_ADDR ως fallback

    // 1. Cloudflare
    $cf = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? null;
    if ($cf && is_public_ip($cf)) return $cf;

    // 2. True-Client-IP
    $trueClient = $_SERVER['HTTP_TRUE_CLIENT_IP'] ?? null;
    if ($trueClient && is_public_ip($trueClient)) return $trueClient;

    // 3. X-Forwarded-For (λίστα)
    $xff = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
    if ($xff !== '') {
        // X-Forwarded-For format: client, proxy1, proxy2
        $parts = array_map('trim', explode(',', $xff));
        foreach ($parts as $p) {
            if ($p === '') continue;
            // Μερικά proxies βάζουν επίσης ports, αποκόπτουμε αν υπάρχουν
            $pClean = preg_replace('/:\d+$/', '', $p);
            if (is_public_ip($pClean)) {
                return $pClean;
            }
        }
    }

    // 4. other common headers
    $altHeaders = [
        'HTTP_X_REAL_IP' => $_SERVER['HTTP_X_REAL_IP'] ?? null,
        'HTTP_CLIENT_IP' => $_SERVER['HTTP_CLIENT_IP'] ?? null,
    ];
    foreach ($altHeaders as $h) {
        if ($h && is_public_ip($h)) return $h;
    }

    // 5. fallback to REMOTE_ADDR (may be proxy IP)
    $remote = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    return $remote;
}

// --- Determine IP ---
$clientIp = pick_client_ip();

// --- Render page (no logging, no storage) ---
?>
<!doctype html>
<html lang="el">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Η δημόσια IP σου</title>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,'Helvetica Neue',Arial;padding:28px;background:#fff;color:#111}
    .card{max-width:720px;padding:20px;border-radius:8px;background:#f7f9fc;border:1px solid #e6eaef}
    .ip{font-weight:700;font-size:1.5rem;margin-top:12px;word-break:break-all}
    .note{color:#444;margin-top:10px;font-size:0.95rem}
    .small{font-size:0.85rem;color:#666;margin-top:8px}
    .btn{display:inline-block;margin-top:14px;padding:8px 12px;border-radius:6px;background:#0b69ff;color:#fff;text-decoration:none}
  </style>
</head>
<body>
  <div class="card">
    <h2>Η δημόσια IP σου</h2>
    <div id="ip" class="ip"><?php echo htmlspecialchars($clientIp, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></div>
    <div class="note">Αυτή η σελίδα δεν αποθηκεύει την IP σε αρχείο ή βάση δεδομένων.</div>
    <div class="small">Προειδοποίηση: ο web server σου (π.χ. nginx/apache) μπορεί να καταγράφει access logs. Για πλήρη αποφυγή εγγραφής IPs πρέπει να αλλάξεις τη ρύθμιση του web server.</div>
    <a class="btn" href="#" onclick="location.reload();return false;">Ανανέωση</a>
  </div>
</body>
</html>
