
function DrawingExample(opts, canvas) {

    let ctx = canvas.getContext('2d', { willReadFrequently:true });


    let compound = null;

    return {

        setopts(options) {
            opts = options;
        },

        scale(sx, sy) {
            return null;
        },

        measure(str, font, width, height) {

            ctx.font = height + 'px monospace';
            let bbox = ctx.measureText(str);

            let descent = /[Qgjpqy]/.test(str) ? 0.25 * height : 0;
            return { width:bbox.width * width / height, ascent:0.65 * height, descent:descent };
        },

        init(width, height) {

            let padl = opts.paddingleft;
            let padr = opts.paddingright;
            let padt = opts.paddingtop;
            let padb = opts.paddingbottom;

            width += padl + padr;
            height += padt + padb;


            let tx = {  R:[ 1, height-padt, padl, 0.5 ],
                        L:[ 1, padt, width-padl, 1.5 ],
                        I:[ 0, width-padl, height-padt, 1 ] }[opts.rotate] ||
                          [ 0, padl, padt, 0 ];

            canvas.width  = tx[0] ? height : width;
            canvas.height = tx[0] ? width : height;
            ctx.setTransform(1, 0, 0, 1, 0, 0);    // Reset to unity transform


            if (/^[0-9a-fA-F]{6}$/.test(''+opts.backgroundcolor)) {
                ctx.fillStyle = '#' + opts.backgroundcolor;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }


            ctx.translate(tx[1], tx[2]);
            ctx.rotate(tx[3] * Math.PI);
        },

        line(x0, y0, x1, y1, linew, rgb) {
            ctx.beginPath();
            ctx.moveTo(x0, y0);
            ctx.lineTo(x1, y1);
            ctx.lineWidth = linew;
            ctx.lineCap = 'butt';
            ctx.strokeStyle = '#' + rgb;
            ctx.stroke();
        },

        polygon(pts) {
            if (!compound) {
                compound = new Path2D;
            }
            let path = new Path2D();
            path.moveTo(pts[0][0], pts[0][1]);
            for (let i = 1; i < pts.length; i++) {
                path.lineTo(pts[i][0], pts[i][1]);
            }
            path.closePath();
            compound.addPath(path);
        },

        hexagon(pts, rgb) {

            this.polygon(pts);
        },

        ellipse(x, y, rx, ry, ccw) {
            if (!compound) {
                compound = new Path2D;
            }
            let path = new Path2D();
            path.ellipse(x, y, rx, ry, 0, 0, 2*Math.PI, ccw);
            compound.addPath(path);
        },

        fill(rgb) {
            if (!compound) {
                return;
            }
            ctx.fillStyle = '#' + rgb;
            ctx.fill(compound, 'nonzero');
            compound = undefined;
        },

        clip : function(polys) {
            ctx.save();

            let region = new Path2D();
            for (let j = 0; j < polys.length; j++) {
                let pts = polys[j];
                let path = new Path2D();
                path.moveTo(pts[0][0], pts[0][1]);
                for (let i = 1; i < pts.length; i++) {
                    path.lineTo(pts[i][0], pts[i][1]);
                }
                path.closePath();
                region.addPath(path);
            }
            ctx.clip(region, 'nonzero');
        },
        unclip : function() {
            ctx.restore();
        },

        text(x, y, str, rgb, font) {
            let sx = font.width / font.height;
            ctx.save();
            ctx.scale(sx, 1);
            ctx.font = font.height  + 'px monospace';
            ctx.fillStyle = '#' + rgb;
            ctx.textBaseline = 'alphabetic';
            ctx.textAlign = 'left';
            ctx.fillText(str, x / sx, y);
            ctx.restore();
        },

        end() {

        },
    };
}
