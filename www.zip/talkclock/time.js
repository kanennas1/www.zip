// time.js

// 1) build speechMap (unchanged)
const speechMap = { toneIntro: 'Στον επόμενο τόνο η ώρα θα είναι: ' };

const hours = [
 'Μηδέν ', 'Μία ', 'δύο ', 'τρείς ',
 'Τέσσερις ', 'Πέντε ', 'έξι ', 'επτά ',
 'Οκτώ ', 'Εννιά ', 'Δέκα ', 'ένδεκα ',
 'Δώδεκα ', 'Δεκατρείς ', 'Δεκατέσσερις ', 'Δεκαπέντε ',
 'Δεκαέξι ', 'Δεκαεπτά ', 'Δεκαοκτώ ', 'Δεκαεννιά ',
 'Είκοσι ', 'Εικοσιμία ', 'Εικοσιδύο ', 'Εικοσιτρείς '
];

const minutes = [
 ' ', '& ένα ', '& δύο ', '& τρία ',
 '& τέσσερα ', '& πέντε ', '& έξι ', '& επτά ',
 '& οκτώ ', '& εννιά ', '& δέκα ', '& ένδεκα ',
 '& δώδεκα ', '& δεκατρία ', '& δεκατέσσερα ', '& δεκαπέντε ',
 '& δεκαέξι ', '& δεκαεπτά ', '& δεκαοκτώ ', '& δεκαεννιά ',
 '& είκοσι ', '& εικοσιένα ', '& εικοσιδύο ', '& εικοσιτρία ',
 '& εικοσιτέσσερα ', '& εικοσιπέντε ', '& εικοσιέξι ', '& εικοσιεπτά ',
 '& εικοσιοκτώ ', '& εικοσιεννιά ', '& τριάντα ', '& τριανταένα ',
 '& τριανταδύο ', '& τριαντατρία ', '& τριαντατέσσερα ', '& τριανταπέντε ',
 '& τριανταέξι ', '& τριανταεπτά ', '& τριανταοκτώ ', '& τριανταεννιά ',
 '& σαράντα ', '& σαρανταένα ', '& σαρανταδυό ', '& σαραντατρία ',
 '& σαραντατέσσερα ', '& σαρανταπέντε ', '& σαρανταέξι ', '& σαρανταεπτά ',
 '& σαρανταοκτώ ', '& σαρανταεννιά ', '& πενήντα ', '& πενηνταένα ',
 '& πενηνταδύο ', '& πενηντατρία ', '& πενηντατέσσερα ', '& πενηνταπέντε ',
 '& πενηνταέξι ', '& πενηνταεπτά ', '& πενηνταοκτώ ', '& πενηνταεννιά '
];

const seconds = [
 'ακριβώς.', '& δέκα δευτερόλεπτα.', '& είκοσι δευτερόλεπτα.',
 '& τριάντα δευτερόλεπτα.', '& σαράντα δευτερόλεπτα.', '& πενήντα δευτερόλεπτα.'
];

hours.forEach((t,i) => speechMap[`h${i}`] = t);
minutes.forEach((t,i) => speechMap[`m${i}`] = t);
seconds.forEach((t,i) => speechMap[`s${i*10}`] = t);

// 2) audio + sprite loading (unchanged)
const fallbackAudio = document.getElementById('beep-fallback');
const audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
let beepBuffer, spriteBuffer, spriteMapData;
async function decodeAudio(url) {
 try {
  const r = await fetch(url);
  const ab = await r.arrayBuffer();
  return await audioCtx.decodeAudioData(ab);
 } catch {
  return null;
 }
}
async function loadAssets() {
 [beepBuffer, spriteBuffer] = await Promise.all([
  decodeAudio('timebeep.mp3'),
  decodeAudio('sprite.mp3')
 ]);
 let originalMap = {};
 try {
  originalMap = await fetch('sprite-map.json').then(r => r.json());
 } catch {}
 spriteMapData = {};
 if (originalMap.toneIntro) spriteMapData.toneIntro = originalMap.toneIntro;
 Object.entries(originalMap).forEach(([key, clip]) => {
  const m = key.match(/\d+$/);
  if (!m) return;
  const n = String(parseInt(m[0], 10));
  if (key.startsWith('hour'))  spriteMapData[`h${n}`] = clip;
  else if (key.startsWith('minute')) spriteMapData[`m${n}`] = clip;
  else if (key.startsWith('sec'))  spriteMapData[`s${n}`] = clip;
 });
}

// Guard to prevent double starts inside the same 10s window
let lastSpeechWindow = -1;
let isSpeaking = false;

// Estimate duration (seconds) of a speech key sequence using spriteMapData
function estimateSequenceDuration(keys, maxDurationSec = 7) {
  if (!spriteMapData) return maxDurationSec;
  let elapsed = 0;
  for (const key of keys) {
    const clip = spriteMapData[key];
    if (!clip) continue;
    elapsed += Math.min(clip.duration, maxDurationSec - elapsed);
    if (elapsed >= maxDurationSec) break;
  }
  return Math.max(0.1, elapsed);
}

// Try to start speech but block duplicates; uses an estimated duration to release lock
function tryStartSpeech(keys, maxDurationSec = 7) {
  const now = Date.now();
  const windowIndex = Math.floor(now / 10000);
  if (windowIndex === lastSpeechWindow) return false;
  if (isSpeaking) return false;
  lastSpeechWindow = windowIndex;
  isSpeaking = true;
  // start beep + sequence as before
  //playBeep();
  playSpeechSequence(keys, maxDurationSec);
  const dur = estimateSequenceDuration(keys, maxDurationSec);
  setTimeout(() => { isSpeaking = false; }, Math.ceil(dur * 1000) + 200);
  return true;
}

// 3) playback helpers (unchanged)
function playBeep() {
 if (audioCtx.state === 'suspended') audioCtx.resume();
 if (beepBuffer) {
  const src = audioCtx.createBufferSource();
  src.buffer = beepBuffer;
  src.connect(audioCtx.destination);
  src.start();
 } else {
  fallbackAudio.currentTime = 0;
  fallbackAudio.play().catch(()=>{});
 }
}
function playSpeechSequence(keys, maxDurationSec = 7) {
 if (audioCtx.state === 'suspended') audioCtx.resume();
 let t = audioCtx.currentTime, elapsed = 0;
 for (const key of keys) {
  const clip = spriteMapData[key];
  if (!clip) continue;
  const dur = Math.min(clip.duration, maxDurationSec - elapsed);
  if (dur <= 0) break;
  const src = audioCtx.createBufferSource();
  src.buffer = spriteBuffer;
  src.connect(audioCtx.destination);
  src.start(t, clip.start, dur);
  t += dur;
  elapsed += dur;
 }
}

// 4) drawAnalogClock (reads all sizing/colors from CSS vars)
const canvas = document.getElementById('analogClockCanvas');
const ctx2  = canvas.getContext('2d');

function drawAnalogClock(now) {
  canvas.width = canvas.clientWidth;
  canvas.height = canvas.clientHeight;

  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const S = getComputedStyle(document.documentElement);

  const rF = parseFloat(S.getPropertyValue('--clock-radius-factor'));
  const osWf = parseFloat(S.getPropertyValue('--outer-stroke-width-factor'));
  const thWf = parseFloat(S.getPropertyValue('--tick-hour-width-factor'));
  const tmWf = parseFloat(S.getPropertyValue('--tick-minute-width-factor'));
  const tch = S.getPropertyValue('--tick-hour-color').trim();
  const tcm = S.getPropertyValue('--tick-minute-color').trim();
  const hnc = S.getPropertyValue('--hour-number-color').trim();
  const hhnc = S.getPropertyValue('--hour-hidden-number-color').trim();
  const hfF = parseFloat(S.getPropertyValue('--hour-font-size-factor'));
  const hndf = parseFloat(S.getPropertyValue('--hour-number-distance-factor'));
  const hhb = S.getPropertyValue('--hour-hand-border').trim();
  const hhc = S.getPropertyValue('--hour-hand-color').trim();
  const mhb = S.getPropertyValue('--minute-hand-border').trim();
  const mhc = S.getPropertyValue('--minute-hand-color').trim();
  const shc = S.getPropertyValue('--second-hand-color').trim();
  const hhlf = parseFloat(S.getPropertyValue('--hour-hand-length-factor'));
  const mhlf = parseFloat(S.getPropertyValue('--minute-hand-length-factor'));
  const ocC = S.getPropertyValue('--outer-circle-color').trim() || 'transparent';
  const hccc = S.getPropertyValue('--hand-center-cap-color').trim();

  const radius = Math.min(w, h) * rF;

  ctx2.clearRect(0, 0, w, h);

  // outer circle
  ctx2.beginPath();
  ctx2.arc(cx, cy, radius, 0, 2 * Math.PI);
  ctx2.lineWidth = radius * osWf;
  ctx2.strokeStyle = ocC;
  ctx2.stroke();


// Apply shadow to ticks (simulate text-shadow: 1px 1px 0px black)
ctx2.shadowColor = 'black';
ctx2.shadowOffsetX = 1;
ctx2.shadowOffsetY = 1;
ctx2.shadowBlur = 0;

  // ticks
  for (let i = 0; i < 60; i++) {
    const angle = (i / 60) * 2 * Math.PI - Math.PI / 2;
    const isHour = i % 5 === 0;
    const len = radius * (isHour ? 0.12 : 0.06);
    const x1 = cx + Math.cos(angle) * (radius - len);
    const y1 = cy + Math.sin(angle) * (radius - len);
    const x2 = cx + Math.cos(angle) * radius;
    const y2 = cy + Math.sin(angle) * radius;

    ctx2.beginPath();
    ctx2.moveTo(x1, y1);
    ctx2.lineTo(x2, y2);
    ctx2.lineWidth = radius * (isHour ? thWf : tmWf);
    ctx2.strokeStyle = isHour ? tch : tcm;
    ctx2.stroke();
  }

// Reset shadow after drawing ticks
ctx2.shadowColor = 'transparent';
ctx2.shadowOffsetX = 0;
ctx2.shadowOffsetY = 0;
ctx2.shadowBlur = 0;



  // hour numbers
  ctx2.font = `${radius * hfF}px sans-serif`;
  ctx2.textAlign = 'center';
  ctx2.textBaseline = 'middle';

// Simulate CSS text-shadow: 1px 1px 0px black
ctx2.shadowColor = 'black';
ctx2.shadowOffsetX = 1;
ctx2.shadowOffsetY = 1;
ctx2.shadowBlur = 0;

  for (let num = 1; num <= 12; num++) {
    const angle = (num / 12) * 2 * Math.PI - Math.PI / 2;
    const tx = cx + Math.cos(angle) * radius * hndf;
    const ty = cy + Math.sin(angle) * radius * hndf;
    ctx2.fillStyle = [88, 88, 888].includes(num) ? hhnc : hnc;
    ctx2.fillText(num.toString(), tx, ty);
  }

// Reset shadow after drawing text to avoid affecting other elements
ctx2.shadowColor = 'transparent';
ctx2.shadowOffsetX = 0;
ctx2.shadowOffsetY = 0;
ctx2.shadowBlur = 0;


  // hands
  const hr = now.getHours() % 12;
  const mn = now.getMinutes();
  const sc = now.getSeconds();

// hour hand
const hourAngle = ((hr + mn / 60) / 12) * 2 * Math.PI - Math.PI / 2;

// Calculate end point
const xEnd = cx + Math.cos(hourAngle) * radius * hhlf;
const yEnd = cy + Math.sin(hourAngle) * radius * hhlf;

// Draw border (slightly thicker and wider)
ctx2.beginPath();
ctx2.moveTo(cx, cy);
ctx2.lineTo(xEnd, yEnd);
ctx2.lineWidth = radius * 0.05 + 2; // slightly thicker for border
ctx2.strokeStyle = hhb;
ctx2.lineCap = 'round'; // rounded edge
ctx2.stroke();

// Draw main hour hand on top
ctx2.beginPath();
ctx2.moveTo(cx, cy);
ctx2.lineTo(xEnd, yEnd);
ctx2.lineWidth = radius * 0.05;
ctx2.strokeStyle = hhc;
ctx2.lineCap = 'round'; // rounded edge
ctx2.stroke();



// minute hand
const minuteAngle = ((mn + sc / 60) / 60) * 2 * Math.PI - Math.PI / 2;
const mxEnd = cx + Math.cos(minuteAngle) * radius * mhlf;
const myEnd = cy + Math.sin(minuteAngle) * radius * mhlf;

// Draw border (slightly thicker)
ctx2.beginPath();
ctx2.moveTo(cx, cy);
ctx2.lineTo(mxEnd, myEnd);
ctx2.lineWidth = radius * 0.03 + 2; // slightly thicker for border
ctx2.strokeStyle = mhb;
ctx2.lineCap = 'round';
ctx2.stroke();

// Draw main minute hand on top
ctx2.beginPath();
ctx2.moveTo(cx, cy);
ctx2.lineTo(mxEnd, myEnd);
ctx2.lineWidth = radius * 0.03;
ctx2.strokeStyle = mhc;
ctx2.lineCap = 'round';
ctx2.stroke();



  // second hand
  const secondAngle = (sc / 60) * 2 * Math.PI - Math.PI / 2;
  ctx2.beginPath();
  ctx2.moveTo(cx, cy);
  ctx2.lineTo(
    cx + Math.cos(secondAngle) * radius * 0.85, // slightly longer than minute hand
    cy + Math.sin(secondAngle) * radius * 0.85
  );
  ctx2.lineWidth = radius * 0.01; // thin line
  ctx2.strokeStyle = shc;
  ctx2.stroke(); 
  
  // ✅ center cap to cover hand pivot
  const capRadius = radius * 0.04; // 4% of clock radius
  ctx2.beginPath();
  ctx2.arc(cx, cy, capRadius, 0, 2 * Math.PI);
  ctx2.fillStyle = hccc;
  ctx2.fill();
}

// redraw on resize
window.addEventListener('resize', () => drawAnalogClock(new Date()));

// 5) main clock init
(async function initClock() {
 const nowMs = () => Date.now();
 let offsetMs = 0;
 try {
  const t0 = nowMs();
  const { serverTimeMs } = await fetch('../myprog.php?time').then(r => r.json());
  const t1 = nowMs();
  offsetMs = serverTimeMs + (t1 - t0) / 2 - t1;
 } catch {
  offsetMs = 0;
 }

 await loadAssets();

 const dateEl = document.getElementById('hmerom');
 const clockEl = document.getElementById('clock');
 const textEl = document.getElementById('text1');

 const days  = ['ΚΥΡΙΑΚΗ','ΔΕΥΤΕΡΑ','ΤΡΙΤΗ','ΤΕΤΑΡΤΗ','ΠΕΜΠΤΗ','ΠΑΡΑΣΚΕΥΗ','ΣΑΒΒΑΤΟ'];
 const dateFmt = new Intl.DateTimeFormat('el-GR',{day:'2-digit',month:'2-digit',year:'numeric'});
 const timeFmt = new Intl.DateTimeFormat('el-GR',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});

 function renderDate() {
  const now = new Date(Date.now() + offsetMs);
  dateEl.textContent = `${days[now.getDay()]} ${dateFmt.format(now)}`;
 }

 function renderTime() {
  const now = new Date(Date.now() + offsetMs);
  clockEl.textContent = timeFmt.format(now);
 }

 function updateText1() {
  const now   = new Date(Date.now() + offsetMs);
  const s    = now.getSeconds();
  const nextSec = ((Math.floor(s / 10) + 1) * 10) % 60;
  const carryMin = nextSec === 0 ? 1 : 0;
  const nextMin = (now.getMinutes() + carryMin) % 60;
  const carryHr = (now.getMinutes() === 59 && carryMin) ? 1 : 0;
  const nextHr = (now.getHours() + carryHr) % 24;

  const hKey = `h${nextHr}`;
  const mKey = `m${nextMin}`;
  const sKey = `s${nextSec}`;

  textEl.innerHTML =
   `${speechMap.toneIntro}<br>` +
   `${speechMap[hKey]}${speechMap[mKey]}${speechMap[sKey]}`;

  return ['toneIntro', hKey, mKey, sKey];
 }

 function scheduleDateUpdate() {
  const now = new Date(Date.now() + offsetMs);
  const untilMidnight = new Date(
   now.getFullYear(),
   now.getMonth(),
   now.getDate() + 1
  ) - now;

  setTimeout(() => {
   renderDate();
   scheduleDateUpdate();
  }, untilMidnight);
 }

 function scheduleNextTick() {
  const msUntil = 1000 - ((Date.now() + offsetMs) % 1000);
  setTimeout(() => {
   const now = new Date(Date.now() + offsetMs);
   renderTime();
   drawAnalogClock(now);

if (now.getSeconds() % 10 === 0) {
  const seq = updateText1(); // returns keys array
  // start guarded speech 2 seconds after beep, matching previous behavior
  playBeep();
  setTimeout(() => tryStartSpeech(seq, 7), 2000);
}
   scheduleNextTick();
  }, msUntil);
 }

 renderDate();
 renderTime();
 drawAnalogClock(new Date());
 updateText1();
 scheduleDateUpdate();
 scheduleNextTick();
})();
