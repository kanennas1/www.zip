 "use strict";
const userAgent = navigator.userAgent || '';
const lowerUA = userAgent.toLowerCase();
// Basic browser checks
const isFirefox = /firefox/i.test(userAgent);
const isOpera = /opera|opr/i.test(userAgent);
const isEdge = /edg/i.test(userAgent); // Covers Chromium Edge
const isSafari = /^((?!chrome|android).)*safari/i.test(userAgent); // Excludes Chrome on iOS
const isChrome = !isFirefox && !isEdge && !isOpera && /chrome|crios/i.test(userAgent);
// Brave detection (async)
let isBrave = false;
if (navigator.brave && typeof navigator.brave.isBrave === 'function') {
 navigator.brave.isBrave().then(result => {
 isBrave = result;
 }).catch(() => {
 isBrave = false;
 });
}
// Device checks
const isAndroid = /android/i.test(userAgent);
const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile|windows phone|kindle/i.test(userAgent);
const baseDir1 = new URL('.', window.location.href).href; // briskei thn dieythinsi tou site + /   alla xwris to index.html 
// px   https://www.mysite.com/
var now = new Date();
var hour = now.getHours(); // 0 - 23

var timeday;

/* if (hour >= 6 && hour < 11) {
  timeday = 'proi.jpg';
} else if (hour >= 11 && hour < 21) {
  timeday = 'mesimeri.jpg';
} else {
  timeday = 'vrady.jpg';
} */ 

timeday = 'mypic1.jpg';
var notplay = true;
var mypic = baseDir1 + 'talkclock/' + timeday;
var xmypic = baseDir1 + 'talkclock/xmypic1.jpg';
var xblue = baseDir1 + 'talkclock/blue.jpg';
var cpic = 0;
var recpic = ''; //ok
var setrjirjs = false;
var setrjiaud = false;
var setrjimxu = false;
var myradio = '';
var myradioCmd = '';
var j = 0; // ari8mos selects 
var v = 0; // ari8mos ypopinakwn - dhladh selects 
var selectcols = 4; // sthles menu ******** aparaithto
var selectrows; // grammes menu = j / selectcols stroggylemeno akeraio sto +1 
selectrows = Math.ceil(j / selectcols);
var selplatos = 90; // platos select ****** aparaithto
var selypsos = 27; // ypsos select ******* aparaithto
if(isAndroid){selplatos = 89;}
if($(window).width() < selectcols * selplatos){selplatos = $(window).width() / selectcols}
var olaa = "";
var thesis = "center";
var codey = false;
var titley = true;
var nemi = "";
var uri;
var rest = "";
let raining = false;
let isDoorActive = false;
var URLI = "@";
var inbox = true;
var radicon = "stoptheradio";
var myradio1stream = 'https://mpc1.mediacp.eu/stream/djmackrandy/';
var theurl = '';
var keimstart = '<!DOCTYPE HTML>' +
 '<html lang="el" dir="ltr">' +
 '<head>' +
 '<meta charset="UTF-8">' +
 '<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">' +
 '<style>' +
 '@charset "UTF-8";' +
 '@font-face {' +
 'font-family: "Ubuntu Sans";' +
 'src: local("Ubuntu Sans"), url("Ubuntu-Regular.woff2") format("woff2");' +
 'font-weight: normal;' +
 'font-style: normal;' +
 'font-display: swap;' +
 '}' +
 '* {' +
 'font-family: "Ubuntu Sans", sans-serif;' +
 'font-size: 12px;' +
 '}' +
 '</style>';
const dochead = keimstart +
 '</head><body><div class="full" ' +
 'style="overflow-x:hidden;overflow-y:visible">' +
 '<table id="table1" style="width:calc(100vw - 12px);background:#ffffff;">';
const dil1 = '<tr><td><a class="tds" oncontextmenu="$(\'#URLink\').val($(this).next().html());return false"' +
 ' onclick="$(this).css(\'background\',\'#ccffcc\');$(this).next().css(\'background\',\'#ccffcc\');cal2(\'';
const dil2 = '\')">';
const dil3 = '</a><span class="sds" oncontextmenu="codex($(this).html());titlex($(this).prev().html());' +
 '$(this).prev().parent().parent().get(0).remove();return false"' +
 ' onclick="$(this).css(\'background\',\'#ccffcc\');cal2($(this).html())">';
const docend = '</table></div></body></html>';
/* --- flthead --- */
var topVal = this ? '0px' : '30px'; 
 
var flthead = `${keimstart}<style>
#filterContainer {position:fixed;margin-top:${topVal};right:10px;
 display:flex;align-items:center;white-space:nowrap;
 background:#fff;padding:2px 4px;border:1px solid green;border-radius:5px}
#filterInput {flex:0 1 auto;max-width:60vw;width:auto;
 box-sizing:border-box;background:#eeeedd;border:1px solid green;
 color:#000;font:14px/20px Ubuntu Sans}
#filtersearch {color:darkblue;background:yellow;
 padding:2px;font-size:14px;border:1px solid green;border-radius:5px;
 margin-right:4px}
@media(max-width:360px){
 #filterInput {max-width:50vw;font-size:12px;height:18px}
 #filtersearch{font-size:12px;padding:2px}
}
</style></head><body>
<div class=full style="overflow-x:hidden;overflow-y:visible">
 <div id=filterContainer>
 <input id=filterInput type=text placeholder="Filter... and click Sel:">
 &nbsp; <span id=filtersearch>&nbsp;Sel:&nbsp;</span>
 </div>
 <div style="height:15px"></div>
 <table id=table1 style="width:calc(100vw - 12px);background:#fff">
`;
const tmdb_keys = ['fb7bb23f03b6994dafc674c074d01761',
 'e55425032d3d0f371fc776f302e7c09b',
 '8301a21598f8b45668d5711a814f01f6',
 '8cf43ad9c085135b9479ad5cf6bbcbda',
 'da63548086e399ffc910fbc08526df05',
 '13e53ff644a8bd4ba37b3e1044ad24f3',
 '269890f657dddf4635473cf4cf456576',
 'a2f888b27315e62e471b2d587048f32e',
 '8476a7ab80ad76f0936744df0430e67c',
 '5622cafbfe8f8cfe358a29c53e19bba0',
 'ae4bd1b6fce2a5648671bfc171d15ba4',
 '257654f35e3dff105574f97fb4b97035',
 '2f4038e83265214a0dcd6ec2eb3276f5',
 '9e43f45f94705cc8e1d5a0400d19a7b7',
 'af6887753365e14160254ac7f4345dd2',
 '06f10fc8741a672af455421c239a1ffc',
 '09ad8ace66eec34302943272db0e8d2'];
const imdb_keys = ['4b447405','6c3a2d45'];
function help(){cal2('ifo_');$('#URLink').val('');}
function toggleViewport() {
 const meta = document.querySelector('meta[name="viewport"]');
 if (!meta) {
 console.error('No viewport meta tag found.');
 return;
 }
 const content = meta.getAttribute('content');
 const match = content.match(/initial-scale=([\d.]+)/);
 const current = match ? parseFloat(match[1]) : 1;
 const scales = [0.5, 0.75, 1.0];
 const idx = scales.indexOf(current);
 const next = scales[(idx + 1) % scales.length];
 const newContent = content.replace(/initial-scale=[\d.]+/, `initial-scale=${next}`);
 meta.setAttribute('content', newContent);
 $('#URLink').val(`#Zoom: ${next}`);
}
// CANVAS ICONS 
function drawCanvas(e, fillColor, strokeColor){
const canv = document.getElementById(e);
const ctx = canv.getContext("2d");
ctx.clearRect(0, 0, canv.width, canv.height);
ctx.fillStyle = fillColor;
ctx.fillRect(0, 0, canv.width, canv.height);
ctx.strokeStyle = strokeColor;
ctx.strokeRect(0, 0, canv.width, canv.height);
return ctx;
}
function showtrigram(e){
 const ctx = drawCanvas(e, "#ddeeff", "#000000");
 ctx.fillStyle = "#0088dd";
 ctx.lineJoin = "round";
 const barX = 4;
 const barWidth = 24;
 const barHeight = 5;
 const spacing = 3;
 const positionsY = [4, 12.5, 21];
 for (let y of positionsY) {
 ctx.beginPath();
 ctx.roundRect(barX, y, barWidth, barHeight, 2);
 ctx.fill();
 }
} 
function showsearch(e){
 const ctx = drawCanvas(e, "#ccddee", "#000000");
 ctx.font = "24px 'Ubuntu Sans', 'sans-serif'";
 ctx.textAlign = "center";
 ctx.textBaseline = "middle";
 ctx.fillText("\u{1F50D}", 16, 15);
}
function showplay1(e){
 const ctx = drawCanvas(e, "#556699", "#000000");
 ctx.font = "24px 'Ubuntu Sans', 'sans-serif'";
 ctx.textAlign = "center";
 ctx.textBaseline = "middle";
 ctx.fillText("\u{1F4FB}", 16, 15);
}
function showpause1(e){
 const ctx = drawCanvas(e, "#000088", "#000000");
 const canv = document.getElementById(e);
 const w = canv.width;
 const h = canv.height;
 ctx.font = "24px 'Ubuntu Sans', 'sans-serif'";
 ctx.textAlign = "center";
 ctx.textBaseline = "middle";
 ctx.fillStyle = "#eeeeee";
 ctx.fillText("\u{1F4FB}", w / 2, h / 2);
 ctx.strokeStyle = "#ff0000";
 ctx.lineWidth = 3;
 ctx.beginPath();
 ctx.moveTo(4, 4);
 ctx.lineTo(w - 4, h - 4);
 ctx.moveTo(w - 4, 4);
 ctx.lineTo(4, h - 4);
 ctx.stroke();
}
function showplay(e){
 const ctx = drawCanvas(e, "#26b273", "#000000");
 const canvasWidth = 32;
 const canvasHeight = 30;
 const width = 14;
 const height = 14;
 const centerX = 1 + canvasWidth / 2;
 const centerY = canvasHeight / 2;
 ctx.fillStyle = "#eeeecc";
 ctx.beginPath();
 ctx.moveTo(centerX - width / 2, centerY - height / 2);
 ctx.lineTo(centerX + width / 2, centerY);
 ctx.lineTo(centerX - width / 2, centerY + height / 2);
 ctx.closePath();
 ctx.fill();
}
function showpause(e){
	const ctx = drawCanvas(e, "#26b273", "#000000");
	ctx.fillStyle = "#eeeeee";
	ctx.fillRect(6, 5, 7, 20);
	ctx.fillRect(18, 5, 7, 20);
}
function showstop(e){
 const ctx = drawCanvas(e, "#bb0000", "#000000");
 ctx.fillStyle = "#eeeecc";
 ctx.fillRect(7, 12, 18, 6);
}
function runme(e){
 if (typeof e === 'undefined'){
 e = Math.floor(Math.random() * (j - 4)) + 4;
 }
 const selectElement = document.getElementById('select' + e);
 if (!selectElement){
 return;
 }
 const options = selectElement.getElementsByTagName('option');
 const optionCount = options.length;
 if (optionCount <= selectcols){
 return;
 }
 let selectedValue = '';
 const maxAttempts = 5;
 let attempts = 0;
 do {
 const randomIndex =
 Math.floor(Math.random() * (optionCount - selectcols)) + selectcols;
 selectedValue = options[randomIndex].value;
 attempts++;
 } while (!selectedValue && attempts < maxAttempts);
 if (selectedValue){
    const fb = $.fancybox.getInstance();  if (fb) fb.close();
    cal2(selectedValue);
 } else {
 }
}
function conv1(command){ 
 if (!command) return;
 showtrigram('trigram');
 $('#con1').prop('selectedIndex', 0);
 if(($.fancybox.getInstance()) && (!inbox)){$.fancybox.close();}
 if(!inbox){$('#player1').empty().off().removeData();}
 $('#URLink1').html('').hide(); $('#codetemp').empty();
 let finalCommand = command;
 if(command.length === 4 && command.charAt(3) === '_' && !command.startsWith('sss_')){
 const URL_PREFIX = 'xxx_';
 const urlValue = $('#URLink').val();
 const modifiedUrl = urlValue.charAt(3) === '_' ? urlValue : URL_PREFIX + urlValue;
 finalCommand += modifiedUrl.slice(4);
 }
 
// Check if finalCommand starts with 'sss_'
if (!finalCommand.startsWith('sss_')) {
 // If not, call cal2 with the full command
 cal2(finalCommand);
} else {
 // Remove the 'sss_' prefix (first 4 characters)
 const scriptContent = finalCommand.slice(4);
 // Safely inject the script into the #codetemp element
 // ⚠️ Make sure scriptContent is trusted to avoid XSS vulnerabilities
 const scriptTag = document.createElement('script');
 scriptTag.id = 'mytemp';
 scriptTag.charset = 'UTF-8';
 scriptTag.textContent = scriptContent;
 // Clear previous content and append the new script
 const container = document.getElementById('codetemp');
 container.innerHTML = ''; // Optional: clear existing content
 container.appendChild(scriptTag);
}
 
}
function buttonplay(){
if(radicon == "stoptheradio"){
 stoprji();
 $('#URLink').val('cav_' + `${myradio1stream}`);
 $('#URLink1').html('').hide();
// showtrigram('trigram');
 showpause1("radiobutton");
 radicon='playtheradio';
 myradio1.src = myradio1stream;
 myradio1.load();
 myradio1.play();
 }else{
 showplay1("radiobutton");
 radicon='stoptheradio';
 myradio1.pause();
 myradio1.removeAttribute('src');
 myradio1.load();}
}
// gia to  fondo()  
const fondoStylesMap = [
  { color: 'rgb(230, 185, 154)', image: `url(${xmypic})` },
  { color: 'rgb(230, 185, 154)', image: `url(${xblue})` },
  { color: 'rgb(29, 71, 87)', image: 'none' },
  { color: '',image: 'linear-gradient(to top, #005a88 0%, #000000 100%)'},
  { color: '',image: 'linear-gradient(to right, #f06, #4a90e2)' },
  { color: 'rgb(248, 244, 241)', image: 'none' },
  { color: 'rgb(253, 226, 205)', image: 'none' },
  { color: 'rgb(60, 40, 32)', image: 'none' },
  { color: 'rgb(0, 0, 0)', image: 'none' },
  { color: 'rgb(230, 185, 154)', image: `url(${mypic})` }
];
function fondo() {
  const style = fondoStylesMap[cpic];
  $('#player1').css({
    'background-color': style.color,
    'background-image': style.image
  });
  cpic = (cpic + 1) % fondoStylesMap.length;
}
function playpic1(){
 if (!mypic){
 mypic = 'talkclock/mypic1.jpg';
 }
 const styleId = 'pp1css';
 if (!document.getElementById(styleId)) {
 const css = [
 '#player1{background:#000 no-repeat fixed;box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.8);transition:background-position .3s,background-size .3s}',
 '#player1.centered{box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.8);background-position:50% 50%;background-size:cover}',
 '#player1.expanded{box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.8);background-position:0 100%;background-size:100% auto}'
 ].join('');
 const s = document.createElement('style');
 s.id = styleId;
 s.textContent = css;
 document.head.append(s);
 }
 const p = document.getElementById('player1');
 const expanded = p.classList.toggle('expanded');
 p.classList.toggle('centered', !expanded);
 p.style.backgroundImage = `url(${mypic})`;
}
function fws(id = 'player1'){
 // 0) inject slider CSS once
 if (!$('#bcStyles').length) {
 $('head').append(`
 <style id="bcStyles">
 .range-slider {
 -webkit-appearance: none;
 width: 100%;
 height: 14px;
 border-radius: 4px;
 background: #e0e0e0;
 transition: background .3s;
 }
 .range-slider:hover { background: #d0d0d0; }
 .range-slider::-webkit-slider-thumb,
 .range-slider::-moz-range-thumb {
 -webkit-appearance: none;
 width: 12px;
 height: 12px;
 border-radius: 50%;
 background: darkblue;
 border: 1px solid #0ff;
 box-shadow: 0 2px 6px rgba(0,0,0,.5);
 margin-top: 0px;
 cursor: pointer;
 transition: background .15s, transform .15s;
 }
 .range-slider:hover::-webkit-slider-thumb,
 .range-slider:hover::-moz-range-thumb {
 background: royalblue;
 transform: scale(1.1);
 }
 .range-slider::-webkit-slider-thumb::after,
 .range-slider::-moz-range-thumb::after {
 content: attr(data-value);
 //position: absolute;
 //top: -25px;
 left: 50%;
 transform: translateX(-50%);
 transform: translateY(10%);
 pointer-events: none;
 font-size: 10px;
 color: #000;
 }
 </style>
 `);
 }
 // 1) target element
 var $el = $('#' + id);
 if (!$el.length) {
 return alert('No element with id: ' + id);
 }
 // 2) parse existing filter values
 var f = window.getComputedStyle($el[0]).filter.replace(/^none$/, '');
 function getVal(re, def) {
 var m = f.match(re);
 return m ? +m[1] : def;
 }
 var br = getVal(/brightness\(([\d.]+)/, 1),
 ct = getVal(/contrast\(([\d.]+)/, 1),
 hu = getVal(/hue-rotate\(([\d.]+)deg/, 0),
 iv = getVal(/invert\(([\d.]+)/, 0),
 gr = getVal(/grayscale\(([\d.]+)/, 0),
 op = getVal(/opacity\(([\d.]+)/, 1),
 bl = getVal(/blur\(([\d.]+)px/, 0);
 // 3) apply CSS filter
 function applyFilter() {
 $el.css('filter', [
 `brightness(${br})`,
 `contrast(${ct})`,
 `hue-rotate(${hu}deg)`,
 `invert(${iv})`,
 `grayscale(${gr})`,
 `opacity(${op})`,
 `blur(${bl}px)`
 ].join(' '));
 }
 // 4) fill track behind slider
 function updateFill($s, v, min, max) {
 var pct = ((v - min) / (max - min)) * 100;
 $s.css('background',
 `linear-gradient(to right, darkred 0%, orange ${pct}%, #e0e0e0 ${pct}%, #e0e0e0 100%)`
 );
 }
 // 5) build modal container
 var $modal = $('<div id="bcModal">').css({
 position: 'fixed',
 top: '140px',
 left: '50%',
 transform: 'translate(-50%,0%)',
 background: 'rgba(255, 255, 255, 0.08)',
 backdropFilter: 'blur(2px)',
 padding: '4px',
 borderRadius:'4px',
 maxWidth: '340px',
 boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
 color: '#000',
 textShadow: '1px 1px 2px rgba(255, 255, 0, 0.8)',
 zIndex: 1850,
 opacity: 0,
 transition: 'opacity 200ms ease-out'
 }).appendTo('body');
 
 requestAnimationFrame(() => $modal.css('opacity', 1));
 // 6) element selector
 var $sel = $(`
 <select style="width:100%;margin-bottom:4px">
 <option value="">Select element…</option>
 <option value="player1" style="color:yellow">player1</option>
 <option value="tvframe">tvframe</option>
 <option value="table1">table1</option>
 <option value="menu">menu</option>
 <option value="form1">form1</option>
 <option value="trigram">trigram</option>
 <option value="URLink">URLink</option>
 <option value="URLink1">URLink1</option>
 <option value="plbutton">plbutton</option>
 <option value="stbutton">stbutton</option>
 </select>
 `).val(id).on('change', function() {
 teardown();
 fws(this.value);
 }).appendTo($modal);
 // 7) slider row factory
 function addSlider(label, min, max, start, unit, setter) {
 var rawVal = unit === '%' ? start * 100 : unit === 'px' ? start : start;
 var disp = unit === '%' ? Math.round(rawVal) + '%' :
 unit === 'px' ? rawVal + 'px' : start + unit;
 var $row = $('<div>').css({
 display: 'flex',
 justifyContent: 'space-between',
 alignItems: 'center',
 margin: '2px 0'
 }).appendTo($modal);
 $('<div>').text(label).appendTo($row);
 var $val = $('<div>').text(disp).appendTo($row);
 var $input = $(`<input type="range" class="range-slider">`)
 .attr({ min: min, max: max, value: rawVal })
 .attr('data-value', disp)
 .appendTo($modal)
 .on('input', function() {
 var v = +this.value;
 var mapped = unit === '%' ? v / 100 : unit === 'px' ? v : v;
 setter(mapped);
 var txt = unit === '%' ? Math.round(v) + '%' :
 unit === 'px' ? v + 'px' : v + unit;
 $val.text(txt);
 $(this).attr('data-value', txt);
 applyFilter();
 updateFill($(this), v, min, max);
 });
 updateFill($input, rawVal, min, max);
 }
 // 8) instantiate sliders
 addSlider('Brightness', 20, 150, br, '%', v => br = v);
 addSlider('Contrast', 20, 150, ct, '%', v => ct = v);
 addSlider('Hue', 0, 360, hu, 'deg', v => hu = v);
 addSlider('Invert', 0, 100, iv, '%', v => iv = v);
 addSlider('Grayscale', 0, 100, gr, '%', v => gr = v);
 addSlider('Opacity', 0, 100, op, '%', v => op = v);
 addSlider('Blur', 0, 10, bl, 'px', v => bl = v);
 // 9) footer + OK
 var $footer = $('<div>').css({
 display: 'flex',
 justifyContent: 'space-between',
 marginTop: '4px'
 }).appendTo($modal);
 $('<div>').text(id)
 .css({ fontWeight: 'bold', fontSize: '13px' })
 .appendTo($footer);
 $('<button>').text('OK')
 .css({
 padding: '4px 8px',
 background: 'green',
 color: '#ff0',
 border: 'none',
 borderRadius: '4px',
 cursor: 'pointer'
 })
 .hover(
 e => $(e.currentTarget).css('background', '#060'),
 e => $(e.currentTarget).css('background', 'green')
 )
 .on('click', teardown)
 .appendTo($footer);
 // 10) ESC key to close
 $(document).on('keydown.bcModal', e => {
 if (e.key === 'Escape') teardown();
 });
 function teardown() {
 $modal.remove();
 $(document).off('keydown.bcModal');
 }
 // initial application
 applyFilter();
}
function filterTable(filterText){
 const lowerCaseFilter = filterText.toLowerCase();
 const $rows = $('#table1 tr');
 $rows.each(function(){
 const rowText = $(this).text().toLowerCase().trim();
 if(rowText.includes(lowerCaseFilter)){
 $(this).show();
 } else {
 $(this).hide();
 }
 });
 $('#table1 td').removeClass('odd');
 $('#table1 td:visible:odd').addClass('odd');
}
function pinax2(searchText){
 if (!searchText) return;
if (searchText?.startsWith('get_')) { do { searchText = searchText.slice(4); } while (searchText.startsWith('get_')); }
 $('#player1').empty();
 playpic1();
 offmenu();
 const lowerSearch = searchText.toLowerCase();
 const buttonStyles = `
 width: 130px;
 height: 40px;
 border-radius: 10px;
 box-shadow: 5px 3px 3px #99aacc;
 margin: 0 0 10px 0;
 `;
 const searchOptions = `
 <div id="searchOptions"
 style="margin-left:10px; margin-top:10px; width:240px; background:#cccccc; border:2px solid black; border-radius:10px; text-align:center; box-shadow:5px 3px 3px #99aacc;">
 <br>-- ΑΝΑΖΗΤΗΣΗ ▲ με μικρά γράμματα ▲<br>
 --- Τρόπος Αναζήτησης --<br><br>
 <button class="searchButton" data-option="value"
 style="${buttonStyles} border:3px solid darkred; transform:rotate(-5deg);">
 μόνο σε URL
 </button>
 <button class="searchButton" data-option="text"
 style="${buttonStyles} border:3px solid darkgreen;">
 μόνο σε ONOMA
 </button>
 <button class="searchButton" data-option="both"
 style="${buttonStyles} border:3px solid darkblue; transform:rotate(5deg);">
 παντου
 </button>
 <br>Πατήστε ένα button για αναζήτηση:<br>&nbsp;
 </div>
 `;
 // Inject into DOM
 $('#player1').append(searchOptions);
 // 1) Grab the “both” button
 const bothBtn = $('#searchOptions .searchButton[data-option="both"]');
 // 2) Focus it
 bothBtn.focus();
 // 3) (Optional) Add a CSS rule so :focus is really visible
 $('<style>')
 .text(`
.searchButton:focus {
 outline: 3px solid orange;
 background: #ffffcc;
}
 `)
 .appendTo('head');
 // Helper: count visible rows and update the DL1 span
 function updateDataLinesCount() {
 const visible = $('#table1 tbody tr:visible').length;
 $('#DL1').text(`--- Data Lines: ${visible}`);
 }
 function performSearch(option) {
 let optionCount = 0;
 let resultsHtml = flthead;
 for (let e = 0; e < (j || 0); e++) {
 $(`#select${e} option`).each(function () {
 const val = this.value.toLowerCase();
 const txt = this.text.toLowerCase();
 const match =
 (option === 'value' && val.includes(lowerSearch)) ||
 (option === 'text' && txt.includes(lowerSearch)) ||
 (option === 'both' && (val.includes(lowerSearch) || txt.includes(lowerSearch)));
 if (match) {
 optionCount++;
 resultsHtml += (
 dil1 +
 this.value +
 dil2 +
 this.text +
 dil3 +
 this.value +
 '</span></td></tr>'
 );
 }
 });
 }
 // inject counter before closing table
 resultsHtml += `
 <br>
 <span id='DL1' style='margin-left:10px;color:white;background:black'>
 --- Data Lines: ${optionCount}
 </span>
 <br>
 `;
 resultsHtml += docend;
 $('#player1').append(resultsHtml);
 // styling
 $('td:contains("·")').addClass('limeBg');
 $('#table1 td:odd').addClass('odd');
 // wire up filter + counter-update
 $('#filtersearch').on('click', function () {
 filterTable($('#filterInput').val());
 updateDataLinesCount();
 });
 $('#filterInput').on('keypress', function (e) {
 if (e.which === 13) {
 filterTable(this.value);
 updateDataLinesCount();
 }
 });
 }
 // kick off search
 $('.searchButton').on('click', function () {
 const mode = $(this).data('option');
 performSearch(mode);
 $('#searchOptions').remove();
 });
}
function epilogi(){
 // Remove any existing modal
 $('#select-length-modal').remove();
 // Configuration
 var totalLinks = 0;
 var cols = 4; // exactly 4 cells per row
 var startIdx = 4; // ignore selects #select0–#select3
 var rows = Math.ceil((j - startIdx) / cols);
// Build modal container
var $modal = $('<div>', { id: 'select-length-modal' }).css({
 position: 'absolute',
 top: '30px',
 left: '0px',
 background: 'var(--select-bg)',
 border: 'none',
 padding: '10px',
 'box-shadow': 'var(--select-box-shadow)',
 'font-family': 'var(--font-family)',
 'text-indent': 'var(--select-text-indent)',
 'text-shadow': 'var(--select-text-shadow)',
 'line-height': 'var(--select-line-height)',
 'z-index': 'var(--epil-modal)',
 });
 // Close button
 $('<button>')
 .text('Close')
 .css({
 float: 'right',
 padding: '4px',
 fontWeight: 'bold',
 borderRadius: '5px',
 marginBottom: '10px',
 cursor: 'pointer'
 })
 .on('click', function() {
 $modal.remove();
 })
 .appendTo($modal);
 // Total options counter
 var $total = $('<div>')
 .text('Total options: 0')
 .css({ marginBottom: '8px', color: 'yellow' })
 .appendTo($modal);
 // Table setup
 var $table = $('<table>')
 .css({ 'border-collapse': 'collapse', width: '180px' })
 .appendTo($modal);
 // Populate rows & cells
 for (var r = 0; r < rows; r++) {
 var $tr = $('<tr>').appendTo($table);
 for (var c = 0; c < cols; c++) {
 var idx = startIdx + r * cols + c;
 if (idx < j) {
 var $sel = $('#select' + idx);
 var count = $sel.find('option').length;
 var title = $sel.find('option:first').text();
 totalLinks += count;
 $('<td>')
 .text(count)
 .attr('title', title)
 .css({
 border: '1px solid #999',
 padding: '4px',
 textAlign: 'center',
 cursor: 'pointer'
 })
 .data('idx', idx)
 .on('click', function() {
 pin($(this).data('idx')); $modal.remove();
 })
 .appendTo($tr);
 } else {
 // filler cell for uneven last row
 $('<td>')
 .css({
 border: '1px solid transparent',
 padding: '4px'
 })
 .appendTo($tr);
 }
 }
 }
 // Update total and inject into DOM
 $total.text('Total options: ' + totalLinks);
 $('body').append($modal);
 
 // allow closing with Esc $modal.on(
 $(document).on('keydown.selectLengthModal', function(e) {
 if (e.key === 'Escape') {
 $modal.remove();
 $(document).off('keydown.selectLengthModal');
 }
 });
}
function pin(e) {
    const $player1 = $('#player1').empty().off().removeData();
    offmenu();

    $player1.off('contextmenu').on('contextmenu', evt => {
        evt.preventDefault();
        evt.stopPropagation();
    });

    let rowsHtml = '';
    if (typeof e === 'number' && e >= 0 && e < j) {
        rowsHtml = $(`#select${e} option`).map(function () {
            return `${dil1}${this.value}${dil2}${this.text}${dil3}${this.value}</span></td></tr>`;
        }).get().join('');
    } else {
        for (let idx = 0; idx < j; idx++) {
            rowsHtml += $(`#select${idx} option`).map(function () {
                return `${dil1}${this.value}${dil2}${this.text}${dil3}${this.value}</span></td></tr>`;
            }).get().join('');
        }
    }

    const html = [
        flthead,
        '<br>',
        `<span id="DL1" style="margin-left:10px;color:white;background:black"></span>`,
        '<br>',
        rowsHtml,
        docend
    ].join('');

    const fragment = document.createRange().createContextualFragment(html);
    $player1.append(fragment);

    $('#table1 td:odd').addClass('odd');
    $('td').filter((_, td) => td.textContent.includes('·')).addClass('limeBg');

    const updateDataLinesCount = () => {
        const count = $('#table1 tbody tr:visible').length;
        $('#DL1').text(`--- Data Lines: ${count}`);
    };
    updateDataLinesCount();

    $('#filtersearch').off('click').on('click', () => {
        filterTable($('#filterInput').val());
        updateDataLinesCount();
    });

    $('#filterInput').off('keypress').on('keypress', evt => {
        if (evt.which === 13) {
            filterTable(evt.target.value);
            updateDataLinesCount();
        }
    });

    // ---- NEW: Sorting function ----
    function sortTableByFirstColumn() {
        const rows = $('#table1 tbody tr').get();

        rows.sort((a, b) => {
            const A = $(a).find('td:first').text().trim();
            const B = $(b).find('td:first').text().trim();

            const numA = parseFloat(A), numB = parseFloat(B);
            if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
            return A.localeCompare(B);
        });

        $('#table1 tbody').empty().append(rows);
    }

    // ---- NEW: Ask user only when e is undefined ----
    if (typeof e !== 'number') {
        setTimeout(() => {
            if (confirm("Sort the table by the first column?")) {
                sortTableByFirstColumn();
                updateDataLinesCount();
            }
        }, 50);
    }
}

function tax(e){
 const select = document.getElementById("select" + e);
 select.style.display = "none";
 const sortedHTML = Array.from(select.options)
 .sort((a, b) => a.textContent.localeCompare(b.textContent))
 .map(opt => `<option value="${opt.value}">${opt.textContent}</option>`)
 .join('');
 select.innerHTML = sortedHTML;
 select.selectedIndex = 0;
 select.style.display = "";
}
function codex(e){
	if(!codey && titley){
		codey = true;
		titley = false;
		nemi += `"${e}",`;
		return `"${e}",`;
	}
	return "";
}
function titlex(e){
	if(codey && !titley){
		titley = true;
		codey = false;
		nemi += `"${e}",\n`;
		return `"${e}",`;
	}
	return "";
}
function copyNemi(){
 const textArea = document.getElementById("nemiTextArea");
 textArea.select();
 document.execCommand("copy");
 alert("Αντιγράφηκε στο clipboard");
}
function clearNemi(){
 if(confirm("Επιβεβαιώνετε το άδειασμα της λίστας;")){
 nemi = '';
 $.fancybox.close();
 }
}

function ora() {
 const html = `<!DOCTYPE HTML>
<html lang="el" dir="ltr">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
 <title>SYnchronize Time windows</title>
</head>
<body>
 <br>
 Για συγχρονισμο ώρας απο ΙΝΤΕΡΝΕΤ χρησιμοποιώντας DOS:<br><br>
 Κάντε ένα αρχείο <b>SETTIME.BAT</b><br>
 Σώστε το, και τρέξτε το ως Διαχειριστής:<br><br>
 <textarea style="width:680px;height:300px" onclick="this.select()">
Rem run as administrator
@echo on & @setlocal enableextensions
@echo =========================
@echo Turn off the time service
net stop w32time
@echo ======================================================================
@echo Set the SNTP (Simple Network Time Protocol) source for the time server
w32tm /config /syncfromflags:manual /manualpeerlist:"0.gr.pool.ntp.org 1.europe.pool.ntp.org"
@echo =============================================
@echo ... and then turn on the time service back on
net start w32time
@echo =============================================
@echo Tell the time sync service to use the changes
w32tm /config /update
@echo =======================================================
@echo Reset the local computer s time against the time server
w32tm /resync /force /rediscover 
@endlocal & @goto :EOF
 </textarea>
</body>
</html>`;
 // Create blob & trigger download
 const blob = new Blob([html], { type: "text/html" });
 const url = URL.createObjectURL(blob);
 const a = document.createElement("a");
 a.href = url;
 a.download = "settime.html";
 document.body.appendChild(a);
 a.click();
 a.remove();
 URL.revokeObjectURL(url);
 }

function cleanoffice() {
 const html = `<!DOCTYPE HTML>
<html lang="el" dir="ltr">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
 <title>Clean Office MRU lists</title>
</head>
<body>
 <br>
 Για καθαρισμο λιστας προσφατων αρχειων OFFICE:<br><br>
 Κάντε ένα αρχείο <b>CLEANOFFICE.BAT</b><br>
 Σώστε το, και τρέξτε το:<br><br>
 <textarea style="width:680px;height:300px" onclick="this.select()">
@echo off
setlocal enabledelayedexpansion

REM --- Εκδόσεις Office προς επεξεργασία ---
set VERS=13.0 14.0 15.0 16.0

REM --- Εφαρμογές ---
set APPS=Word Excel PowerPoint Access

echo Deleting MRU entries for Office versions: %VERS%
echo.

for %%V in (%VERS%) do (
  echo ===== Processing Office version %%V =====
  for %%A in (%APPS%) do (
    echo  - App: %%A

    rem Delete common subkeys if present
    reg delete "HKCU\Software\Microsoft\Office\%%V\%%A\File MRU" /f >nul 2>&1
    reg delete "HKCU\Software\Microsoft\Office\%%V\%%A\Recent Files" /f >nul 2>&1
    reg delete "HKCU\Software\Microsoft\Office\%%V\%%A\Recent File List" /f >nul 2>&1

    rem Delete individual MRU values named like "Item 1", "Item 2", etc.
    for /f "tokens=*" %%K in ('reg query "HKCU\Software\Microsoft\Office\%%V\%%A" 2^>nul ^| findstr /i "Item"') do (
      set "line=%%K"
      set "valname="
      for %%T in (!line!) do set "valname=%%T"
      if defined valname (
        echo    Deleting value "!valname!" under %%A (ver %%V)
        reg delete "HKCU\Software\Microsoft\Office\%%V\%%A" /v "!valname!" /f >nul 2>&1
      )
    )

    rem Best-effort: delete any values with MRU or Recent in the name (attempt)
    for /f "tokens=*" %%M in ('reg query "HKCU\Software\Microsoft\Office\%%V\%%A" 2^>nul ^| findstr /i "MRU Recent"') do (
      rem try to extract last token as value name
      set "line2=%%M"
      set "v2="
      for %%U in (!line2!) do set "v2=%%U"
      if defined v2 (
        reg delete "HKCU\Software\Microsoft\Office\%%V\%%A" /v "!v2!" /f >nul 2>&1
      )
    )
  )
  echo.
)

echo Finished clearing MRU for versions %VERS%.
echo Open the Office apps to verify the Recent lists.
pause
endlocal

 </textarea>
</body>
</html>`;
 // Create blob & trigger download
 const blob = new Blob([html], { type: "text/html" });
 const url = URL.createObjectURL(blob);
 const a = document.createElement("a");
 a.href = url;
 a.download = "cleanoffice.html";
 document.body.appendChild(a);
 a.click();
 a.remove();
 URL.revokeObjectURL(url);
 }

function epitrepetai(rest1) {

cal2(rest1);

/* 
  const msg = `Θέλετε σίγουρα να τρέξετε
αυτή την απαγορευμένη επιλογή;
Αν ΟΧΙ: πατήστε [Ακύρωση] ή ESC`;
  // Create and style wrapper
  const wrapper = document.createElement('div');
  wrapper.style.cssText = `
    position: fixed;
    left: 50%;
    transform: translateX(-50%);
    top: 6vh;
    z-index: 2147483647;
    display: flex;
    justify-content: center;
    pointer-events: auto;
  `;
  // Create and style card with inner HTML
  const card = document.createElement('div');
  card.style.cssText = `
    min-width: 300px;
    max-width: 520px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.12);
    padding: 12px 14px;
    font: 14px/1.35 system-ui, Segoe UI, Roboto, Arial, sans-serif;
    color: #111;
  `;
  card.innerHTML = `
    <div style="white-space: pre-wrap; margin-bottom: 10px;">
      ${msg}
    </div>
    <div style="display: flex; justify-content: flex-end; gap: 8px;">
      <button id="btnCancel" style="
        padding: 6px 10px;
        border: 1px solid #cfcfcf;
        border-radius: 6px;
        background: transparent;
        cursor: pointer;
      ">
        Ακύρωση
      </button>
      <button id="btnOk" style="
        padding: 6px 10px;
        border: 1px solid transparent;
        border-radius: 6px;
        background: #0b63ff;
        color: #fff;
        cursor: pointer;
      ">
        OK
      </button>
    </div>
  `;
  wrapper.append(card);
  document.body.append(wrapper);
  // References to buttons
  const btnCancel = card.querySelector('#btnCancel');
  const btnOk     = card.querySelector('#btnOk');
  // Cleanup routine
  const cleanup = () => {
    document.removeEventListener('keydown', onEsc, { once: true });
    wrapper.remove();
  };
  // Handlers
  const onEsc = (e) => {
    if (e.key === 'Escape') cleanup();
  };
  btnCancel.addEventListener('click', cleanup, { once: true });
  btnOk.addEventListener('click', () => {
    try { cal2(rest1); } catch {}
    cleanup();
  }, { once: true });
  document.addEventListener('keydown', onEsc, { once: true });
  btnOk.focus();  
  
  */ 
  
  
}


function menupos() {
 const modal = document.createElement('div');
 modal.style.cssText = `
 position:absolute;top:32px;left:50%;transform:translateX(-50%);
 background:linear-gradient(-180deg,#555,#999);padding:10px;border-radius:8px;
 width:160px;box-shadow:0 2px 10px rgba(0,0,0,.3);z-index:var(--thesimenu)
 `;
 modal.innerHTML = `
 <h3 style="margin:0 0 8px;font:14px sans;text-align:center;background:#007BFF;color:#fff;padding:4px;border-radius:4px">
 Επιλέξτε ΘΕΣΗ menu:
 </h3>
 <div style="display:grid;grid-template-columns:1fr auto 1fr;align-items:center;margin:8px 0">
 <input type="radio" name="pos" value="left" style="justify-self:start;cursor:pointer">
 <input type="radio" name="pos" value="center" style="justify-self:center;cursor:pointer" checked>
 <input type="radio" name="pos" value="right" style="justify-self:end;cursor:pointer">
 </div>
 <div style="display:flex;justify-content:center;margin:8px 0">
 <input type="radio" name="pos" value="middle" style="cursor:pointer">
 </div>
 <button id="mpOK" style="position:absolute;bottom:8px;right:8px;padding:4px 8px;font:13px sans;background:#007BFF;color:#fff;border:none;border-radius:4px;cursor:pointer">
 OK
 </button>
 `;
 document.body.append(modal);
 const apply = pos => mthesis(pos);
 apply('center');
 modal.addEventListener('click', e => {
 if (e.target.name === 'pos') apply(e.target.value);
 else if (e.target.id === 'mpOK') close();
 });
 const keyMap = {
 ArrowLeft: 'left', ArrowUp: 'center',
 ArrowRight: 'right', ArrowDown: 'middle'
 };
 function onKey(e) {
 if (e.ctrlKey || e.shiftKey || e.altKey) return;
 const pos = keyMap[e.key];
 if (pos) {
 e.preventDefault();
 const r = modal.querySelector(`input[value="${pos}"]`);
 if (r) r.checked = true, apply(pos);
 } else if (e.key === 'Enter' || e.key === 'Escape') {
 e.preventDefault(); close();
 }
 }
 document.addEventListener('keydown', onKey);
 function close() {
 document.removeEventListener('keydown', onKey);
 modal.remove();
 }
}
function offmenu(){
$('#menu').fadeOut(1000);
}
function onmenu(){
$('#menu').fadeIn(1000);
}
function resetselect() {
 if (typeof j !== 'number' || j <= 4) return;
 const limeMap = {
 48: [4, 28],
 84: [4, 40, 56],
 88: [4, 32, 60],
 64: [4, 36]
 };
 const toLime = new Set(limeMap[j] || []);
 for (let i = 4; i < j; i++) {
 const $el = $(`#select${i}`);
 const desiredColor = toLime.has(i) ? 'lime' : 'white';
 if ($el.css('color') !== desiredColor) {
 $el.prop('selectedIndex', 0).css('color', desiredColor);
 }
 }
}
function unblur(){
 $('[id^=select]').slice(0, j).css('filter', 'blur(0)');
 }
function createselect(e) {
 if (!menu1.length) {
 showAlert(
 'Δεν υπάρχει Array menu1 <br> Δεν είναι εφικτή η δημιουργία select - menu'
 );
 return;
 }
 const form = document.getElementById("form1");
 const options = menu1[e];
 const select = document.createElement("select");
 select.id = "select" + e;
 // attach click / long-press / contextmenu handlers for selects beyond index 3
 if (e > 3) {
 select.addEventListener("mousedown", evt => {
 if (evt.button === 0) {
 select.onchange = () => cal2(select.value);
 } else if (evt.button === 2 && !isMobile) {
 pin(e);
 }
 });
 if (isMobile) {
 let longPressTimeout;
 select.addEventListener("touchstart", () => {
 longPressTimeout = setTimeout(() => pin(e), 500);
 });
 select.addEventListener("touchend", () => {
 clearTimeout(longPressTimeout);
 });
 }
 select.addEventListener("contextmenu", evt => {
 evt.preventDefault();
 evt.stopPropagation();
 });
 }
 // build options fragment
 const frag = document.createDocumentFragment();
 for (let i = 0; i < options.length; i += 2) {
 const opt = document.createElement("option");
 opt.value = options[i];
 opt.textContent = options[i + 1] || "";
 // give empty-value options an initial white text
 if (!opt.value) {
 opt.style.color = "#ffffcc";
 }
 frag.appendChild(opt);
 }
 select.appendChild(frag);
 // on change: reset all selects to white & clear all option styles,
 // then highlight this select and its chosen option in yellow
 select.addEventListener("change", () => {
 // reset every dropdown in the form
 form.querySelectorAll("select").forEach(s => {
 s.style.color = "#ffffff";
 Array.from(s.options).forEach(o => {
 o.style.color = "";
 o.style.backgroundColor = "";
 });
 });
 // highlight the current select in yellow
 select.style.color = "yellow";
 // highlight the chosen option in yellow
 const chosen = select.options[select.selectedIndex];
 chosen.style.color = "yellow";
 });
 form.appendChild(select);
}
function iconsize() {
  var $selects = $('[id^="select"]').slice(0, 4);
  if ($selects.length === 0) return;
  $selects.css({
    textAlign: 'center',
    fontSize: '22px',
    background: 'rgba(80,100,120,0.5)',
    borderRadius: '0',
    transition: 'background 0.3s'
  });
  $selects.first().css('border-radius', '10px 0 0 0');
  $('#menu').css('border-radius', '0 0 10px 0');
}
function selectplat1() {
  const $window   = $(window);
  const windowW   = $window.width();
  const $menu     = $('#menu');
  const $form1    = $('#form1');
  const selectors = Array.from({ length: j }, (_, i) => `#select${i}`).join(',');
  if (windowW < 360) {
    selplatos = windowW / selectcols;
  }
  const mW = selectcols * selplatos;
  const mH = Math.ceil(j / selectcols) * selypsos;
  const $items = $(selectors);
  $items.css({ width: selplatos, height: selypsos });
  $menu.css({ width: mW, height: mH, position: 'absolute' }).show();
  $form1.css({
    width:        mW,
    height:       mH,
    overflow:     'hidden',
    position:     'relative',
    'z-index':    'var(--forma)'
  });
}
function configRji(){
 const grads = {
 rjs_: 'linear-gradient(135deg,#7F00FF,#E100FF)',
 aud_: 'linear-gradient(135deg,#99778B,#FF6A88)',
 mxu_: 'linear-gradient(135deg,#FF6A88,#3B82F6)',
 rji_: 'linear-gradient(135deg,#5DB813,#3F3D00)',
 };
 const modal = Object.assign(document.createElement('div'), {
 id: 'rji-config-modal',
 innerHTML: `
 <h3 style="margin:0 0 5px;font-size:1.25rem;color:#ffcc00"> Replace &nbsp; &nbsp; <span style="color:lime;font-size:20px">rji_</span> &nbsp; &nbsp; with: </h3>
 <div style="display:flex;justify-content:space-around;margin-top:16px">
 ${Object.keys(grads).map(ch=>`
 <button data-ch="${ch}"
 style="padding:5px 5px;width:45px;height:30px; background:${grads[ch]};color:#fff;border-radius:6px;cursor:pointer;font-size:1.25rem;transition:filter .2s,transform .1s;">
 ${ch}
 </button>
 `).join('')}
 </div> ` });
 Object.assign(modal.style, { 
 position:'absolute',
 top:'32px',
 left:'50%',
 width:'220px',
 transform:'translate(-50%, 0%)',
 background:'rgba(255, 255, 255, 0.03)',
 backdropFilter: 'blur(2px)',
 borderRadius:'12px',
 padding:'15px 5px',
 boxShadow:'4px 4px 8px rgba(0,0,0,0.5)',
 textAlign:'center',
 zIndex:'var(--soundplay)',
 color:'#eee',
  });
 modal.querySelectorAll('button').forEach(btn => {
 btn.addEventListener('mouseenter', ()=>btn.style.filter='brightness(1)');
 btn.addEventListener('mouseleave', ()=>btn.style.filter='brightness(0.8)');
 btn.addEventListener('mousedown', ()=>btn.style.transform='scale(.95)');
 btn.addEventListener('mouseup', ()=>btn.style.transform='scale(1)');
 btn.addEventListener('click', () => {
 const key = btn.dataset.ch;
 window.setrjirjs = key === 'rjs_';
 window.setrjirji = key === 'rji_';
 window.setrjiaud = key === 'aud_';
 window.setrjimxu = key === 'mxu_';
 
 // 1) Update your <option> text (and value if desired)
 const opt = document.getElementById('rgiRedir');
 if (opt) {
 opt.textContent = `Radio \u{1F4FB} Player rji_ \u{1F51C} ${key}`;
 }
 
 modal.remove();
 });
 });
 document.body.appendChild(modal);
}
function stoprji(){
 const $link1 = $('#URLink1');
 const htmlContent = $link1.html();
 if (htmlContent) {
 myradio = htmlContent;
 $link1.empty().hide();
 }
// showtrigram('trigram');
}
function showAlert(message, duration = 20000) {
 if (!document.getElementById('custom-alert-styles')) {
 const styles = `
 <style id="custom-alert-styles">
 .custom-alert {
 position: fixed;
 left: 50%; top: 50%;
 transform: translate(-50%, -50%);
 display: flex; align-items: center;
 padding: 0.5em 1em;
 background: #fff;
 border: 1px solid #ccc;
 border-radius: 1em;
 box-shadow: 0 2px 10px rgba(0,0,0,0.2);
 opacity: 0;
 transition: opacity 0.3s ease;
 z-index: var(--alerti);
 user-select: text;
 cursor: text;
 }
 .custom-alert.show { opacity: 1; }
 .custom-alert .alert-close {
 background: none;
 border: none;
 font-size: 3em;
 line-height: 1;
 margin-left: 0.5em;
 color: darkred;
 cursor: pointer;
 }
 </style>
 `;
 document.head.insertAdjacentHTML('beforeend', styles);
 }
 const alertDiv = document.createElement('div');
 alertDiv.className = 'custom-alert';
 alertDiv.innerHTML = `
 <span class="alert-message">${message}</span>
 <button class="alert-close" aria-label="Close">&times;</button>
 `;
 document.body.appendChild(alertDiv);
 requestAnimationFrame(() => alertDiv.classList.add('show'));
 const removeAlert = () => {
 clearTimeout(timeoutId);
 alertDiv.classList.remove('show');
 alertDiv.addEventListener('transitionend', () => alertDiv.remove(), { once: true });
 };
 const timeoutId = setTimeout(removeAlert, duration);
 alertDiv.addEventListener('dblclick', e => {
 e.preventDefault();
 e.stopPropagation();
 removeAlert();
 });
 alertDiv.querySelector('.alert-close').addEventListener('click', e => {
 e.stopPropagation();
 removeAlert();
 });
}
function generateYouTubeEmbed(videoId, topOffset = 0){
 // 1) build wrapper
 const wrapper = document.createElement('div');
 wrapper.className = 'full';
 Object.assign(wrapper.style, {
 position: 'absolute',
 top: `${topOffset}px`,
 left: 0,
 width: '100vw',
 height: `calc(100% - ${topOffset}px)`,
 background: 'transparent',
 overflow: 'hidden'
 });
 // 2) build iframe
 const iframe = document.createElement('iframe');
 iframe.className = 'full';
 iframe.allowFullscreen = true;
 Object.assign(iframe.style, {
 border: 'none',
 width: '100%',
 height: '100%',
 display: 'block'
 });
 // 3) prepare the inner HTML
 const innerHTML = `<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
 <style>
 html,body { margin:0; padding:0; overflow:hidden; background:#000; }
 #ytplayer { position:absolute; top:0; left:0; width:100vw; height:100vh; }
 </style>
</head>
<body>
 <div id="ytplayer"></div>
 <script src="https://www.youtube.com/iframe_api"></script>
 <script>
 function onYouTubeIframeAPIReady() {
 new YT.Player('ytplayer', {
 videoId: '${videoId}',
 playerVars: {
 autoplay: 1,
 controls: 2,
 rel: 0,
 modestbranding: 1,
 origin: '*' // adjust as needed
 },
 events: {
 onReady: e => e.target.setVolume(90),
 onStateChange: e => {
 if (e.data === YT.PlayerState.ENDED) {
 parent.postMessage({ type: 'YT_ENDED', videoId: '${videoId}' }, '*');
 }
 }
 }
 });
 }
 </script>
</body>
</html>`;
 // 4a) inject via srcdoc (supported in all modern browsers)
 iframe.srcdoc = innerHTML;
 // 5) listen for end event in parent
 window.addEventListener('message', e => {
 if (e.data && e.data.type === 'YT_ENDED' && e.data.videoId === videoId) {
 console.log('YouTube video ended!');

 }
 }, false);
 wrapper.appendChild(iframe);
 return wrapper;
}

// ----- START tseries and getmo ------
const TSRIES_CONFIG = {
  maxPagesSpan: 7,
  maxPromptSpan: 5,
  requestDelayMs: 500,
  fetchTimeoutMs: 10000
};

const fetchWithTimeout = (
  url,
  timeout = TSRIES_CONFIG.fetchTimeoutMs
) =>
  Promise.race([
    fetch(url).then(r =>
      r.ok ? r : Promise.reject(new Error('HTTP ' + r.status))
    ),
    new Promise((_, rej) =>
      setTimeout(() => rej(new Error('Fetch timeout')), timeout)
    )
  ]);

const sleep = ms => new Promise(res => setTimeout(res, ms));

async function tsries({ from, to, typ }) {
  const start = Number(from);
  const end = Number(to);
  const type = (typ || '').trim();

  if (!Number.isFinite(start) || !Number.isFinite(end) || !type) {
    throw new Error('Invalid query parameters');
  }

  if (end < start) {
    throw new Error('Invalid range: to < from');
  }

  if (end - start >= TSRIES_CONFIG.maxPagesSpan) {
    throw new Error(
      `Range too large (max ${TSRIES_CONFIG.maxPagesSpan - 1})`
    );
  }

  // Inject zebra CSS once
  if (!document.getElementById('tsries-zebra-css')) {
    const css = document.createElement('style');

    css.id = 'tsries-zebra-css';

    css.textContent = `
      pre.zebra span.zline {
        display: block;
        padding: 0 0.5rem;
      }

      pre.zebra span.zline:nth-of-type(odd) {
        background: rgba(0, 0, 100, 0.1);
        color: darkblue;
      }

      pre.zebra span.zline:nth-of-type(even) {
        background: transparent;
        color: black;
      }
    `;

    document.head.appendChild(css);
  }

  function applyZebraToPre(pre) {
    if (!pre) return;

    const lines = pre.textContent.split('\n');

    pre.innerHTML = lines
      .map(line => {
        const escaped = line
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;');

        return `<span class="zline">${escaped}</span>`;
      })
      .join('<div></div>');

    pre.classList.add('zebra');
  }

  playpic1();
  offmenu();
  cal2('aud_local/chrono.mp3');

  // Build modal HTML with a <pre> to preserve tabs
  const html = `
    <div id="tsries-content"
      style="user-select:text; color:#313852;background-color:#d1d1dc"
      onmousedown="event.stopPropagation()"
      ontouchstart="event.stopPropagation()">

      <div id="tsries-progress"
        style="color:#313852; background:#e1c1ac; font-weight:700;
        margin-bottom:3px; width:150px;">
        Loading...
      </div>

      <pre id="tsries-list"
        style="margin:0; padding:0; white-space:pre-wrap; tab-size:4;
        overflow:auto; overflow-wrap:anywhere; max-width:98vw;
        max-height:calc(100vh - 60px); font-family:monospace;
        display:none"></pre>
    </div>
  `;

  $.fancybox.open({
    src: html,
    type: 'html',
    clickSlide: false,
    clickOutside: false,

    touch: {
      vertical: false,
      momentum: false
    },

    opts: {
      baseClass: 'no-padding custom-top-zero',
      smallBtn: true,
      trapFocus: true,
      autoFocus: false,
      animationEffect: 'zoom',
      transitionEffect: 'fade',

      maxWidth: 360,
      maxHeight: $(window).height() - 20,

      mobile: {
        clickSlide: false,
        clickOutside: false,
        preventCaptionOverlap: true
      },

      afterShow: function(_, inst) {
        inst.$content.css({
          border: '1px solid blue',
          padding: '2px',
          margin: '2px'
        });

        inst.$container.css({
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          position: 'fixed'
        });
      }
    }
  });

  const progressEl = document.getElementById('tsries-progress');
  const listEl = document.getElementById('tsries-list');

  // Clear any template whitespace
  listEl.textContent = '';

  // Fetch loop
  for (let i = start; i <= end; i++) {
    progressEl.textContent = `Fetching pages ${i} – ${end}…`;

    try {
      const res = await fetchWithTimeout(
        `https://vidsrc.sh/${type}/latest/page-${i}.json`
      );

      const { result } = await res.json();

      if (Array.isArray(result)) {
        const chunk = result
          .map(v => {
            const imdbRaw = v.imdb_id?.trim() || '';

            // Για tvshows προσθέτει /tv/ πριν από το IMDb ID
            const imdb = imdbRaw
              ? type === 'tvshows'
                ? `/tv/${imdbRaw}`
                : imdbRaw
              : '';

            const title = (v.title || '')
              .replace(/["',!]/g, ' ')
              .replace(/\s+/g, ' ')
              .trim();

            return imdb || title
              ? `"${imdb}","${title}",\n`
              : '';
          })
          .join('');

        listEl.textContent += chunk;
      } else {
        console.warn('Unexpected JSON', result);
      }
    } catch (err) {
      const msg = `Error on page ${i}: ${err.message}`;

      console.error(msg, err);

      const note = document.createElement('div');

      note.style.cssText =
        'color:crimson; font-size:11px';

      note.textContent = msg;

      progressEl.after(note);
    }

    await sleep(TSRIES_CONFIG.requestDelayMs);
  }

  // Finished fetching: apply zebra but keep the pre hidden
  // Caller will show it
  applyZebraToPre(listEl);

  progressEl.textContent = `Done: pages ${start} – ${end}`;

  $('#player1').empty().off().removeData();

  // mypic = recpic;
  playpic1();

  $('#URLink').val('');
}

function getmo(mv1) {
  const f = 1;
  const t = 5; // Last new 250 entries 

  tsries({
    from: f,
    to: t,
    typ: mv1
  })
    .then(() => {
      const listEl = document.getElementById('tsries-list');

      listEl.style.display = 'block';

      resetselect();
      playpic1();
      onmenu();
    })
    .catch(err => {
      console.error('tsries failed:', err);

      showAlert(
        'Fetch failed, see console for details',
        8000
      );

      resetselect();
    });
}

// ----- END tseries and getmo ------

function AndroidFIX(){
 if (!isAndroid || !isFirefox || document.getElementById('android-fix-style')) return;
 const style = document.createElement('style');
 style.id = 'android-fix-style';
 style.textContent = `
 .fancybox-slide--iframe .fancybox-content {
 max-width: calc((100vh - 88px) * 16 / 9);
 max-height: calc(100vh - 88px);
 }
 `;
 document.head.appendChild(style);
}
function loadme(src) {
 if (typeof src !== 'string' || !src.trim()) {
 return Promise.reject(new Error('Invalid script source'));
 }

 if (loadme._player1Handler) {
 const btnmenu = document.getElementById('player1');
 if (btnmenu) {
 btnmenu.removeEventListener('click', loadme._player1Handler);
 }
 delete loadme._player1Handler;
 }
 if (!loadme._chain) loadme._chain = Promise.resolve();
 if (!loadme._preloaded) loadme._preloaded = new Set();
 const container = document.getElementById('codetemp');
 if (!container) {
 return Promise.reject(new Error('#codetemp element not found'));
 }
 if (!loadme._preloaded.has(src)) {
 const link = document.createElement('link');
 link.rel = 'preload';
 link.as = 'script';
 link.href = src;
 document.head.appendChild(link);
 loadme._preloaded.add(src);
 }
loadme._chain = loadme._chain.then(() =>
 new Promise((resolve, reject) => {
 const script = document.createElement('script');
 script.async = false;
 script.src = src;
 script.onload = () => { console.log(`Loaded script: ${src}`); resolve(); };
 script.onerror = () => {
 console.error(`Failed to load script: ${src}`);
 resolve(); // absorb error to keep chain alive
 };
 container.appendChild(script);
 })
);
 return loadme._chain;
}
function loadmenu(){
 onmenu();
 if (!$('#_loadmenu_styles').length) {
 $(`
 <style id='_loadmenu_styles'>
 .lm-container {
 display: flex;
 flex-direction: column;
 align-items: center;
 gap: 8px;
 color: #eee;
 font-family: var(--font-family);
 }
 .lm-select {
 width: 160px;
 height: 26px;
 font-size: 14px;
 padding: 4px 8px;
 background: linear-gradient(to bottom, var(--select-bg-start), var(--select-bg-end));
 color: #ffd;
 border: 1px solid #555;
 border-radius: 4px;
 }
 .lm-info {
 text-align: center;
 font-size: 12px;
 line-height: 1.4;
 color: #aaa;
 }
 .lm-modal {
 position: fixed;
 top: 35px;
 left: 5px;
 transform: translate(0%, 0%);
 background: linear-gradient(to bottom, var(--select-bg-start), var(--select-bg-end));
 padding: 16px;
 border: 1px solid #555;
 border-radius: 8px;
 z-index: 10000;
 }
 .lm-close {
 position: absolute;
 top: 4px;
 right: 4px;
 background: black;
 border: none;
 color: #eee;
 font-size: 20px;
 cursor: pointer;
 }
 </style>
 `).appendTo('head');
 }
 const $content = $(`
 <br><div class='lm-container'>Επιλέξτε απο τα υπάρχοντα μενου<br>
 <select class='lm-select' size='1'>
 <option value=''>Επιλέξτε MENU</option>
 <option value='menu.js'>\u{1F374} KENTRIKO MENU</option>
 <option value='menu_rad.js'>\u{1F4FB} RADIO</option>
 <option value='menu_tv.js'>\u{1F4FA} TV</option>
 <option value='menu_mov.js'>\u{1F3AC} ΤΑΙΝΙΕΣ</option>
 </select>
 <div class="lm-info">
 Eίτε δικό σας menu (.js)<br>
 ή αρχείο: \u{1F388} .jpg .png .gif<br>
 .txt .pdf \u{26A1} .m3u .mp3 .mp4
 </div>
 <input
 type='file'
 id='fileInput'
 accept='.js,.jpg,.png,.gif,.svg,.bmp,.txt,.pdf,.m3u,.mp3,.mp4'
 style='font-size:10px; max-width:200px; background:black; border:1px solid green'
 />
 </div><br>
 `);
 // build modal container
 $('#lm-modal').remove();
 const $modal = $(`
 <div id="lm-modal" class="lm-modal">
 <button class="lm-close">\u{274C}</button>
 </div>
 `).appendTo('body');
 $modal.append($content);
 
 // helper to close & clean up
 function closeModal() {
 $modal.remove();
 $(document).off('keydown.lmModal');
 }
 
 // close on close-button click
 $modal.find('.lm-close').on('click', closeModal);
 
 // close on Escape press
 $(document).on('keydown.lmModal', function(e) {
 if (e.key === 'Escape') {
 closeModal();
 }
 });
 
 // dropdown handler with autoclose
 $content.find('.lm-select').on('change', function() {
 if (!this.value) return;
 loadme(this.value);
 $modal.remove();
 });
 
 // file-picker handler with autoclose
 $content.find('#fileInput').on('change', function(e) {
 const file = e.target.files[0];
 if (!file) return alert('No file chosen');
 const name = file.name.toLowerCase();
 const url = URL.createObjectURL(file);
 
 if (name.endsWith('.js')) loadme(url);
 else if (name.endsWith('.dat')) loadme(url);
 else if (/\.(jpe?g|png|gif|svg|bmp)$/.test(name)) cal2('pic_' + url);
 else if (/\.(txt|pdf)$/.test(name)) cal2('dir_' + url);
 else if (name.endsWith('.m3u')) cal2('mxu_' + url);
 else if (name.endsWith('.mp3')) cal2('rji_' + url);
 else if (name.endsWith('.mp4')) cal2('vjs_' + url);
 else {
 URL.revokeObjectURL(url);
 return alert(`Unsupported file: ${file.name}`);
 }
 // revoke and close
 setTimeout(() => URL.revokeObjectURL(url), 3000);
 closeModal();
 });
}
function createframe(){
 $('#player1').html('<iframe id="tvframe" name="tvframe" src="" class="full" allowfullscreen></iframe>');
 $('#tvframe').css({
 'box-shadow': 'inset 0 0 1vw rgba(0, 0, 0, 0.8)'
 });
} 
function mthesis(rest){
 thesis = rest;
// URLI = '@';
 const pW = $('#player1').width();
 const pH = $('#player1').height();
 const mW = $('#menu').width();
 const mH = $('#menu').height();
 let left, top;
 if (rest === "left") {
 left = 0; top = 30;
 }
 else if (rest === "right") {
 left = pW - mW; top = 30;
 }
 else if (rest === "center") {
 left = (pW - mW)/2; top = 30;
 }
 else { // middle
 left = (pW - mW)/2;
 top = Math.max((pH - mH)/2, 30);
 }
 $('#menu').css({ left, top });
}
function rologi(){
 const t0 = Date.now();
 fetch('myprog.php?time')
 .then(res => res.json())
 .then(data => {
 const t1 = Date.now();
 const latency = (t1 - t0) / 2;
 const offset = (data.serverTimeMs + latency) - t1;
 const weekdays = [ 'ΚΥΡΙΑΚΗ', 'ΔΕΥΤΕΡΑ', 'ΤΡΙΤΗ', 'ΤΕΤΑΡΤΗ', 'ΠΕΜΠΤΗ', 'ΠΑΡΑΣΚΕΥΗ', 'ΣΑΒΒΑΤΟ' ];
 function update(){
 const nowCorrected = new Date(Date.now() + offset);
 const dayName = weekdays[nowCorrected.getDay()];
 const dd = String(nowCorrected.getDate()).padStart(2, '0');
 const mm = String(nowCorrected.getMonth() + 1).padStart(2, '0');
 const yyyy = nowCorrected.getFullYear();
 const hh = String(nowCorrected.getHours()).padStart(2, '0');
 const mi = String(nowCorrected.getMinutes()).padStart(2, '0');
 const ss = String(nowCorrected.getSeconds()).padStart(2, '0');
 $('#URLink').val(`${dayName}, ${dd}-${mm}-${yyyy} ${hh}:${mi}`);
 }
 update();
  // ✅ Clear after 5 seconds
        setTimeout(() => {
            $('#URLink').val('');
        }, 5000);
 })
 }
function tvdecode(URLI) {
 URLI = URLI.trim(); // Normalize whitespace
 // --- Empty input check ---
 if (URLI === '') {
 $('#player1').empty();
 URLI = '@';
 return URLI;
 }
 // --- Avoid prefix stacking ---
 if (/^[a-zA-Z0-9]{3,4}_/.test(URLI)) {
 // Already prefixed — skip normalization
 } else {
 // --- Normalize input ---
 if (URLI.startsWith('URL=')) {
 URLI = URLI.slice(4);
 }
 if (URLI.startsWith('http') && URLI.includes('youtu')) {
 URLI = 'vjs_' + URLI;
 }



 if (URLI.startsWith('tt')) {
 const matchit = URLI.match(/^t{3,}/);
 if (matchit) {
 URLI = URLI.replace(/^t{3,}/, 'tt');
 }
 URLI = 'vsr_' + URLI;
 if(notplay){alert('if tt does not play - then try: /tv/tt');notplay=false}
 }

 if (URLI.startsWith('http')) {
 if (URLI.includes('.m3u8')) {
 URLI = 'vjs_' + URLI;
 } else if (URLI.endsWith('.mp3')) {
 URLI = 'rji_' + URLI;
 }
 }
 
 
 if (URLI.startsWith('/tv/tt')) {
  URLI = 'https://vidsrc.sh/embed' + URLI;
  $('#URLink').val(URLI);
}
 
 
 if (URLI.endsWith('.txt') || URLI.endsWith('.pdf')) {
 if (URLI.length > 3 && URLI.charAt(3) !== '_') {
 URLI = 'dir_' + URLI;
 document.getElementById("URLink").value = URLI;
 }
 }
 const imdbPatterns = [
 "https://www.imdb.com/title/tt",
 "https://m.imdb.com/title/tt"
 ];
 if (imdbPatterns.some(pattern => URLI.startsWith(pattern))) {
 const match = URLI.match(/\/title\/(tt\d+)/);
 if (match) {
 URLI = 'vsr_' + match[1];
 document.getElementById("URLink").value = URLI;
 }
 }
 }
 if ( URLI == 'pako' || URLI == 'own_pako') URLI += '.html';
 // --- Extract command and argument ---
 let uri = URLI.slice(0, 4).toLowerCase();
 let rest = URLI.slice(4);
 // --- Runtime overrides ---
 if (setrjirjs && uri === 'rji_') uri = 'rjs_';
 if (setrjiaud && uri === 'rji_') uri = 'aud_';
 if (setrjimxu && uri === 'rji_') uri = 'mxu_';
 
 // --- Command dispatch ---
 // (continues...)
 switch (uri) {

case 'gmt_':{ if(rest!==''){gmt(rest)} else {gmt()}
 URLI = '@';
 break;
}

case 'prm_': {
if(rest!==''){ cal2('https://primesrc.me/embed/movie?imdb='+rest);}
 URLI = '@';
 break;
}

case 'rss_': {
$('#player1').empty().off().removeData();
stoparaxni();
stoprain();
stopPulse();
cal2('dir_prog/news.html?'+rest);
 URLI = '@';
 break;
}

case 'cav_': {
 if (rest.includes('.m3u8')) {
 // alert('cav_ does not support: .m3u8');
 cal2('vjs_'+rest);
 } else {
 stoprji();
 $('#URLink1').html('').hide();
 showtrigram('trigram');
 if (rest !== '') {
 radicon = 'stoptheradio';
 myradio1stream = rest;
 $('#URLink').val('cav_' + `${myradio1stream}`);
 $('#radiobutton').click();
 } else {
 radicon = 'playtheradio';
 myradio1stream = '';
 $('#radiobutton').click();
 }
 }
 URLI = '@';
 break;
}

case 'fan_': {
 showAlert(`<div>${rest}</div>`);
 URLI = '@';
 break;
 }
 
case 'juk/':{
 if("vjuk" !== rest.slice(0, 4)){
 	createframe(), window.open(uri + rest, "tvframe"), offmenu();
 } else {
 	cal2('./juk/' + rest)
 }
 URLI = '@';
 break;}
 
case 'rnm_':{
 runme(rest === "" ? undefined : rest);
 URLI = '@';
 break;}
 
case 'mov_':{
 cal2('dir_prog/MoviePlayer.html?' + rest);
 URLI = '@';
 break;}
 
case 'tax_': {
 const index = parseInt(rest, 10);
 if (!isNaN(index) && index >= 0 && index <= j) {
 if (confirm('Να γίνει ταξινόμηση;')) {
 tax(index); // Sorts select[index] by option text
 }
 const selectElement = document.getElementById('select' + index);
 if (selectElement) {
 selectElement.selectedIndex = 0; // Reset to label option
 }
 } else {
 console.warn(`Invalid rest value: ${rest}`);
 }
 URLI = '@';
 break;
}
 
case 'pin_':{
 rest = rest.trim();
 if(rest === ""){
 	pin();
 } else {
 	pin(parseInt(rest));
 }
 URLI = '@';
 break;}
 
case 'run_':{
 if (rest !== ""){
 const parts = rest.split(",");
 if (parts.length < 2){
 break;
 }
 const [selectIndex, optionIndexStr] = parts;
 const optionIndex = parseInt(optionIndexStr, 10);
 const selectElement = document.getElementById("select" + selectIndex);
 if (!selectElement){
 break;
 }
 const options = selectElement.options;
 if (optionIndex < 0 || optionIndex >= options.length){
 break;
 }
 const selectedValue = options[optionIndex].value;
 if (selectedValue){
 cal2(selectedValue);
 } else {
 }
 }
 URLI = '@';
 break;
}
case 'get_':{
 if(rest != ''){
 	pinax2(rest.toLowerCase())
 } else {
 	help();
 }
 URLI = '@';
 break;}
 
case 'sss_':{ $('#URLink').val(''); 
 $('#codetemp').html(`<script id="mytemp" type="text/javascript" charset="UTF-8">${rest}</script>
`);
 URLI = '@';
 break;}
 
case 'loc_':{ 
// --- inline modal που δεν αφήνει listeners μετά το κλείσιμο
 epitrepetai(rest);
 URLI = '@';
 break;}
 
case 'rji_':{ 
if($.fancybox.getInstance()){$.fancybox.close()}
radicon='playtheradio';$('#radiobutton').click(); // stops the cav_
 myradioCmd = URLI;
 const n = document.createElement("iframe");
 n.id = "rplayer";
 n.src = `${uri.slice(0, 3)}.html?${rest}
`;
 $('#URLink1').html(n);
 myradio = n;
 URLI = '@';
 break;}
 
case 'mxu_':
case 'rjs_':
case 'vjs_':{
 stoprji();
 
if(uri=='mxu_'){
 if(($.fancybox.getInstance()) && (!inbox)){$.fancybox.close();}
 }
 
 $('#player1').css('background-color', '#333333');
 URLI = uri.slice(0, 3);
 if(setrjirjs){
 	myradio = '';
 }
 if(URLI === 'rjs'){
 	URLI = 'rji';
 }
 URLI += ".html";
 if(rest !== ''){
 	URLI += "?" + rest;
 }
 break;}
 
case 'rad_':{
 offmenu();
 createframe();
 $('#tvframe').css('background','white');
 window.open('https://www.radio-browser.info/search?name=' + encodeURI(rest), 'tvframe');
 URLI = '@';
 break;}

 
case 'ipc_':{
 var xhr = new XMLHttpRequest();
 xhr.open("GET", "myprog.php?gic=" + rest, true);
 xhr.setRequestHeader("Cache-Control", "no-cache");
 xhr.onreadystatechange = function () {
 if (xhr.readyState === XMLHttpRequest.DONE) {
 if (xhr.status === 200) {
 const response = xhr.responseText;
 if (response.length < 14 || response.includes("//stream")) {
 cal2("404.html");
 } else {
 cal2("vjs_" + response);
 }
 } else {
 alert("Error No-php: " + xhr.status);
 if(xhr.status === 0){
 //cal2('own_' + rest);
 }
 }
 }
 };
 xhr.send();
 URLI = '@';
 break;
}

case 'sky_': {
  fetch("myprog.php?sky=" + encodeURIComponent(rest), {
    cache: "no-store" // Αντιστοιχεί στο Cache-Control: no-cache
  })
  .then(function(response) {
    if (!response.ok) {
      // Αν το status δεν είναι 200-299, πετάμε σφάλμα για να πάει στο catch
      throw new Error("Error No-php: " + response.status);
    }
    return response.text();
  })
  .then(function(text) {
    var url = text.trim();
    if (url) {
      cal2('own_' + url);
    } else {
      cal2("den yparxei");
    }
  })
  .catch(function(error) {
    // Διαχείριση σφαλμάτων δικτύου ή HTTP errors
    alert(error.message);
    
    // Αν το status ήταν 0 (π.χ. offline / aborted), εκτελούμε την εναλλακτική
    // (Το fetch δεν επιστρέφει status 0 άμεσα, αλλά αν αποτύχει η σύνδεση πιάνεται εδώ)
    if (!navigator.onLine || error.message.includes("0")) {
      cal2('own_' + rest);
    }
  });

  URLI = '@';
  break;
}

case 'dir_':{
 if(rest ===''){URLI='myprog.php?katalogos'}else{
 offmenu();
 createframe();
 $('#tvframe').css({
 'background': 'white',
// 'box-shadow': 'inset 0 0 1vw rgba(0, 0, 0, 0.8)'
 });
 window.open(rest, 'tvframe');
 URLI = '@';}
 break;
}

case 'cat_':{
 if(rest ===''){URLI='myprog.php?katalogos'}else{
 //offmenu();
 createframe();
 $('#tvframe').css('background','transparent');
 
 $('#tvframe').css({
 'transform': 'scale(0.5)',
 'transform-origin': 'top left',
 'width': '200%',
 'height': '200%'
});
 
 window.open(rest, 'tvframe');
 }
 URLI = '@';
 break;
}

case 'dai_':{
 URLI = 'https://geo.dailymotion.com/player.html?video='+rest;
 break;}

case 'pic_':{
 mypic = decodeURIComponent(rest);
 playpic1();
 URLI = '@';
 break;}
 
case 'aud_': {
 stoprji();
 const tpl = `
<div id="tpl">
 <style>
 #tpl { width:320px; height:210px; padding:5px; border:1px solid #000; background:rgba(200,200,200,.6); box-sizing:border-box; }
 #tpl audio, #tpl input { width:100%; display:block; }
 #speedDisplay, #pitchDisplay, #combinedDisplay {
 font:14px/1 sans-serif; color:#000; text-align:center; width:100px;
 background:#888; border:1px solid #000; user-select:none; margin-top:5px;
 }
 #resetBtn {
 background:blue; color:#fff; border:1px solid blue;
 cursor:pointer; user-select:none; padding:2px 5px; margin-top:5px;
 }
 #semitoneBtns { margin-top:8px; text-align:center; }
 #semitoneBtns button {
 width:23px; margin:2px; padding:1px; font-size:10px; cursor:pointer;
 }
 </style>
 <input id="fileLoader" type="file" accept="audio/*" /><div style="height:3px;"></div>
 <audio id="myAudio2" controls autoplay loop></audio>
 <input id="speedSlider" type="range" min="0.5" max="2" step="0.01" value="1" disabled />
 <div id="speedDisplay">Speed: 1.00×</div>
 <input id="pitchSlider" type="range" min="0.5" max="2" step="0.01" value="1" disabled />
 <div style="display:flex; justify-content:space-between; align-items:center;">
 <div id="pitchDisplay">Pitch: 1.00×</div>
 <button id="resetBtn">RESET</button>
 <div id="combinedDisplay">Rate: 1.000×</div>
 </div>
 <div id="semitoneBtns">
 ${[-5,-4,-3,-2,-1,0,1,2,3,4,5].map(n =>
 `<button data-semitone="${n}">${n>0? '+'+n : n}</button>`
 ).join('')}
 </div>
</div>
<!-- HLS.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
<script>
(function() {
 const $ = id => document.getElementById(id);
 const audio = $('myAudio2');
 const speed = $('speedSlider');
 const pitch = $('pitchSlider');
 const spD = $('speedDisplay');
 const pD = $('pitchDisplay');
 const cD = $('combinedDisplay');
 const reset = $('resetBtn');
 const semis = document.querySelectorAll('#semitoneBtns button');
 // 1) Καθορισμός πηγής
 const url = \`${rest}\`;
 if (url.includes('.m3u8') && Hls.isSupported()) {
 const hls = new Hls();
 hls.loadSource(url);
 hls.attachMedia(audio);
 } else {
 audio.src = url;
 }
 // 2) Συνάρτηση ενημέρωσης rate & displays
 function upd() {
 const s = +speed.value;
 const p = +pitch.value;
 const c = s * p;
 audio.playbackRate = c;
 spD.textContent = \`Speed: \${s.toFixed(2)}×\`;
 pD.textContent = \`Pitch: \${p.toFixed(2)}×\`;
 cD.textContent = \`Rate: \${c.toFixed(4)}×\`;
 }
 // 3) When metadata loaded — ενεργοποίηση sliders
 audio.addEventListener('loadedmetadata', () => {
 speed.disabled = false;
 pitch.disabled = false;
 // disable pitch preservation
 ['preservesPitch','mozPreservesPitch','webkitPreservesPitch']
 .forEach(prop => prop in audio && (audio[prop] = false));
 speed.addEventListener('input', upd);
 pitch.addEventListener('input', upd);
 reset.addEventListener('click', () => {
 speed.value = pitch.value = 1;
 upd();
 });
 // semitone buttons
 semis.forEach(btn => {
 btn.addEventListener('click', () => {
 const n = +btn.dataset.semitone;
 pitch.value = Math.pow(2, n/12).toFixed(2);
 upd();
 });
 });
 upd();
 });
 // 4) Load local file
 $('fileLoader').addEventListener('change', () => {
 const f = $('fileLoader').files[0];
 if (!f) return;
 const u = URL.createObjectURL(f);
 audio.loop = false;
 audio.src = u;
 audio.load();
 });
})();
</script>
`.trim();
 // εμφάνιση
 if (!inbox || /\.mp3$/.test(rest) || rest.startsWith('blob:')) {
 $('#player1').html(tpl);
 if ($('#player1').width() < 965) offmenu();
 } else {
 $.fancybox.open({
 src: 'data:text/html;charset=utf-8,' + encodeURIComponent(tpl),
 type: 'iframe',
 opts: {
 iframe: { css: { width:'336px', height:'230px' } },
 smallBtn: true,
 afterShow: (inst, cur) => {
 inst.$refs.bg.css('background','rgba(0,0,0,0.6)');
 cur.$content.css({ background:'rgba(200,200,200,0.3)', boxShadow:'none' });
 }
 }
 });
 }
 URLI = '@';
 break;
}
case 'vid_':{
 if (rest.includes('.m3u8')) {
 alert('.m3u8 >> vjs_');cal2('vjs_'+rest);
 } else {
 stoprji();
 rest = rest.replace(/:(\d+)\/$/, (_, num) => `:${num}/;`);
 rest = rest.replace(/:(\d+)$/, (_, num) => `:${num}/;`);
 var ttop = inbox ? 30 : 0;
 var myvideo = ` <div class="full" style="top: ${ttop}px; background: transparent; height: calc(100% - ${ttop}px);">
 <video class="full" src="${rest}" controls autoplay type="video/mp4"></video> </div> `;
 if(inbox){
 	$.fancybox.open(myvideo);
 } else {
 	$('#player1').html(myvideo);
 }
 }
 URLI = '@';
 break;}
 
case 'mod_':{
 stoprji();
let restNum = parseInt(rest, 10);
if (isNaN(restNum) || rest === '' || restNum > 182034 || restNum < 1) {
 rest = 'random';
} else {
 rest = restNum;
}
 URLI = "https://modarchive.org/index.php?request=view_player&query=" + rest;
$('#URLink').val(`mod_${rest}`);
 break;}
 
case 'tun_':{
 stoprji();
 URLI = "http://tunein.com/embed/player/s", "" === rest && (rest = 1e3 + Math.floor(162e3 * Math.random()), $('#URLink').val(URLI + rest + "/?autoplay=true")),
 	URLI = URLI + rest + "/?autoplay=true";
 break;}
 
case 'imdb':{
 cal2('own_https://www.imdb.com');
 URLI = '@';
 break;}
 
case 'tmdb':{
 cal2('own_https://www.tmdbsearch.com/');
 URLI = '@';
 break;}
 
case 'cov_': {
 // 1) extract “tt”+7–8 digits or just the digits
 const idMatch = rest.match(/tt\d{7,8}/) || rest.match(/\d{7,8}/);
 if (!idMatch) {
 URLI = '@';
 break;
 }
 // 2) normalize to “tt”+digits
 let imdbID = idMatch[0];
 if (!imdbID.startsWith('tt')) {
 imdbID = 'tt' + imdbID;
 }
 // 3) one-and-only-one click for playCover()
 cal2(`https://coverapi.store/embed/${imdbID}
 `);
// setTimeout(() => parent.jQuery.fancybox.close(), 3000);
// setTimeout(() => $('#plbutton').click(), 5000);
 URLI = '@';
 break;
}
case 'vsr_': {
 // a) Find “tt” + 7 or 8 digits anywhere in rest
 const idMatch = rest.match(/tt\d{7,8}/);
 // b) If we got a valid IMDb-style ID, call cal2()
 if (idMatch) {
 const imdbID = idMatch[0]; // https://vidsrc.sh/embed/movie?imdb=tt1618400
 cal2(`https://vidsrc.sh/embed/${imdbID}`);
 }
 // c) In either case, reset URLI and break
 URLI = '@';
 break;
}
case 'tid_': {
 const randomKey = tmdb_keys[Math.floor(Math.random() * tmdb_keys.length)];
 const url = `https://api.themoviedb.org/3/find/${rest}?external_source=imdb_id&api_key=${randomKey}`;
 $.ajax({ method: "GET", url })
 .done(data => {
 const keys = Object.keys(data);
 const modalStyle = `
 position:fixed;top:35px;left:5px;transform:translate(0%,0%);
 background:linear-gradient(to bottom,var(--select-bg-start),var(--select-bg-end));
 color:#eee;padding:16px;border:1px solid #555;border-radius:8px;
 z-index:10000;font-family: var(--font-family);max-width:320px;line-height:1.4;
 `;
 const closeBtn = `<button style="position:absolute;top:8px;right:8px;background:transparent;border:none;color:#eee;font-size:18px;cursor:pointer">X</button>`;
 const showModal = (type, id, extra = '') => {
 $('#simple-modal').remove();
 const $modal = $(`
 <div id="simple-modal" style="${modalStyle}">
 ${closeBtn}
 <div>
 Το IMDB.id:<br>${rest} &nbsp; (${type})<br><br>
 αντιστοιχεί σε &nbsp; TMDB.id:<br>${id}${extra}
 </div>
 </div>
 `).appendTo('body');
 $modal.find('button').on('click', () => $modal.remove());
 };
 if (data[keys[0]]?.length) showModal('movie', data[keys[0]][0].id, ''); // '&type=movie' 
 if (data[keys[2]]?.length) showModal('tv series', data[keys[2]][0].id, '&s=1&e=1');
 })
 .fail((jqXHR, textStatus, errorThrown) => {
 console.error("AJAX error:", textStatus, errorThrown);
 });
 URLI = '@';
 break;
}
 
case 'turk':{
 stoprji();
 x = 15e3 + 2 * Math.floor(120 * Math.random()),
 	cal2('rji_http://newserver.radyosfer.net:' + x + '/stream'),
 	$('#URLink').val('turk # ' + $('#URLink').val());
 URLI = '@';
 break;}
 
case 'yts_':{
 window.open('https://www.google.gr/search?q=' + rest + ' youtube');
 URLI = '@';
 break;}
 
case 'tub_':
case 'ytm_':
case 'you_':{
  stoprji();
 parent.jQuery.fancybox.close()
  if (rest == null) rest = '';
  rest = String(rest).trim();

  let id = '';

  // extract videoId from input (id / keywords / youtube url)
  if (/^[0-9A-Za-z_-]{6,}$/.test(rest)) {
    id = rest.match(/^([0-9A-Za-z_-]{6,})$/)[1];
  } else {
    const m =
      rest.match(/youtu\.be\/([0-9A-Za-z_-]{6,})/i) ||
      rest.match(/[?&]v=([0-9A-Za-z_-]{6,})/i) ||
      rest.match(/\/embed\/([0-9A-Za-z_-]{6,})/i) ||
      rest.match(/\/shorts\/([0-9A-Za-z_-]{6,})/i) ||
      rest.match(/\/live\/([0-9A-Za-z_-]{6,})/i) ||
      rest.match(/\/v\/([0-9A-Za-z_-]{6,})/i);
    if (m && m[1]) id = m[1];
  }

  // music: πάντα search (όπως το αρχικό σου)
  if (uri === "ytm_" || uri === "tub_") {
    const q = id ? id : rest;
    cal2('own_https://music.youtube.com/search?q=' + encodeURIComponent(q));
  } else { // uri === "you_"
    // αν έχουμε id -> embed, αλλιώς -> search
    if (!id) {
      cal2('own_https://www.youtube.com/results?search_query=' + encodeURIComponent(rest));
    } else {
      const ttop = 30;
      const dummy = generateYouTubeEmbed(id, ttop);
      if (inbox) $.fancybox.open(dummy);
      else $('#player1').html(dummy);
    }
  }

  URLI = '@';
  break;
}



case 'cam_':{
 window.open('https://www.earthcam.net/projects/common/js/embedviewer.php?type=h264&vid=' + rest + '.flv&w=auto','earth');
 URLI = '@';
 break;}
 
case 'box_': {
 // Normalize rest to a boolean
 if (rest === '1' || rest === 'true') {
 rest = true;
 } else if (rest === '0' || rest === 'false') {
 rest = false;
 }
 // Set inbox directly from rest
 inbox = Boolean(rest);
 // Update input field value
 $('#URLink').val('fancybox is set to: ' + inbox);
 // Update display text and color
 var o = document.getElementById('fancyboxOpt');
 o.text = '\u{7530} \u{2630} Fancybox is ' + (inbox ? 'ON' : 'OFF');
 o.style.color = inbox ? 'lime' : '#ffaa99';
 URLI = '@';
 break;
}
 
case 'rolo':{
 if(rest==='gi'){ rologi() }
 URLI = '@';
 break;
 }
 
case 'ast_':{
 if(rest == ''){
 	rest = "0436"
 };
 window.open("https://larisa.citybus.gr/el/stops/live/" + rest, "_new");
 URLI = '@';
 break;}
 
case 'mp3_':
case 'mp4_':
case 'mkv_':
case 'flv_':{
/* const prefix = uri.slice(0, 3);
 const baseUrl = 'https://www.google.gr/search?q=';
 const queryParams = ['intitle:index.of',
 	encodeURIComponent(prefix),
 	encodeURIComponent(rest), '-html', '-htm', '-php', '-asp', '-txt', '-pls'
 ];
 const searchQuery = `${baseUrl}${queryParams.join('+')}`;
 window.open(searchQuery, "_new"); */ 
 cal2('dir_y.html?q=' + encodeURIComponent(rest));
 URLI = '@';
 break;}
 
case 'ote_':
case 'οτε_': {
 if (!/^\d{10}$/.test(rest)) {
 alert("Μη έγκυρος αριθμός τηλεφώνου");
 URLI = '@';
 break;
 }
 const searchUrl = `https://www.11888.gr/antistrofh-anazhthsh-me-arithmo-thlefwnou/?phone_number=${rest}`;
 cal2('own_' + searchUrl);
 URLI = '@';
 break;
}
 
case 'map_':{
 URLI = 'https://www.google.com/maps/embed/v1/view?key=AIzaSyDe6YD3g2YniTGrlMArq88kk2WX9g8Pfx8&zoom=16&maptype=satellite&center=' + rest;
 break;}
 
case 'sat_':{
 URLI = 'https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&zoom=16&q=' + escape(rest) + '';
 break;}
 
case 'str_':{
 if(rest == ''){
 	rest = '37.968769,23.731421'
 }
 URLI = 'https://maps.google.com/?layer=c&output=svembed&cbp=,,,,&cbll=' + rest;
 break;}
 
case 'ean_':
case 'bar_':{
 var qrpage = 'https://barcode.tec-it.com/barcode.ashx?code=EAN13&qz=5&format=png&data=';
 if(/^\d{12}$/.test(rest)){
 	window.open(qrpage + rest, "_new");
 } else {
 	alert("Για EAN-13 δωστε τα πρωτα 12 ψηφία\n (προσθέτει +1 checksum ψηφιο EAN13 ) \nΕχεις δώσει " + rest.length + " ψηφία\n" + qrpage);
 }
 URLI = '@';
 break;}
 
case 'qrc_':{
 URLI = 'barcodes/qrmaker.html?' + rest;
 break;}
 
case 'qrt_':{
 cal2('own_https://barcode.orcascan.com/?fontsize=Fit&format=png&type=qrcode&data=' + rest + '&text=' + rest);
 URLI = '@';
 break;}
 
case 'azt_':{
 cal2('own_https://barcode.orcascan.com/?format=png&type=aztec&data=' + rest);
 URLI = '@';
 break;}
 
case 'dmt_':{
 cal2('own_https://barcode.orcascan.com/?fontsize=Fit&format=png&type=datamatrix&data=' + rest + '&text=' + rest);
 URLI = '@';
 break;}
 
case 'c12_':{
 cal2('own_https://barcode.orcascan.com/?fontsize=Fit&format=png&type=code128&data=' + rest + '&text=' + rest);
 URLI = '@';
 break;}
 
case 'pd4_':{
 cal2('own_https://barcode.orcascan.com/?fontsize=Fit&format=png&type=pdf417&data=' + rest + '&text=' + rest);
 URLI = '@';
 break;}
 
case 'own_': {
 if (rest == "") {
 alert('Δεν δωσατε παραμετρο');
 URLI = '@';
 break;
 }
 stoprji();
 parent.jQuery.fancybox.close();
 if (rest.length == 11) {
 rest = `https://www.youtube.com/watch?v=${rest}`;
 } else if (rest.length === 7 || rest.length === 8) {
 if (rest < ":") {
 rest = `https://coverapi.store/embed/${rest}`;
 }
 } else if (rest.startsWith("tt") || (rest.length < 7 && rest < ":")) {
 rest = `https://vidsrc.sh/embed/${rest}`;
 }
 window.open(rest, "_new" + Math.floor(50 * Math.random()));
 URLI = '@';
 break;
}
 
case 'lidl':{
 var qrpage = 'https://barcode.tec-it.com/barcode.ashx?code=QRCODE&eclevel=L&qz=5&format=png&data=';
 if(/^-?[\d.]+(?:e-?\d+)?$/.test(rest)){
 	if(rest.length !== 17){
 		alert("Ο κωδικός LIDL είναι 17 ψηφίων και στο \nτελικό QRCODE προστίθεται αυτόματα το 0\n" + "(txt με error correction L) \nΈχεις δώσει " + rest.length + " ψηφία\n" + qrpage);
 	} else {
 		window.open(qrpage + rest + "0", "_new");
 	}
 } else {
 	alert("Δεν δώσατε σωστό αριθμό");
 }
 URLI = '@';
 break;}
 
case 'masu':{
 var qrpage = 'https://barcode.tec-it.com/barcode.ashx?code=QRCODE&eclevel=Q&qz=5&format=png&data=';
 if(/^-?[\d.]+(?:e-?\d+)?$/.test(rest)){
 	if(rest.length !== 10){
 		alert("Ο κωδικός QR ΜΑΣΟΥΤΗ είναι 10 ψηφίων και στο \nτελικό QRCODE γίνεται: XE0000000000XZ\n" + "(txt με error correction Q) \nΈχεις δώσει " + rest.length + " ψηφία\n" + qrpage);
 	} else {
 		window.open(qrpage + "XE" + rest + "XZ", "_new");
 	}
 } else {
 	alert("Δεν δώσατε σωστό αριθμό");
 }
 URLI = '@';
 break;}
 
case 'abab':{
 var qrpage = 'https://barcode.tec-it.com/barcode.ashx?code=EAN13&qz=5&format=png&data=';
 if(/^\d{12}$/.test(rest)){
 	window.open(qrpage + rest, "_new");
 } else {
 	alert("Για κωδικο καρτας AB_vasil δωστε τα πρωτα 12 ψηφία\n (προσθέτει +1 checksum ψηφιο EAN13 ) \nΕχεις δώσει " + rest.length + " ψηφία\n" + qrpage);
 }
 URLI = '@';
 break;}
 
case 'gala':{
 var qrpage = 'https://barcode.tec-it.com/barcode.ashx?code=EAN13&qz=5&format=png&data=';
 if(/^\d{12}$/.test(rest)){
 	window.open(qrpage + rest, "_new");
 } else {
 	alert("Για κωδικο καρτας ΓΑΛΑΞΙΑΣ δωστε τα πρωτα 12 ψηφία\n (προσθέτει +1 checksum ψηφιο EAN13 ) \nΕχεις δώσει " + rest.length + " ψηφία\n" + qrpage);
 }
 URLI = '@';
 break;}
 
case 'nem_':{
 if(nemi != ''){
 const nemiBox = `
 <div style="padding:10px;">
 <textarea id="nemiTextArea" style="width:100%;height:200px;">${nemi}</textarea><br><br>
 <button onclick="copyNemi()">\u{1F4D3} Αντιγραφή</button>
 <button onclick="clearNemi()">\u{1F5D1}\u{FE0F} Αδειασμα Λίστας</button>
 <button onclick="$.fancybox.close()">\u{274C} Ακύρωση</button>
 </div>`;
 $.fancybox.open(nemiBox);
 }
 URLI = '@';
 break;}
 
case 'men_': {
 mthesis(rest);
 URLI = '@';
 break;
}
case 'set_':{ 
 if(rest){fws(rest);}else{fws();}
 URLI = '@';
 break;}
 
case 'eur1':{
 cal2('own_https://www.youtube.com/channel/UC8HJZNfDPoySgW9DN3YGNaA');
 URLI = '@';
 break;}
 
case 'help':
case 'info':
case 'ifo_':{
 var html = ifthetext;
 var newWindow = window.open("", "Test");
 newWindow.document.open();
 newWindow.document.write(html);
 newWindow.document.close();
 URLI = '@';
 break;}
 
case 'orca':{
 if(rest == ''){
 	var html = theorcatext;
 	var newWindow = window.open("", "Test1");
 	newWindow.document.open();
 	newWindow.document.write(html);
 	newWindow.document.close();
 	URLI = '@';
 }
 break;}
 
case 'kasp':{
 if(rest === 'ersky'){
 	$.fancybox.open('<div>' + kaspersky + '</div>');
 }
 URLI = '@';
 break;}
default:
 break;
 }
 theurl = URLI;
 return URLI;
}
// drop-area with replaced modal
function m3ublob1() {
 const modalStyle = `
 position: fixed; top: 35px; left: 5px;
 background: linear-gradient(to bottom, var(--select-bg-start), var(--select-bg-end));
 color: #fff; border: 1px solid #555; border-radius: 8px;
 padding: 12px 16px; z-index: 10000;
 font-family: var(--font-family);
 font-size: 13px;
 max-width: 260px; line-height: 1.4;
 `;
 const closeBtnStyle = `
 position: absolute; top: 3px; right: 3px;
 background: black; border: none;
 color: #fff; font-size: 20px; cursor: pointer;
 `;
 
 // If drop-area already exists: show warning modal
 if (document.getElementById('drop-area')) {
 cleanupDropArea();
 $('#m3u-modal').remove();
 
 const $msg = $(`
 <div id="m3u-modal" style="${modalStyle}">
 <button id="m3u-modal-close" style="${closeBtnStyle}">×</button>
 <div>Κλείστε το blob-DROP<br>πριν το ξανα-ανοίξετε</div>
 </div>
 `).appendTo('body');
 
 // Helper to remove modal & unbind Esc
 function closeModal() {
 $msg.remove();
 $(document).off('keydown.m3uModal');
 }
 // Close on click or Esc
 $msg.find('#m3u-modal-close').on('click', closeModal);
 $(document).on('keydown.m3uModal', e => {
 if (e.key === 'Escape') closeModal();
 });
 return;
 }
 
 // Full drop-area modal
 const html = `
 <style>
 #drop-area {
 font-size: 13px; margin: 15px 0 0 0px;
 width: 180px; height: 115px;
 border: 2px dotted yellow; border-radius: 10px;
 display: flex; color: #fff;
 align-items: center; justify-content: center;
 text-align: center; transform: rotate(-12deg);
 transition: background-color .3s;
 }
 #drop-area.hover {
 background: #e0e0e0; color: darkblue;
 border: 2px solid red;
 }
 </style>
 <br>
 <div id="drop-area">
 <br>
 Ρίξτε (DROP) \u{26A1} .m3u \u{1F3BB} .mp3 \u{1F3A5} .mp4<br>
 \u{1F4C4} .txt .pdf \u{1F3A8} image<br>
 ή URL / YouTube / .js / HTML
 </div>
 <br>
 `;
 
 $('#m3u-modal').remove();
 
 const $modal = $(`
 <div id="m3u-modal" style="${modalStyle}">
 <button id="m3u-modal-close" style="${closeBtnStyle}">\u{274C}</button>
 ${html}
 </div>
 `).appendTo('body');
 
 // Helper to remove modal, drop-area & unbind Esc
 function closeModal() {
 $('#m3u-modal').remove();
 cleanupDropArea();
 $(document).off('keydown.m3uModal');
 }
 // Close on click or Esc
 $modal.find('#m3u-modal-close').on('click', closeModal);
 $(document).on('keydown.m3uModal', e => {
 if (e.key === 'Escape') closeModal();
 });
 
 initializeDropArea();
 
 // ───────────── Helpers ─────────────
 function initializeDropArea() {
 const dropArea = document.getElementById('drop-area');
 const events = ['dragenter','dragover','dragleave','drop'];
 events.forEach(evt => {
 [dropArea, document.body].forEach(el => {
 el.addEventListener(evt, e => {
 e.preventDefault();
 e.stopPropagation();
 }, false);
 });
 });
 ['dragenter','dragover'].forEach(evt => {
 dropArea.addEventListener(evt, () => dropArea.classList.add('hover'), false);
 });
 ['dragleave','drop'].forEach(evt => {
 dropArea.addEventListener(evt, () => dropArea.classList.remove('hover'), false);
 });
 dropArea.addEventListener('drop', handleDrop, false);
 }
 
 function handleDrop(e) {
 $('#m3u-modal').remove();
 const dt = e.dataTransfer;
 const items = dt.items || [];
 const files = dt.files || [];
 
 if (items.length && items[0].kind === 'string') {
 items[0].getAsString(url => {
 if (isValidYouTubeUrl(url)) {
 cal2('vjs_' + url);
 } else {
 handleGenericUrl(url);
 }
 cleanupDropArea();
 });
 return;
 }
 
 if (!files.length) {
 cleanupDropArea();
 return;
 }
 
 const file = files[0];
 const name = file.name.toLowerCase();
 const reader = new FileReader();
 
 reader.onload = ev => {
 const content = ev.target.result;
 
 if (name.endsWith('.m3u')) {
 const blob = new Blob([content], { type: 'application/vnd.apple.mpegurl' });
 const blobUrl = URL.createObjectURL(blob);
 cal2('mxu_' + blobUrl);
 setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
 cleanupDropArea();
 return;
 }
 
 launchByExtension(name, content);
 cleanupDropArea();
 };
 
 const textExts = ['.txt','.html','.m3u','.js','.url'];
 if (textExts.some(ext => name.endsWith(ext))) {
 reader.readAsText(file);
 } else {
 reader.readAsArrayBuffer(file);
 }
 }
 
 function cleanupDropArea() {
 const area = document.getElementById('drop-area');
 if (area) area.remove();
 }
 
 function isValidYouTubeUrl(url) {
 const re = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[A-Za-z0-9_-]{11}/;
 return re.test(url);
 }
 
 function handleGenericUrl(url) {
 const imgExts = [".jpg",".gif",".png",".svg",".bmp"];
 if (!confirm('Έχετε ρίξει το URL:\n' + url + '\nαντί για YouTube.\nΘέλετε να το τρέξω;')) {
 alert("Πατήθηκε Cancel");
 return;
 }
 
 if (url.endsWith('.js')) {
 loadme(url);
 } else if (imgExts.some(ext => url.endsWith(ext))) {
 mypic = url;
 playpic1();
 } else if (url.includes('youtube.com/watch?v=')) {
 const vid = url.split('v=')[1].substr(0, 11);
 cal2('vjs_' + vid);
 } else {
 alert('Δεν είναι συμβατό');
 }
 }
 
 function launchByExtension(name, content) {
 let blobUrl;
 const makeBlob = (mime, prefix) => {
 const blob = new Blob([content], { type: mime });
 blobUrl = URL.createObjectURL(blob);
 cal2(prefix + blobUrl);
 setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
 };
 
 if (name.endsWith('.mp3')) {
 makeBlob('audio/mpeg','rji_');
 if (myradio) {
 $('#URLink1').html(myradio).show();
 }
 }
 else if (name.endsWith('.mp4')) {
 makeBlob('video/mp4','vjs_');
 }
 else if (/\.(jpe?g|png|gif)$/.test(name)) {
 const mime = name.endsWith('.png') ? 'image/png'
 : name.endsWith('.gif') ? 'image/gif'
 : 'image/jpeg';
 makeBlob(mime,'pic_');
 }
 else if (name.endsWith('.txt')) {
 makeBlob('text/plain','dir_');
 }
 else if (name.endsWith('.pdf')) {
 makeBlob('application/pdf','dir_');
 }
 else if (name.endsWith('.html')) {
 const blob = new Blob([content], { type: 'text/html' });
 blobUrl = URL.createObjectURL(blob);
 let recinbox = inbox;
 inbox = false;
 cal2(blobUrl);
 inbox = recinbox;
 setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
 }
 else if (name.endsWith('.url')) {
 const line = content.split('\n').find(l => l.startsWith('URL='));
 if (line) $('#URLink').val('mxu_' + line.slice(4));
 }
 else if (name.endsWith('.dat')) {
 loadme(URL.createObjectURL(new Blob([content])));
 }
 else if (name.endsWith('.js')) {
 const blob = new Blob([content], { type: 'application/javascript' });
 blobUrl = URL.createObjectURL(blob);
 loadme(blobUrl);
 setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
 }
 }
}


function cal2(e) {
  // guard clauses
  if (!e || (typeof e === 'string' && e.length >= 300000)) return;
  if (!e.startsWith('own_')) $('#URLink').val(e);
  const theurl = tvdecode(e);
  if (theurl === '@') return;

  const recinbox = inbox;

  let isMX = typeof e === 'string' && e.startsWith('mx') && inbox;
  const mxKeywords = ['js2m3u', 'cleanm3u', 'sortm3u', 'tube.php', 'vsembed', 'angelcam', 'ipcamlive'];
  if (setrjimxu) isMX = true;
  if (typeof e === 'string' && mxKeywords.some(k => e.includes(k))) isMX = true;

  if (inbox) {
    // ---- Fancybox v3: close previous instance(s) before opening new one ----
    const active = $.fancybox.getInstance();
    if (active && typeof active.close === 'function') {
      try { active.close(); } catch (err) {}
    }
    // Extra safety (harmless if not supported by your exact build)
    try { $.fancybox.close(); } catch (err) {}

    if (isMX) {
      const styleId = 'fb-transparent-bg';
      $('#' + styleId).remove();
      const css = `
.fancybox-bg,.fancybox__backdrop,.fancybox__overlay,.fancybox-overlay,.fancybox-bg::before,
.fancybox__backdrop::before { background: transparent !important; box-shadow: none !important; backdrop-filter: none !important; }
.fancybox__container,.fancybox-stage,.fancybox-stage__container,.fancybox-wrap,
.fancybox-inner { position: fixed !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100vh !important; margin: 0 !important; padding: 0 !important; transform: none !important; background: transparent !important; }
.fancybox-slide,.fancybox-slide__content,.fancybox-slide--iframe .fancybox-content,
.fancybox-content { position: fixed !important; top: 30px !important; left: 0 !important; width: 100vw !important; height: calc(100vh - 30px) !important; margin: 0 !important; padding: 0 !important; box-sizing: border-box !important; background: transparent !important; max-width: none !important; max-height: none !important; min-width: 0 !important; min-height: 0 !important; overflow: hidden !important; }
.fancybox-content::before,.fancybox-slide::before,
.fancybox-slide__content::before { display: none !important; content: none !important; }
.fancybox-slide--iframe .fancybox-content iframe { width: 100% !important; height: 100% !important; border: 0 !important; background: transparent !important; display: block !important; } 
.fancybox-toolbar,.fancybox-button,.fancybox-caption,.fancybox-navigation,
.fancybox-close-small { background: transparent !important; box-shadow: none !important; color: inherit !important; }
[data-fancybox-root] { background: transparent !important; }
.fancybox-button--close { margin-top: 26px !important; margin-right: 20px !important; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAMAAACtdX32AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAt1BMVEUAAAD2dHP3tLP/Xl3/MzX/R0j1k5H/OTz/Q0P/PD7/cHH/ZGb+Pj7/Pj77PDz/Tk//Pz/+BwTnAAD+////BwfOAwThDg7dAADpISDlFhXkHh3iAADiCAjcERH6FBTuAQLYAADsGxrbEBD0Hx/4PDzpMjLlKSjpCwvtWFftTk70EhLnPz/tYWDwOjv1f37zk5T46Of6JSX52dn2Ly/zyMfyq6rweHj59fXzoaH0bm3vfX7ZBAT1trVMUArqAAAAEXRSTlMArlbD5uV259zm5OXR6dTl3wGb4bUAAAF2SURBVHjaddLbcqsgFIBhkphY2+7uykpAhYhU8Gw8xJzavv9zFZLOtBfpNw7C/NwwgBBavTie6105yyfv6f/y8XHpeM7LChmzdZAF5rOk1kEd6FpHduHPEJqvsw/M8B00XM/RQlJ/fZdPxQL9i0Ss1D6u4kGpITaGfWypWJAHmwc1pJdzp+J9cdztdqWy40UNOHxFXoRTVR0A4FQK+4OuBKtNcfhwzekRPvcN9OIMl6Ixs12r2rRi18zSdARZiQ7aDjDGogTNsBDilmnawijbqoC6gb7vsYZTfypw/p3zEEac4xp0AdM0mTxOU4lzanNIMR2BMvoO5B2YUUJNGc6/c5KzAg5RDX3SAWHc5IJxzvMkumbC6dkeLEsOEDJCC2goMWx2TSaUlt0xorxuCCc8ajL+kzeEbDlNEmq3ka0ZzfSWl2ghNm/bu9421QLN/XDzh8xcKJr5VSCl1EGmpW4zKYObLPVnyFg9O+6vV+R6nms5zyuEvgAz9D1EfJT7NQAAAABJRU5ErkJggg==') !important; width: 30px !important; height: 20px !important; border: none !important; }
.fancybox-slide--iframe .fancybox-content iframe { filter: brightness(1.05) !important; }
`;
      $('<style>').attr('id', styleId).text(css).appendTo('head');
    }

    const fancyOpts = {
      src: theurl,
      type: 'iframe',
      iframe: isMX ? { attr: { allowTransparency: 'true', scrolling: 'auto' }, css: {} } : {},
      opts: {
        baseClass: 'custom-fancybox-transparent',

        afterShow(instance, current) {
          try {
            if (current && current.$content) {
              $(current.$content).css({
                width: '100vw',
                height: 'calc(100vh - 30px)',
                'max-width': 'calc((100vh - 30px) * 16/9)',
                'max-height': 'none',
                'min-width': '0',
                'min-height': '0',
                'box-sizing': 'border-box',
              });
            }

            const $iframe = (current && current.$content)
              ? $(current.$content).find('iframe').last()
              : $('iframe').last();

            if ($iframe && $iframe.length) {
              $iframe.attr('allowTransparency', 'true')
                     .attr('scrolling', 'auto')
                     .css({
                       width: '100%',
                       height: '100%',
                       border: '0',
                       display: 'block',
                       background: 'transparent'
                     });

              // ������ FIX για το zoom bug
              $iframe.on('load', function () {
                instance.update();
              });
            }
          } catch (err) {}
        },

        afterClose() {
          if (isMX) $('#fb-transparent-bg').remove();
        }
      }
    };

    // Open new instance (after close)
    // Micro-delay helps avoid rare “close/open overlap” issues
    setTimeout(() => {
      $.fancybox.open(fancyOpts);
    }, 0);

  } else {
    createframe();
    window.open(theurl, 'tvframe');
    offmenu();
  }

  inbox = recinbox;
}



{ /* -- olaa -- */ olaa = `
<select id="con1" class="change1" 
 onkeydown="if (/^(ArrowUp|ArrowDown|ArrowLeft|ArrowRight)$/.test(event.key)) event.preventDefault();"
 oncontextmenu="parent.jQuery.fancybox.close(); runme(); return false"
 onchange="conv1(this.value)">
 <option value="" style="display:none !important"></option>
<option value="sss_!($('#menu').is(':animated'))&&$('#menu').stop(true,true).fadeToggle(500)" style="color:#aaffee">\u{7530} MENU: ON/OFF (ALT-M)</option>
<option value="own_" style="color:#fff"> \u{1F517} own_ (URLink) </option>
<option id="fancyboxOpt" value="sss_inbox = !inbox;var o=document.getElementById('fancyboxOpt');o.text=' \u{7530} \u{2630} Fancybox is ' + (inbox ? 'ON' : 'OFF');o.style.color = inbox ? 'lime' : '#ffaa99';" style="color:lime;"> \u{7530} \u{2630} Fancybox is ON</option>
<option value="sss_menupos()" style="color:#aaffee"> \u{7530} MENU: ΘΕΣΗ </option>
<option id="menover" value="sss_$('#menu').css('z-index', function(_, old){var idx = parseInt(old,10) || 1100;return idx === 1100 ? 2100 : 1100;});var o=document.getElementById('menover'), z=parseInt($('#menu').css('z-index'),10); o.text = '\u{7530} MENU is ' + (z===2100 ? 'OVER' : 'BACK'); o.style.color = (z===2100 ? 'lime' : '#ffaa99');" style="color:#ffaa99">\u{7530} MENU is BACK</option>
<option value="sss_resetselect();unblur();" style="color:#aaffee"> \u{7530} \u{2630} resetselect() \u{269b} </option>
<option value="sss_toggleViewport()" style="color:#aaffee"> ZOOM 0.5 / 0.75 / 1 (mobile) </option>
<option value="sss_fondo()" style="color:#aaffee">fondo() (Alt-B)</option>
<option value="sss_cal2('set_')" style="color:#ffcc99">\u{1F3A8} set_ Φωτισμός (Alt-F)</option>
<option value="sss_epilogi()" style="color:#ff8"> \u{1F4C8} menu Stat. & ΕΠΙΛΟΓΗ ( ALT-E )</option>
<option value="sss_pin()" style="color:#ff8"> \u{1F4C8} menu ΠΙΝΑΚΑΣ: ΟΛΑ ( ALT-O )</option>
<option value="sss_loadmenu()" style="color:#ff8;background-color:black"> \u{2753} MENU or \u{1F3A8} \u{1F3B6} \u{26A1} \u{1F4C4} ( ALT-L )</option>
<option value="sss_m3ublob1()" style="color:#ff8;background-color:black"> \u{1f4a7} DROP --||--, pdf, js, ytURL ( ALT-D )</option>
<option value="sss_cal2('pack_m3u/tube.php')" style="color:#ff8;background-color:black"> \u{1f4a7} DROP tube to M3U</option>
<option id="rgiRedir" value="sss_configRji()" style="color:#8ff;font-size:14px">Radio \u{1F4FB} Redirect rji_ \u{27A1}\u{27A1} rji_</option>
<option value="vjs_" style="color:#ff8"> vjs_ ( \u{1F4FA} video / audio elements ) </option>
<option value="mxu_" style="color:#eee"> \u{1F4FB} mxu_ (playlist at right) </option>
<option value="rji_" style="color:#ddd"> \u{1F4FB} rji_ (radio inline) </option>
<option value="rjs_" style="color:#ddd"> \u{1F4FB} rjs_ (radio elements) </option>
<option value="cav_" style="color:#ddd"> \u{1F4FB} cav_ (radio inline) </option>
<option value="aud_" style="color:#ff8"> aud_ (audio) </option>
<option value="vid_" style="color:#ff8"> vid_ (video) </option>
<option value="vsr_" style="color:lime"> vsr_ (play TMDB vsr) </option>
<option value="cov_" style="color:lime"> cov_ (play IMDB cov) </option>
<option value="tid_" style="color:lime"> tid_ (convert IMDB.id to TMDB.id) </option>
<option value="sss_AndroidFIX()" style="color:#aaffee">\u{1F4F1} AndroidFIX</option>
<option value="sss_cal2('own_https://lighthouseapp.io/tools/feed-finder')" style="color:#aaffee">\u{1F552} Find RSS Feeds</option>
<option value="talkclock" style="color:#aaffee">\u{1F570}\u{FE0F}\u{1F50A} Στον επόμενο τόνο </option>` + 
(isMobile?'':'<option value="sss_mm()" style="color:#aaffee"> sss_mm() show mouse position</option>') +
`</select>
<div>
 <canvas id="trigram" width="32px" height="30px"></canvas>
 <canvas width="32px" height="30px" id="sebutton" title="Alt-G" style="position:absolute;top:0px;left:31px;"
 onclick="conv1('get_')"></canvas>
 <input id="URLink" type="text" value="" ></input> <!-- placeholder="Εδω γραφετε τις εντολες (enter)" -->
 <span id="URLink1"></span>
 <canvas width="32px" height="30px" id="radiobutton" title="Alt-A" style="position:absolute;top:0px;right:64px;" onclick="buttonplay()"></canvas>
 <canvas id="plbutton" width="32px" height="30px" title="Alt-P Alt-Q" style="position:absolute;top:0px;right:32px;"
 onclick="cal2($('#URLink').val())" 
 oncontextmenu="$('#URLink').val(''); return false"></canvas>
 <canvas id="stbutton" width="32px" height="30px" title="Alt-S" style="position:absolute; top:0px;right:0px;"
 onclick="$.fancybox.close();showtrigram('trigram'); $('#player1').empty().off().removeData(); onmenu(); resetselect(); stoprji(); $('#codetemp').empty();setTimeout(() => { window.status = 'sbhse re';}, 1000);" 
 oncontextmenu="$('#URLink').val(''); return false"></canvas>
</div>
<div id="player1" style="background:black url(${mypic}) center center/cover no-repeat fixed;box-shadow:inset 0 0 1vw rgba(0,0,0,0.8);"></div>
/* box-shadow is: x offset, y offset, blur radius, shadow color */
<div id="menu" class="menu">
 <div id="form1" class="form1"></div>
</div>
`;
}
$(document.body).append(olaa);olaa = "";
showtrigram("trigram");
showsearch("sebutton");
showplay1("radiobutton");
showplay("plbutton");
showstop("stbutton");
var myradio1 = document.createElement('audio'); // δημιουργει audio element 
myradio1.preload = 'none';
myradio1.volume = 1.0;
myradio1.loop = false;
myradio1.autoplay = false;
myradio1.style.display = 'none';
document.body.appendChild(myradio1);
/* ---- ksekinhma telikhs diadikasias ----- */ 
$('#URLink').on('keypress', e => {
 if (e.which === 13) {
 e.preventDefault();
 e.stopPropagation();
 cal2($('#URLink').val());
 }
});
$(window).on("resize", () => {
 const $win = $(window),
 windowWidth = $win.width(),
 windowHeight = $win.height(),
 $urLink = $('#URLink'),
 $urLink1 = $('#URLink1'),
 $player1 = $('#player1');
 $urLink.css('width', windowWidth - 158);
 $urLink1.css('width', $urLink.width()).hide();
 $player1.css('height', windowHeight - $player1.position().top);
 mthesis(thesis);
});
$(window).trigger('resize');


/* --- check for ? parameter where: vfile=location.href --- */
document.title = window.location.host;
var vfile = decodeURIComponent(window.location.search.slice(1) || "");
if (!vfile || vfile === location.href) vfile = "";
if (vfile !== "") cal2(vfile);
/* END check automatic command at startup */

/* -----keimena και Εφαρμογές ----- */ 


{ var kaspersky = `
KASPERSKY:<br>
1. Πατάω αριστερά στη στήλη της καρτέλας kaspersky <br>
 (όπου εμφανίζεται το .... email μας).<br>
2. Πατάω δεξιά το [→] και καταργείται ο λογαριασμός.<br>
3. Θα εμφανιστεί μήνυμα «Σύνδεση για επαναφορά συνδρομής»
 και κλείνω τελείως την καρτέλα και κάτω δεξιά στη μπάρα 
 κάνοντας δεξί-κλικ στο εικονίδιο Kaspersky → Έξοδος.<br>
4. Από StartMenu → Programs ανοίγω πάλι το Kaspersky. <br>
5. Όταν ζητήσει «Σύνδεση για ενεργοποίηση δωρεάν προστασίας» 
 δίνω ένα αλλο email.<br>
6. Επιβεβαιώνω περιοχή:<br> Ελλάδα → Επιβεβαίωση → Δημιουργία → Αποδοχή.<br>
7. Στην πράσινη στήλη λεει «Kaspersky Standard» και <br>
( πρεπει να πατησετε αρνηση για να εχετε ξανά 365 μέρες δωρεάν).<br>
`;
}
{var ifthetext = `${keimstart}
<style>
 :root {
 --bg: #ffffff;
 --fg: #222222;
 --muted-bg: #f9f9f9;
 --accent: #217ca3;
 --radius: 6px;
 --gap: 0.75rem;
 --font: 1rem/1.5 Arial, sans-serif;
 }
 body {
 margin: 2px;
 background: var(--bg);
 color: var(--fg);
 font: var(--font);
 }
 .help-panel {
 width: 355px;
 max-width: 100%;
 padding: var(--gap);
 background: var(--bg);
 border: 1px solid #ccc;
 border-radius: var(--radius);
 box-shadow: 0 2px 6px rgba(0,0,0,0.1);
 overflow-y: auto;
 -webkit-overflow-scrolling: touch;
 }
 .help-panel details {
 margin-bottom: var(--gap);
 }
 .help-panel summary {
 cursor: pointer;
 font-weight: bold;
 color: var(--accent);
 margin-bottom: 0.5em;
 list-style: none;
 }
 .grid-keys,
 .grid-cmds {
 display: grid;
 grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
 gap: 0.5em;
 margin-top: 0.5em;
 }
 kbd {
 background: var(--muted-bg);
 border: 1px solid #bbb;
 border-radius: 3px;
 padding: 0.1em 0.4em;
 font-family: monospace;
 font-size: 0.9em;
 }
 pre {
 background: var(--muted-bg);
 padding: var(--gap);
 border-radius: var(--radius);
 overflow-x: auto;
 font-family: monospace;
 margin: 0 0 var(--gap);
 }
 .copy-btn {
 display: inline-block;
 padding: 0.4em 0.8em;
 background: var(--accent);
 color: #fff;
 border: none;
 border-radius: var(--radius);
 cursor: pointer;
 font-size: 0.9rem;
 }
 .copy-btn:active {
 background: #185f7c;
 }
</style>
 <style>
 .bold { font-weight: bold; }
 body{margin:2px}
 table.zebra tr:nth-child(odd) {
 background-color: #f9f9f9;
 }
 table.zebra tr:nth-child(even) {
 background-color: #ffffff;
 }
 table.zebra td:hover {
 background-color: #ffff99;
 }
 </style>
<div class="help-panel">
 <details open>
 <summary>Άνοιγμα &amp; Κλείσιμο Βοήθειας</summary>
 <kbd>Alt + H</kbd> ανοίγει το help.<br>
 Εναλλακτικά: κενή μπάρα + μεγενθυντικος φακος.<br>
 Κλείνει με <kbd>Ctrl + W</kbd><hr>
 </details>
 <details>
 <summary>Συντομεύσεις Πληκτρολογίου:</summary>
 <div class="grid-keys">
 <div><kbd>Alt + D</kbd> Dropbox Upload</div>
 <div><kbd>Alt + L</kbd> Load/Upload</div>
 <div><kbd>Alt + K</kbd> Κεντρικό</div><div></div>
 <div><kbd>Alt + R</kbd> Radio Menu</div><div></div>
 <div><kbd>Alt + T</kbd> TV Menu</div><div></div>
 <div><kbd>Alt + W</kbd> Movies Menu</div><div></div>
 <div><kbd>Alt + O</kbd> Όλα Pinakas</div>
 <div><kbd>Alt + E</kbd> Επιλογή</div>
 <div><kbd>Alt + X</kbd> Files DIR</div><div></div>
 <div><kbd>Alt + S</kbd> Stop Bar</div>
 <div><kbd>Alt + P</kbd> Play Black Bar</div>
 <div><kbd>Alt + A</kbd> Audio Radiobutton</div>
 <div><kbd>Alt + C</kbd> Clean Black Bar</div>
 <div><kbd>Alt + M</kbd> Menu On/Off</div>
 <div><kbd>Alt + G</kbd> Get Search</div>
 <div><kbd>Alt + B</kbd> Background Change</div><div></div>
 </div><hr>
 </details>
 <details>
 <summary>Program functions USED:</summary>
<table>
<tr><td colspan="2">Τρεχετε οποιαδηποτε function ως εξης:<br>sss_tadefunction()</td></tr>
<tr><td>help()</td><td>Αυτή εδώ η βοήθεια</td></tr>
<tr><td>toggleViewport()</td><td>Ζοομ για κινητο</td></tr>
<tr><td>drawCanvas()</td><td>σχεδιαζει πανω σε εικονιδιο</td></tr>
<tr><td>showtrigram()</td><td>σχεδιαζει trigram εικονιδιο</td></tr>
<tr><td>showsearch()</td><td>αναζητηση</td></tr>
<tr><td>showplay1()</td><td>radio icon</td></tr>
<tr><td>showpause1()</td><td>pause radio icon</td></tr>
<tr><td>showplay()</td><td>play icon</td></tr>
<tr><td>showpause()</td><td>pasue play icon</td></tr>
<tr><td>showstop()</td><td>stop icon</td></tr>
<tr><td>runme()</td><td>τυχαια εκτελεση</td></tr>
<tr><td>conv1()</td><td>μετατροπη Players & helpers</td></tr>
<tr><td>buttonplay()</td><td>play sto radio icon</td></tr>
<tr><td>playpic1()</td><td>mypic ως ταπετσαρια</td></tr>
<tr><td>fws()</td><td>φωτισμος αντικειμενων</td></tr>
<tr><td>filterTable()</td><td>φιλτρο πινακα αναζητησης</td></tr>
<tr><td>pinax2()</td><td></td></tr>
<tr><td>epilogi()</td><td>προβολη στατιστικων & επιλογη cell</td></tr>
<tr><td>pin(e)</td><td>select(s) σε πινακα</td></tr>
<tr><td>tax()</td><td>sort select</td></tr>
<tr><td>codex()</td><td></td></tr>
<tr><td>titlex()</td><td>for blacklist</td></tr>
<tr><td>copyNemi()</td><td>for blacklist</td></tr>
<tr><td>clearNemi()</td><td>for blacklist</td></tr>
<tr><td>menupos()</td><td>θεση μενου</td></tr>
<tr><td>offmenu()</td><td>κρυψιμο μενου</td></tr>
<tr><td>onmenu()</td><td>επαναφορα μενου</td></tr>
<tr><td>resetselect()</td><td>μηδενισμος select σε αρχικο</td></tr>
<tr><td>unblur()</td><td>ξεθολωμα</td></tr>
<tr><td>createselect()</td><td>δημιουργια select cell απο πινακα js</td></tr>
<tr><td>iconsize()</td><td>ρυθμισεις διαστασεις</td></tr>
<tr><td>selectplat1()</td><td></td></tr>
<tr><td>configRji()</td><td>redirect ραδιο player</td></tr>
<tr><td>stoprji()</td><td>stop playing rji</td></tr>
<tr><td>showAlert()</td><td>html alert</td></tr>
<tr><td>generateYouTubeEmbed()</td><td>embed youtube id</td></tr>
<tr><td>tsries()</td><td>json (vidsrc.sh) vidsrc to paper & js</td></tr>
<tr><td>getmo()</td><td>json number of pages and type</td></tr>
<tr><td>sorting()</td><td>sort menu-mov.js menu1[]</td></tr>
<tr><td>AndroidFIX()</td><td>firefox android width</td></tr>
<tr><td>loadme()</td><td>Load js data menu</td></tr>
<tr><td>loadmenu()</td><td>Load predefined menu</td></tr>
<tr><td>createframe()</td><td>create frame tvplayer for player1</td></tr>
<tr><td>mthesis()</td><td>θεση μενου</td></tr>
<tr><td>rologi()</td><td>Get Time</td></tr>
<tr><td>tvdecode()</td><td>commands for bar: πχ pic_eikona</td></tr>
<tr><td>m3ublob1()</td><td>Users Drop Box </td></tr>
<tr><td>cal2()</td><td>run tvdecode commands</td></tr>
<tr><td>zte()</td><td>zte unlock</td></tr>
<tr><td>dtmf()</td><td>dtml beeper</td></tr>
<tr><td>freq()</td><td>freq generator</td></tr>
<tr><td>ora()</td><td>DOS time set</td></tr>
<tr><td>colorfind()</td><td>Find color of pixel in picture</td></tr>
<tr><td>paint1()</td><td>paintbrush</td></tr>
<tr><td>star1()</td><td>create star graph</td></tr>
<tr><td>flower1()</td><td>create flower graph</td></tr>
<tr><td>kleftichu()</td><td>notepad tichu</td></tr>
<tr><td>xlm3u()</td><td>excel to m3u</td></tr>
<tr><td>m3xls()</td><td>m3u to excel</td></tr>
<tr><td>ExcelViewer()</td><td>Excel Viewer in html</td></tr>
<tr><td>magicsquare()</td><td>game</td></tr>
<tr><td>sudoku1()</td><td>sudocu killer</td></tr>
<tr><td>araxni()</td><td>arachnoid effect</td></tr>
<tr><td>stoparaxni()</td><td>stop arachnoid</td></tr>
<tr><td>startWaves()</td><td>sea waves sound</td></tr>
<tr><td>stopWaves()</td><td>stop waves</td></tr>
<tr><td>startrain()</td><td>icon rain reverse</td></tr>
<tr><td>stoprain()</td><td>stop icon rain</td></tr>
<tr><td>mm()</td><td>mouse coords (pc only)</td></tr></table>
<style>
 table {
 border-collapse: collapse;
 width: 100%;
 }
 th, td {
 padding: 8px;
 border: 1px solid #ccc;
 }
 tbody tr:nth-child(even) {
 background-color: #f2f2f2;
 }
</style><hr>
</details>
<details>
 <summary>Ανανέωση Kaspersky free</summary>
 ${kaspersky} 
<hr>
</details>
 
 <details>
 <summary>Οδηγίες Ασφαλείας</summary>
 <ul>
 <li>Δείτε τα σχετικά με Kaspersky Free</li>
 <li>Δεν χρησιμοποιούμε δικά μας cookies ούτε καταγράφουμε επισκέψεις.</li>
 <li>Προτείνουμε Firefox + uBlock Origin.</li>
 <li> είτε Ublock Origin Lite σε CHROME</li>
 <li>Για κινητο: Firefox → Επεκτάσεις → εγκαταστήστε ublockorigin.</li>
 </ul>
 </details>
 <details>
 <summary>ΜΠΟΡΕΙΤΕ ΝΑ ... <br></summary>
(κατεβασετε το site: μαυρη μπαρα: www.zip και enter )<br>
( ΔΕΙΤΕ περιεχομενα του site, γράψτε στην μπαρα: dir_ και enter )<br>
( στήσετε τοπικο server πχ κατεβαστε το UNIFORM SERVER )<br>
( φτιάξετε δωρεαν site στο infinityfree.com )<br>
( θα μπορουσατε να φτιάξετε και να χρησιμοποιησετε για εγγραφη: outlook.com )
</details>
 <details>
 <summary>Κατέβασμα &amp; Ανέβασμα Site</summary>
 <p>Μαύρη μπάρα: <code>www.zip</code> + Enter για zip πακέτο.</p>
 <p>Τρέχει από <code>index.html</code>. Τοπικά: Uniform Server ή InfinityFree.</p>
 <ol>
 <li>Φτιάξτε email στο protonmail.</li>
 <li>Εγγραφείτε στο InfinityFree, ενεργοποιήστε λογαριασμό.</li>
 <li>Με FTP (π.χ. FileZilla) στείλτε τα αρχεία στο ftp://ftpupload.net.</li>
 </ol>
 <br>
 Αν θελετε αυτη εδω την ιστοσελιδα σε πακετο, γραψτε στη μαυρη μπαρα: www.zip <br>
και πατηστε enter και κατεβαινει ολοκληρη ζιπαρισμενη.<br>
Αφου την ξεζιπάρετε σε φακελο, τρεχει απο το index.html<br>
Για να λειτουργήσουν τα πάντα, καλύτερα κατεβαστε και εγκαταστηστε UNIFORM SERVER ή 
 φτιάξτε δική σας σελιδα online και φορτωστε τα εκει.
----------------<br>
Πώς μπορείτε να φτιάξετε δική σας ιστοσελιδα,<br>
( Το αρχικο αρχειο πρεπει να ειναι το index.html ),<br>
και να την ανεβασετε δωρεαν στο ιντερνετ:<br>
<br>
Πηγαινετε στο w3cschools, μαθαίνετε HTML,<br>
Πηγαίνετε στο protonmail.com και φτιάχνετε ενα email:<br>
με ..... ΣΤΟΙΧΕΙΑ.<br>
Εχοντας αυτο το email, Πηγαινετε στο infinityfree.com<br>
και κάνετε εγγραφη με αυτο.<br>
Σας ερχεται email επιβεβαίωσης, ενεργοποίησης.<br>
Τελείωσε η εγγραφη, οσον αφορα το email .... ξερετε τι να το κανετε.<br>
<br>
Μετα την επιβεβαιωση εγγραφης στο infinityfree.com , κανετε login,
και εχετε στη διαθεση σας να φτιαξετε μεχρι 3 domain.<br>
Το καθε domain εχει:<br>
 ftp: ftpupload.net<br>
 username: if0.....<br>
 password: .......<br>
Εχοντας αυτα τα στοιχεια, χρησιμοποιείτε πχ το filezilla για να ανεβασετε την σελιδα σας.
Στο infinityfree επισης εχετε control panel οπου μπορειτε:<br>
Να κανετε subdomain, να αλαξετε κωδικο κλπ. , να κανετε redirects κλπ.<br>
Την ιστοσελιδα σας ( κι αν δεν την ανεβασετε) μπορειτε να την χρησιμοποιησετε 
 με το προγραμμα: uniform server με το οποιο μπορειτε να την τρεχετε σε localhost.<br>
<hr>
 </details>
 <details>
 <summary>ΔΙΑΤΑΞΗ ΣΕΛΙΔΑΣ:</summary>
Trigram [Ξ] , [search] (sebutton), ΜΠΑΡΑ (URLink),<br>
 κρυφή μπάρα (URLink1), radiobutton, PLAY (plbutton), STOP<br>
player1, ( και απο πάνω βγαίνει popup funcybox εφοσον<br>
 εχουμε inbox=true ( ειναι προεπιλεγμενο αρχικα ),<br>
 αλλοιώς αν inbox=false παιζει μεσα στο player1 ).<br>
Επίσης υπαρχει εντολη own_REST με την οποια παιζει<br>
 σε νεο παραθυρο το REST.<br>
menu > form1 > select0 ~ j<br>
ΕΠΙΣΗΣ υπαρχουν διάφορα popup παραθυρα ( για αλλαγη φοντου κλπ )<br>
<hr>
</details>

 <details>
 <summary>ΠΕΡΙ ΤΑΙΝΙΩΝ ... <br></summary>
<pre>
Στη σελιδα cloudflare
https://1.1.1.1
---
πχ windows, βαζουμε την εφαρμογη: Cloudflare_Warp.
Μετα την εγκατασταση, οταν το τρεχουμε εχει
 ενα εικονιδιο συνεφακι κατω στη μπαρα.
Αν το κανουμε ON , ενεργοποιει ενα ειδος VPN 
και οι αναζητησεις μας στο ιντερνετ πανε μεσω WARP 
---
Σελιδα για δοκιμη: https://1.1.1.1/help
---
Πρεπει να λεει Connected to 1.1.1.1
using dns over WARP:   Yes
-----------------
Σχετικα με IMDB:
Καθε ταινια ειτε σειρα εχει εναν κωδικο  IMDB_id
κατι τετοιο:   tt12345678
---
Σχετικα με TMDB: 
Καθε ταινια ειτε σειρα εχει εναν κωδικο TMDB_id
κατι τετοιο:   12345
---
Στο imdb ειτε στο tmdb αναζητουμε 
τον κωδικο μιας ταινιας.
---
Πως την βλεπουμε: Προτεινεται WARP ανοιχτο.
---
Για να ισχυει το WARP (yes) πρεπει ο firefox να εχει
 ρυθμισεις ασφαλεια - (*) προεπιλεγμενη προστασια.
Ενω χωρις το warp προτεινεται να λεει: 
 ρυθμισεις ασφαλεια - μεγιστη προστασια cloudflare.
---
Για αποφυγη διαφημισεων πρεπει να εχουμε
 Ublockorigin 
 ειτε ublockorigin lite ( safari, chrome κλπ )
---

Όλες οι ταινίες >>> <a href="https://vidsrc.sh/" target="_new">https://vidsrc.sh/</a>

Διαβαστε το <a href="https://vidsrc.sh/vidsrc/docs/" target="_new">API</a> στο μενου της σελιδας
 το οποιο πρακτικα συντομευεται στο εξης:

για movies: https://vidsrc.sh/embed/tt  +  IMDBNOYMERO
για σειρες: https://vidsrc.sh/embed/tv/tt  +  IMDBNOYMERO
ειτε 
https://vidsrc.sh/embed/ + TMDBNUMERO

Ας απλοποιησουμε τα πραγματα οσο ειναι δυνατον:

FIREFOX - ΠΡΟΒΟΛΗ - ΓΡΑΜΜΕΣ ΕΡΓΑΛΕΙΩΝ

    ΓΡΑΜΜΗ ΣΕΛΙΔΟΔΕΙΚΤΩΝ - ΕΜΦΑΝΙΣΗ ΠΑΝΤΑ
    ΔΕΞΙ ΚΛΙΚ ΣΤΗ ΓΡΑΜΜΗ ΣΕΛΙΔΟΔΕΙΚΤΩΝ,
    ΝΕΟΣ ΣΕΛΙΔΟΔΕΙΚΤΗΣ
    ΟΝΟΜΑ: IMDB_movie_PLAYER
URL:
</pre>
javascript:(()=>{const m=location.href.match(/(tt\d+)/);if(m)open('https://vidsrc.sh/embed/'+m[1],'_blank')})();

<br><br>
αν το open δεν λειτουργει για popup στο κινητο, χρησιμοποιήστε το εξης:<br>
javascript:(()=>{const m=location.href.match(/(tt\d+)/);if(m)location.href='https://vidsrc.sh/embed/'+m[1];})();
<br><br>(ομως θα ανοιγει στην ιδια καρτέλα)<br>
ΑΝΤΙΣΤΟΙΧΑ:  ΔΕΞΙ ΚΛΙΚ ΣΤΗΝ ΓΡΑΜΜΗ ΣΕΛΙΔΟΔΕΙΚΤΩΝ ,<br>
(ΑΛΛΟΣ) ΝΕΟΣ ΣΕΛΙΔΟΔΕΙΚΤΗΣ:<br>
ONOMA: TMDB_PLAYER<br>
URL: javascript:(()=>{const m=location.href.match(/themoviedb\.org\/(?:movie|tv)\/(\d+)/);if(m)open('https://vidsrc.sh/embed/'+m[1],'_blank')})();
<br><br><br>
ΓΙΑ ΑΝΑΖΗΤΗΣΗ IMDB: ΠΑΜΕ ΣΤΗ ΣΕΛΙΔΑ IMDB<br>
ΓΙΑ ΑΝΑΖΗΤΗΣΗ TMDB ΠΑΜΕ ΣΤΗ ΣΕΛΙΔΑ TMDB<br>
<br>
ΑΦΟΥ ΕΠΙΛΕΞΟΥΜΕ και ανοιξουμε  ΜΙΑ ΤΑΙΝΙΑ (trailer - ΠΛΗΡΟΦΟΡΙΕΣ ΔΕΙΧΝΕΙ),<br>
ΠΑΤΑΜΕ ΤΟΝ ΑΝΤΙΣΤΟΙΧΟ ΣΕΛΙΔΟΔΕΙΚΤΗ ΠΟΥ ΚΑΝΑΜΕ.<br><br>
ΤΙ ΚΑΝΕΙ ΑΥΤΟΣ Ο ΣΕΛΙΔΟΔΕΙΚΤΗΣ:<br>
ΑΠΟ ΤΗΝ ΤΡΕΧΟΥΣΑ ΔΙΕΥΘΥΝΣΗ<br>
(ΤΗΣ ΤΑΙΝΙΑΣ ΣΤΟ IMDB ΕΙΤΕ TMDB)<br>
ΚΡΑΤΑΕΙ ΤΟ ID ΚΩΔΙΚΟ ΚΑΙ ΑΝΟΙΓΕΙ ΜΙΑ ΝΕΑ ΚΑΡΤΕΛΑ<br>
ΜΕ URL ΤΟ (vidsrc.sh) VIDSRC + ΤΟ ID ΚΑΙ ΒΛΕΠΕΤΕ ...<br>
----------
Εναλλακτικος αυτοματος player για TV_series imdb:<br>
    ΔΕΞΙ ΚΛΙΚ ΣΤΗ ΓΡΑΜΜΗ ΣΕΛΙΔΟΔΕΙΚΤΩΝ,<br>
    ΝΕΟΣ ΣΕΛΙΔΟΔΕΙΚΤΗΣ<br>
    ΟΝΟΜΑ: IMDB_tv_PLAYER<br>
URL:<br>
javascript:(()=>{const m=location.href.match(/(tt\d+)/);if(m)open('https://vidsrc.sh/embed/tv/'+m[1],'_blank')})();
<br><br>
αν το open δεν λειτουργει για popup στο κινητο, χρησιμοποιήστε το εξης:<br>
javascript:(()=>{const m=location.href.match(/(tt\d+)/);if(m)location.href='https://vidsrc.sh/embed/tv/'+m[1];})();
<br><br>(ομως θα ανοιγει στην ιδια καρτέλα)<br>
----------
<pre>
ΓΙΑ ΠΙΟ ΠΡΟΧΩΡΗΜΕΝΑ ΠΡΑΓΜΑΤΑ:
ΧΡΗΣΙΜΟΠΟΙΗΣΤΕ ΤΟ MoviePlayer.html
ΣΤΟΝ ΦΑΚΕΛΟ <a href="prog" target="_new">prog</a> εδώ δείτε το:  <a href="prog/MoviePlayer.html" target="dm1">MoviePlayer.html</a>
προτείνεται να το κατεβάσετε καλύτερα.
αντί να το τρέχετε κάθε φορά από το site.
download: <a href="prog/MoviePlayer.html" download>MoviePlayer.html</a>
</pre>
<hr>
</details>
 <details>
 <summary>ΙΣΤΟΣΕΛΙΔΑ - ΓΕΝΙΚΑ ΠΩΣ ΛΕΙΤΟΥΡΓΕΙ:<br></summary>
Τρεχει το index.html<br>
Αφαιρει την παραμετρο i=.. αν το site ειναι στο infinityfree<br>
Δηλώνει εικονίδιο ( ισως λειτουργήσει ), <br>
CSS ρυθμισεις για: , fancybox , και custom css αυτου εδω του site.<br>
(fancybox ειναι αυτο που προβάλει παραθυρο με σκιά πάνω απο την σελιδα.)<br>
Δηλώνει βοηθητικο χώρο: codetemp <br>
Φορτώνει javascript για jquery , messagbox , fancybox<br>
Φορτώνει code.js το οποιο δημιουργει το site μεσα στο html-body με την χρηση του olaa<br>
Αν υπαρχει ?ταδε στο αρχικο URL , εκτελει το ταδε.<br>
Φορτώνει αρχικο κεντρικο menu<br>
To κεντρικο και καθε αλλο menu εδω, εχει στο επανω μερος 4 εικονιδια αλλαγης μενου.<br><br>
Trigram: περιεχει βοηθητικές εντολες & εντολες αντικαταστασης εντολων.<br>
Μαυρη μπαρα: εκει δινει ο χρηστης ή τα λινκ της σελιδας εντολες ( πχ players, σελιδες ).<br>
Κουμπι play ( για εντολες cav_AUDIO ), Κουμπι play ( πρασινο) για υπολοιπες εντολες,<br>
Κουμπί stop , ( επόμενο κατω απο το το κουμπι stop , για stop fancybox ).<br>
Εντολές δίνετε είτε απο τα menu ειτε απευθειας στη μαύρη μπάρα.
Οι εντολες ειναι 3 grammata , κατω παυλα , παραμετρος. πχ aud_local/chrono.mp3<br>
Επισης στη μαυρη μπαρα μπορειτε να γράψετε link αλλων σελιδων (σκέτα ή με own_ μπροστά) και παίζουν εντος.
( Tα link των αλλων σελιδων εχουν νοημα αν τα ενσωματωσετε σε menu ).<br>
( τα αρχεια μενου ειναι τα: menu.js, ... κλπ )<br>
Υπαρχουν 3 θεσεις προβολης του αποτελεσματος:<br>
(a) μεσα στη σελιδα player1<br>
(b) σε fancybox<br>
(c) εκτος σελιδας<br>
Αν inbox==false εντος σελιδας , inbox==true σε fancybox , own_LINK σε παραθυρο.<br>
<br>
Το URLink1 είναι ένα κρυφο div και αφορα το rji_TADERADIO<br>
 και rjs_TADERADIO.
Οταν φορτωνει η σελιδα, φορτωνει το μενου menu.js<br>
 ( το οποίο δημιουργει τα select του menu),<br>
αλλαζει φοντο mypic.jpg στο #player1,<br>
ελέγχει αν στην γραμμή διευθύνσεων υπάρχει<br>
 παραμετρος ?tadeparametros και την εκτελει.<br>
----<br>
Η μαύρη μπάρα επάνω ειναι για εκτέλεση εντολών (xyz_TADE)<br>
 και για ενδειξη τι παίζει τωρα.<br>
Επιλέγοντας κάτι, παίζει στην περιοχη player1 (inbox=false)<br>
 ειτε popup fancybox (inbox=true) ειτε own ( εξωτερικα ).<br>
Στην μαυρη μπάρα μπορειτε να δωσετε εντολη: box_false<br>
 ειτε box_true και ετσι παιρνει τιμη το inbox.<br>
Αν θελατε να χρησιμοποιήσετε άμεσα εντολη javascript<br>
 θα μπορουσατε να γραψετε στη μαυρη μπαρα sss_inbox=false<br>
( και εντερ είτε πατηστε plbutton ) δηλώνετε ετσι ότι<br>
 οι επομενες εντολες θα παιζουν στο player1 μεσα.<br>
----<br>
Στην πρωτη γραμμη του μενου υπαρχουν 4 εικονιδια<br>
 που αλλαζουν το μενου σε:<br>
 home = menu.js, radio = menu_rad.js , tv = menu_tv.js , movies = menu_mov.js<br>
 Εικονίδιο Home, επιστρεφετε στο κεντρικο<br>
Επίσης απο το Trigram μπορειτε να επιλεξετε ? MENU<br>
 για αλλαγη μενου, ειτε DROP file και να ριξετε μεσα <br>
 δικο σας μενου px mymenu.js ( αν φτιαξετε ).<br>
----<br>
Στην μαυρη μπάρα μπορειτε να δωσετε ειτε ολοκληρο<br>
 url link ειτε XYZ_ταδε , οπου xyz_ εντολη απο τις διαθεσιμες.<br>
( Δειτε διαθεσιμες εντολες ). Οι εντολες ειναι συντομογραφιες<br>
 πρωτου μερους του URL για μικροτερα data files <br>
και για ευκολοτερη απομνημονευση <br>
 ( πχ vjs_tadevideo αντι vjs.html?tadevideo ).<br>
----<br>
kentriko menu - HELP - DIR είτε (Alt-X) βλέπεις τα περιεχόμενα του site 
 σε μορφη καταλογου, μπορειτε να σωσετε αρχεια με δεξι κλικ.<br>
Επίσης το trigram παρεχει εναλλαγη εντολων στο ιδιο url,<br>
πχ vjs_TADEVIDEO γινεται mxu_TADEVIDEO<br>
(για να μην πληκτρολογειτε την αλλαγη στην μπαρα ).<br>
----<br>
Στο trigram (Ξ) εχετε διαθεσιμο: αλλαγη μενου , drop file ...<br>
Με το drop file μπορειτε να φορτωνετε (τοπικα)<br>
 δικο σας αρχειο (ταπετσαρια, txt, pdf, tade.js)<br>
 και να το βλεπετε.<br></span>
 ----<br>
</details><hr>
 <details>
 <summary>Εντολές για τη Μαύρη Μπάρα</summary>
<br>
 <!-- Commands Table -->
 <table class="zebra" style="width:360px; border-collapse: collapse;">
 
 ${(() => {
 const b = (text) => `<span class="bold">${text}</span>`;
 var commands = [
 "ΕΝΤΟΛΕΣ ΓΙΑ ΜΑΥΡΗ ΜΠΑΡΑ",
 "αν αρχιζει απο " + b("tt"),
 "αν αρχιζει απο " + b("http") + " και<br> τελειωνει σε " + b(".m3u8") + " ή σε " + b(".mp3"),
 "αν τελειωνει σε " + b(".txt") + " ή σε " + b(".pdf"),
 "αν ειναι τυπου " + b("imdb") + " ( αρχιζει απο .. )",
 "αν αρχιζει απο " + b("rji_") + ", αν θα γινει " + b("rjs_") + ",<br> αν θα γινει " + b("mxu_"),
 b("gmt_") + " random movie",
 b("abab") + " ab ean code",
 b("ast_") + " calc ast bus",
 b("aud_") + " play audio html5",
 b("azt_") + " aztec code",
 b("bar_") + " barcode",
 b("blo_") + " blob",
 b("box_v set player inside<br> page or fancybox"),
 b("cam_") + " play earthcam",
 b("cav_") + " play html5 audio radio (right radio icon)",
 b("cov_") + " play movie using coverapi",
 b("dir_") + " view text files inside,<br> or nothing for περιεχομενα site <br> (site contents)",
 b("dmt_") + " / " + b("c12_") + " / " + b("pd4_"),
 b("ean_") + " barcode",
 b("eur1_") + " euronews",
 b("fan_") + " - κλήση showAlert με το variable <div>",
 b("fan_") + "message to popup for 20 sec",
 b("flv_") + " search flv web",
 b("gala") + " galaxias ean code",
 b("get_") + "search",
 b("help") + " this help",
 b("ifo_"),
 b("imdb") + " open imdb",
 b("info"),
 b("ipc_") + "play american camera",
 b("juk/") + " - δημιουργεί frame και<br> το ανοίγει σε νέο παράθυρο<br> εφόσον το rest δεν αρχίζει απο 'vjuk'",
 b("kasp") + "ersky re-enable info",
 b("lidl") + " qrcode lidl",
 b("mxu_") + "play m3u list with mxu.html",
 b("map_") + " google maps",
 b("masu") + " code128 & qrcode masutis",
 b("men_") + "center",
 b("men_") + "middle",
 b("men_") + "right",
 b("men_left") + " position menu",
 b("mkv_") + " searck mkv web",
 b("mod_") + " play mod",
 b("mov_") + " - αναζήτηση ταινίας<br> με βάση το rest",
 b("mp3_") + " search mp3 web",
 b("mp4_") + " search mp4 web",
 b("mul_") + " play movie using multiplayer",
 b("mut_") + " mus_ play movie using multiplayer",
 b("nem_") + " show blacklisted<br> right clicked of pin array",
 b("orca") + " barcodes help",
 b("ote_") + " reverse ote number search",
 b("own_") + " play to external window",
 b("pic_") + " display background pic",
 b("pin_") + "metatroph select σε πίνακα<br> ή κάντε δεξί κλικ σε SELECT",
 b("qrc_") + "qrcode 1",
 b("qrt_") + "qrcode 2",
 b("rss_") + "url_rss.feed",
 b("rad_") + "internet search radio title",
 b("rji_") + "play radio inline",
 b("rjs_") + "play radio player",
 b("rol_") + "horizontal roll marque",
 b("rnm_") + "random of tade.select",
 b("run_") + "random OLA",
 b("sat_") + " google satellite maps",
 b("set_") + "ID<br> sets brightness - contrast etc - for ID<br>example set_player1",
 b("sky_") + " play skyline cam",
 b("sss_") + "run javascript",
 b("str_") + " google street maps",
 b("tax_") + "taxinomisi enos select",
 b("tid_") + " convert imdb id to tmdb id",
 b("tmdb") + " open tmdb",
 b("tt") + "IMDB id plays movie using vidsrc.sh",
 b("/tv/tt") + "IMDB id plays tv series using vidsrc.sh",
 b("tub_") + " " + b("ytm_") + " youtube",
 b("tun_") + " play radio using tunein",
 b("turk") + " play turk radio",
 b("vid_") + " play video html5",
 b("vjs_") + "play multimedia",
 b("vsr_") + " play movie using vidsrc.sh",
 b("you_") + " play youtube",
 b("ytm_") + " youtube music",
 b("yts_") + "youtube search",
 "code.js",
 "data: menu.js menu_tv.js menu_mov.js menu_rad.js",
 "rologi",
 
 ];
 // Set number of columns
 var cols = 4;
 var rows = Math.ceil(commands.length / cols);
 let output = "";
 for (let i = 0; i < rows; i++){
 output += "<tr>";
 for (let j = 0; j < cols; j++){
 let index = i + j * rows;
 output += "<td style='border:1px solid #ccc; padding:4px; vertical-align: top;'>" +
 (commands[index] ? commands[index] : "") +
 "</td>";
 }
 output += "</tr>";
 }
 return output;
 })()
 }
 </table>
<br>
 </details>
 <details>
 <summary>Καλή διασκέδαση !</summary>
( Αν δεν καταλαβαίνετε κατι στις οδηγίες, ρωτήστε μας ).
</details>
</div>
</body>
</html>`;
}
{var theorcatext = `${keimstart}</head>
<body style="background:#ffffff;font-size: 12px;">
# Barcode Generation Commands<br>
<br>
Below are the prefixes you can use to generate different barcode types in your system:<br>
<br>
- qrcode ingognito: qrc_<br>
- ean13: ean_1234567890128<br>
- code128: c12_<br>
- aztec: azt_<br>
- qrcode: qrt_<br>
- pdf417: pd4_<br>
- datamatrix: dmt_<br>
<br>
---<br>
<br>
## Generating a QR Code for “IRIS PAYMENTS”<br>
<br>
1. Open the ZXing generator:<br>
 https://zxing.appspot.com/generator/<br>
2. Select TEXT as the format.<br>
3. In TEXT CONTENT, enter:<br>
 IRISTIN<AFM><br>
 (Replace <AFM> with the seller’s Greek VAT number.)<br>
4. For px, use: IRISTIN123456789<br>
5. Set BARCODE SIZE to MEDIUM.<br>
6. Choose ERROR CORRECTION: Q.<br>
7. Click GENERATE.<br>
<br>
----<br>
<br>
## Encoding Bonus Supermarket Cards (Demo)<br>
<br>
> The following examples use random numbers and do not correspond to real cards.<br>
> Replace the numeric sequences in both the data and text parameters with your own card number.<br>
<br>
- Generator site (no affiliation):<br>
 https://orcascan.com/tools/free-barcode-generator<br>
<br>
----<br>
<br>
### LIDL QR Code<br>
<br>
1. Go to https://zxing.appspot.com/generator/<br>
2. Select TEXT.<br>
3. TEXT CONTENT: the 17-digit card number followed by a zero (to make 18 digits).<br>
4. BARCODE SIZE: SMALL or MEDIUM.<br>
5. ERROR CORRECTION: L.<br>
6. Click GENERATE.<br>
<br>
Test link example:<br>
https://barcode.orcascan.com?type=qrcode&data=123000011223344550&fontsize=Fit&format=png&text=LIDL+12300001122334455<br>
<br>
----<br>
<br>
### Masoutis (Old Format)<br>
<br>
https://barcode.orcascan.com/?type=code128&data=111-111-111-0&fontsize=Fit&format=png&text=MasCard+111-111-111-0<br>
<br>
----<br>
<br>
### Masoutis (New QR Code)<br>
<br>
1. Open ZXing: https://zxing.appspot.com/generator/<br>
2. Choose TEXT.<br>
3. TEXT CONTENT: XE0000000000XZ<br>
 (Use your 10-digit card number without hyphens.)<br>
4. BARCODE SIZE: MEDIUM.<br>
5. ERROR CORRECTION: Q.<br>
6. Click GENERATE.<br>
<br>
----<br>
<br>
### Galaxias (EAN-13)<br>
<br>
https://barcode.orcascan.com?type=ean13&data=111122223333&fontsize=Fit&format=png&text=GALAXIAS+1111+2222+3333+2<br>
<br>
----<br>
<br>
### AB Plus (EAN-13)<br>
<br>
https://barcode.orcascan.com?type=ean13&data=012345678901&fontsize=Fit&format=png&text=ABPLUS+0+123456+789012<br>
<br>
----<br>
<br>
## General Guidelines<br>
<br>
- Lidl cards display only the first 17 digits; the 18th must be a zero.<br>
- Masoutis_old uses CODE128.<br>
- Galaxias and AB Plus use EAN-13. You may supply 12 digits (the 13th is auto-computed) or all 13 if you’ve pre-calculated it.<br>
- The text parameter comes entirely from you (not the generator) and can include spaces—just replace spaces with +.<br>
- Font size can be Fit (auto) or a pixel value (e.g., 36px).<br>
<br>
----<br>
<br>
## Supported Barcode Types on Orcascan<br>
<br>
- QR Code: ?type=qrcode<br>
- Aztec (alternative to QR): ?type=aztec<br>
- Data Matrix: ?type=datamatrix<br>
- Code 39: ?type=code39<br>
- UPC-A (11 or 12 digits): ?type=upca<br>
- UPC-E (7 or 8 digits): ?type=upce<br>
- EAN-13 (12 or 13 digits): ?type=ean13<br>
- EAN-8 (7 or 8 digits): ?type=ean8<br>
- ITF (Interleaved 2 of 5, numbers only): ?type=itf<br>
- Code 128: ?type=code128<br>
- PDF417: ?type=pdf417<br></body></html>
`;
} 
function zte(){
	var html = keimstart + '</head><body><br>' + 'KSEKLEIDWMA ZTE ROUTERS:<br>' + '<hr>' + 'katebazoume: https://www.python.org/downloads/<br>' + 'kai egka8istoume sto fakelo: c:\python<br>' + '( tsekarismena gia olous tous xrhstes kai add path kai customize epilogh fakelou )<br>' + 'bgainoume sto dos kai dinoume cd \python<br>' + 'pip install pycryptodomex<br>' + 'kai to egka8ista automata<br>' + '<hr>' + 'PAME STO<br>' + 'https://github.com/mkst/zte-config-utility<br>' + '<> Code download zip<br>' + '-- kseziparoume ta entos8ia tou fakelou: zte-config-utility-master, mesa ston fakelo<br>' + 'c:\python<br>' + '( dhladh mesa sto fakelo c:\python 8a blepete fakelo examples klp )<br>' + '--mpainoume sto router mas ( ws aplos admin )kai swzoume to USER CONFIG<br>' + '( dhladh synh8ws: config.bin )<br>' + 'kai to bazoume meta, mesa sto fakelo c:\python\examples<br>' + 'bgainoume sto dos kai dinoume:<br>' + 'cd\python\examples<br>' + 'C:\PYTHON\examples>python decode.py config.bin config.xml<br>' + '--<br>' + 'ftiaxnei ena config.xml<br>' + 'to opoio einai txt<br>' + 'to anoigoume me editor ( eite notepad sthn anagkh )<br>' + 'kai mesa ekei mporoume na broume me anazhthsh:<br>' + 'root<br>' + 'pass<br>' + '--<br>' + 'to thlefwno mas<br>' + '--<br>' + 'to voip pass<br>' + '--<br>' + 'ta wifi<br>' + '<hr>' + 'TELEIWNONTAS - APEGKA8ISTOUME APO PINAKA ELEGXOU TO PYTHON.' + '</body></html>';
	var newWindow = window.open("", "Test");
	newWindow.document.open();
	newWindow.document.write(html);
	newWindow.document.close();
}
function magicsquare() {
 const html = `<!DOCTYPE HTML>
<html lang="el">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
 <title>Μαγικό Τετράγωνο 3x3 ~ 21x21</title>
 <style>
 body {
 font-family: Arial, sans-serif;
 }
 table {
 border-collapse: collapse;
 margin-top: 10px;
 }
 td {
 border: 1px solid #555;
 width: 32px;
 height: 32px;
 text-align: center;
 font-size: 1.2vw;
 }
 select, button {
 font-size: 1rem;
 padding: 5px;
 }
 </style>
</head>
<body>
 <h2>\u{1F512} Επιλέξτε μέγεθος μαγικού τετραγώνου:</h2>
 <select id="sizeSelector">
 <option value="3">3\u{00D7}3</option>
 <option value="5">\u{00D7}5</option>
 <option value="7">7\u{00D7}7</option>
 <option value="9">9\u{00D7}9</option>
 <option value="11">11\u{00D7}11</option>
 <option value="13">13\u{00D7}13</option>
 <option value="15">15\u{00D7}15</option>
 <option value="17">17\u{00D7}17</option>
 <option value="19">19\u{00D7}19</option>
 <option value="21">21\u{00D7}21</option>
 </select>
 <button onclick="generateSquare()">\u{1F3B2} Δημιουργία</button>
 <div id="result"></div>
 <br> 
 <button id="saveProg">SaveProg</button>
 <script>
 function createMagicSquare(n) {
 const square = Array.from({ length: n }, () => Array(n).fill(0));
 let i = 0, j = Math.floor(n / 2);
 for (let num = 1; num <= n * n; num++) {
 square[i][j] = num;
 let newI = (i - 1 + n) % n;
 let newJ = (j - 1 + n) % n;
 if (square[newI][newJ] !== 0) {
 i = (i + 1) % n;
 } else {
 i = newI;
 j = newJ;
 }
 }
 return square;
 }
 function generateSquare() {
 const size = parseInt(document.getElementById("sizeSelector").value);
 const square = createMagicSquare(size);
 let html = "<h3>\u{2728} Μαγικό Τετράγωνο " + size + "\u{00D7}" + size + "</h3><table>";
 square.forEach(row => {
 html += "<tr>";
 row.forEach(cell => {
 html += "<td>" + cell + "</td>";
 });
 html += "</tr>";
 });
 html += "</table>";
 document.getElementById("result").innerHTML = html;
 }
 const saveProg = document.getElementById('saveProg');
 saveProg.addEventListener('click', () => {
 var htmlContent = document.documentElement.outerHTML;
 var blob = new Blob([htmlContent], {type: "text/html"});
 var a = document.createElement("a");
 a.href = URL.createObjectURL(blob);
 a.download = prompt("Save as:","MagicSquare.html"); if(a.download !== 'null'){
 document.body.appendChild(a);
 a.click();
 setTimeout("document.body.removeChild(a)",5000); }else{alert('Download Aborted')}
 }); 
 <\/script>
</body>
</html>
 `;
 const win = window.open('about:blank', '_blank');
 win.document.open();
 win.document.write(html);
 win.document.close();
}
function sudoku1() {
 const html = `<!DOCTYPE HTML>
<html lang="el">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
 <title>Sudoku Solver</title>
 <style>
 body {
 font-family: Arial, sans-serif;
 padding: 5px;
 }
 #sudoku {
 border-collapse: collapse;
 }
 #sudoku td {
 width: 30px;
 height: 30px;
 border: 1px solid #999;
 padding: 0;
 box-sizing: border-box;
 text-align: center;
 vertical-align: middle;
 }
 #sudoku td:nth-child(3n) { border-right: 2px solid #333; }
 #sudoku td:nth-child(1) { border-left: 2px solid #333; }
 #sudoku tr:nth-child(3n) td { border-bottom:2px solid #333; }
 #sudoku tr:nth-child(1) td { border-top: 2px solid #333; }
 .cell-input {
 display: block;
 width: 100%;
 height: 100%;
 border: none;
 background: transparent;
 box-sizing: border-box;
 font-size: 1.2rem;
 line-height: 30px;
 text-align: center;
 outline: none;
 }
 .cell-input.invalid {
 background-color: #fdd;
 }
 button {
 padding: 5px 15px;
 font-size: 1rem;
 margin: 6px;
 cursor: pointer;
 }
 </style>
</head>
<body>
 <h4>Sudoku Solver 9x9</h4>
 <table id="sudoku"></table>
 <div>
 <button id="solveBtn">Solve</button>
 <button id="resetBtn">UnSolve</button>
 <button id="clearBtn">New</button>
 <br> 
 <button id="saveProg">SaveProg</button>
 </div>
 <script>
 document.addEventListener('DOMContentLoaded', () => {
 const table = document.getElementById('sudoku');
 const solveBtn = document.getElementById('solveBtn');
 const resetBtn = document.getElementById('resetBtn');
 const clearBtn = document.getElementById('clearBtn');
 const saveProg = document.getElementById('saveProg');
 let originalGrid = null;
 initGrid(emptyGrid(), false);
 saveProg.addEventListener('click', () => {
 var htmlContent = document.documentElement.outerHTML;
 var blob = new Blob([htmlContent], {type: "text/html"});
 var a = document.createElement("a");
 a.href = URL.createObjectURL(blob);
 a.download = prompt("Save as:","sudoku_9x9.html"); if(a.download !== 'null'){
 document.body.appendChild(a);
 a.click();
 setTimeout("document.body.removeChild(a)",5000); }else{alert('Download Aborted')}
 });
 solveBtn.addEventListener('click', () => {
 const grid = readGrid();
 originalGrid = grid.map(r => [...r]);
 const solution = grid.map(r => [...r]);
 if (solve(solution)) {
 initGrid(solution, true);
 } else {
 alert('No solution found.');
 }
 });
 resetBtn.addEventListener('click', () => {
 if (originalGrid) initGrid(originalGrid, false);
 });
 clearBtn.addEventListener('click', () => {
 originalGrid = null;
 initGrid(emptyGrid(), false);
 });
 function emptyGrid() {
 return Array.from({ length: 9 }, () => Array(9).fill(0));
 }
 function initGrid(data, readOnly) {
 table.innerHTML = '';
 for (let r = 0; r < 9; r++) {
 const tr = document.createElement('tr');
 for (let c = 0; c < 9; c++) {
 const td = document.createElement('td');
 const val = data[r][c] || '';
 if (readOnly) {
 td.textContent = val;
 } else {
 const input = document.createElement('input');
 input.type = 'text';
 input.maxLength = 1;
 input.className = 'cell-input';
 input.value = val;
 // allow only 1–9, backspace, delete
 input.addEventListener('keydown', e => {
 if (!/[1-9]/.test(e.key) &&
 e.key !== 'Backspace' &&
 e.key !== 'Delete') {
 e.preventDefault();
 }
 });
 // validate on every change
 input.addEventListener('input', validateGrid);
 td.appendChild(input);
 }
 tr.appendChild(td);
 }
 table.appendChild(tr);
 }
 }
 function readGrid() {
 const g = emptyGrid();
 table.querySelectorAll('.cell-input').forEach((inp, i) => {
 const row = Math.floor(i / 9);
 const col = i % 9;
 const v = parseInt(inp.value, 10);
 if (v >= 1 && v <= 9) g[row][col] = v;
 });
 return g;
 }
 function validateGrid() {
 // clear previous highlights
 document.querySelectorAll('.cell-input').forEach(i => i.classList.remove('invalid'));
 // collect filled cells
 const entries = [];
 table.querySelectorAll('.cell-input').forEach((inp, i) => {
 const v = parseInt(inp.value, 10);
 if (v >= 1 && v <= 9) {
 entries.push({
 row: Math.floor(i/9),
 col: i%9,
 block: 3*Math.floor(Math.floor(i/9)/3) + Math.floor((i%9)/3),
 val: v,
 input: inp
 });
 }
 });
 // group and flag duplicates in rows, cols, blocks
 ['row','col','block'].forEach(dim => {
 const map = {};
 entries.forEach(e => {
 const key = e[dim] + '-' + e.val;
 map[key] = map[key]||[];
 map[key].push(e.input);
 });
 Object.values(map).forEach(list => {
 if (list.length > 1) list.forEach(inp => inp.classList.add('invalid'));
 });
 });
 }
 function solve(g) {
 for (let r = 0; r < 9; r++) {
 for (let c = 0; c < 9; c++) {
 if (g[r][c] === 0) {
 for (let n = 1; n <= 9; n++) {
 if (isValid(g, r, c, n)) {
 g[r][c] = n;
 if (solve(g)) return true;
 g[r][c] = 0;
 }
 }
 return false;
 }
 }
 }
 return true;
 }
 function isValid(g, r, c, n) {
 for (let i = 0; i < 9; i++) {
 if (g[r][i] === n || g[i][c] === n) return false;
 }
 const br = 3 * Math.floor(r/3);
 const bc = 3 * Math.floor(c/3);
 for (let dr = 0; dr < 3; dr++) {
 for (let dc = 0; dc < 3; dc++) {
 if (g[br+dr][bc+dc] === n) return false;
 }
 }
 return true;
 }
 });
 <\/script>
</body>
</html>
 `;
 const win = window.open('about:blank', '_blank');
 win.document.open();
 win.document.write(html);
 win.document.close(); 
}
function xartopolemos() {
  // Δημιουργία CSS style element
  const style = document.createElement('style');
  style.textContent = `
    .confetti {
      position: absolute;
      bottom: 0;
      width: 10px;
      height: 10px;
      border-radius: 2px;
      opacity: 1;
      z-index: 9999;
      transform-origin: center;
      will-change: transform, opacity, left, top;
    }
    @keyframes upThenDown {
      0% {
        transform: translateY(0) translateX(0) rotate(0deg);
        opacity: 1;
      }
      45% {
        transform: translateY(-75vh) translateX(var(--x-offset)) rotate(var(--rotate1));
        opacity: 1;
      }
      50% {
        transform: translateY(-78vh) translateX(calc(var(--x-offset) * 0.8)) rotate(var(--rotate2));
        opacity: 1;
      }
      100% {
        transform: translateY(100vh) translateX(var(--x-offset-fall)) rotate(var(--rotateEnd));
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
  const colors = ['#f94144', '#f3722c', '#f9c74f', '#90be6d', '#43aa8b', '#577590'];
  const count = 120;
  const confettiElements = [];
  for (let i = 0; i < count; i++) {
    const confetti = document.createElement('div');
    confetti.classList.add('confetti');
    const left = Math.random() * window.innerWidth;
    confetti.style.left = `${left}px`;
    const size = 6 + Math.random() * 12;
    confetti.style.width = `${size}px`;
    confetti.style.height = `${size * (0.6 + Math.random() * 0.8)}px`;
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    const rotate1 = `${(Math.random() * 360 - 180).toFixed(0)}deg`;
    const rotate2 = `${(Math.random() * 360 - 180).toFixed(0)}deg`;
    const rotateEnd = `${(Math.random() * 720 - 360).toFixed(0)}deg`;
    const xOffset = `${(Math.random() * 120 - 60).toFixed(0)}px`;
    const xOffsetFall = `${(Math.random() * 300 - 150).toFixed(0)}px`;
    confetti.style.setProperty('--rotate1', rotate1);
    confetti.style.setProperty('--rotate2', rotate2);
    confetti.style.setProperty('--rotateEnd', rotateEnd);
    confetti.style.setProperty('--x-offset', xOffset);
    confetti.style.setProperty('--x-offset-fall', xOffsetFall);
    const totalDuration = (2.4 + Math.random() * 1.6).toFixed(2);
    const delay = (Math.random() * 0.8).toFixed(2);
    confetti.style.animation = `upThenDown ${totalDuration}s cubic-bezier(.2,.8,.2,1) ${delay}s forwards`;
    document.body.appendChild(confetti);
    confettiElements.push(confetti);
  }
  // Αφαίρεση όλων των στοιχείων και του style μετά την animation
  const maxDuration = 5.2 * 1000; // μέγιστη διάρκεια + buffer
  setTimeout(() => {
    confettiElements.forEach(el => el.remove());
    style.remove();
  }, maxDuration);
}
/* --- telos efarmogwn --- */ 
 
 
/**  playing random from gamato site movie 
 * Call gmt() to open the modal empty, or gmt(1234) to prefill with 1234.
 * The function creates all DOM, styles and behavior at runtime and cleans up after close.
 * It contains everything inside the function scope and returns a control object.
 */
function gmt(predefinednumber) {
  const MIN = 103, MAX = 10093;

  function buildStyles() {
    const css = `
      .gmt-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:2147483647}
      .gmt-card{width:340px;max-width:92vw;background:#fff;color:#111;border-radius:10px;padding:14px;box-shadow:0 10px 30px rgba(0,0,0,.45);font-family:system-ui,Arial,sans-serif;position:relative}
      .gmt-row{display:flex;gap:8px;align-items:center}
      .gmt-label{display:block;margin-bottom:8px;font-weight:700;font-size:14px}
      .gmt-input{flex:1;padding:8px 10px;border:1px solid #d0d7df;border-radius:8px;font-size:14px;box-sizing:border-box}
      .gmt-btn{padding:8px 10px;border-radius:8px;border:0;cursor:pointer;font-weight:700}
      .gmt-ghost{background:#eef3ff;color:#0b69ff}
      .gmt-primary{background:#0b69ff;color:#fff}
      .gmt-close{position:absolute;right:12px;top:10px;background:transparent;border:0;font-size:18px;cursor:pointer;color:#666}
      .gmt-error{color:#b00020;margin-top:8px;font-weight:700;font-size:13px;display:none}
      .gmt-footer{display:flex;justify-content:space-between;align-items:center;margin-top:10px}
    `;
    const style = document.createElement('style');
    style.setAttribute('data-gmt-style', 'true');
    style.textContent = css;
    document.head.appendChild(style);
    return style;
  }

  function createModal(initialNumber) {
    // overlay
    const overlay = document.createElement('div');
    overlay.className = 'gmt-overlay';
    overlay.tabIndex = -1;

    // card
    const card = document.createElement('div');
    card.className = 'gmt-card';
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');

    // close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'gmt-close';
    closeBtn.type = 'button';
    closeBtn.innerHTML = '✕';
    closeBtn.title = 'Close';

    // label
    const label = document.createElement('div');
    label.className = 'gmt-label';
    label.textContent = `Enter a number ${MIN}–${MAX}`;

    // row with input and buttons
    const row = document.createElement('div');
    row.className = 'gmt-row';

    const input = document.createElement('input');
    input.className = 'gmt-input';
    input.type = 'number';
    input.min = MIN;
    input.max = MAX;
    input.placeholder = String(MIN);
    input.inputMode = 'numeric';
    input.autocomplete = 'off';

    const rndBtn = document.createElement('button');
    rndBtn.className = 'gmt-btn gmt-ghost';
    rndBtn.type = 'button';
    rndBtn.textContent = 'Random';

    const runBtn = document.createElement('button');
    runBtn.className = 'gmt-btn gmt-primary';
    runBtn.type = 'button';
    runBtn.textContent = 'Run';

    const err = document.createElement('div');
    err.className = 'gmt-error';

    // assemble
    row.appendChild(input);
    row.appendChild(rndBtn);
    row.appendChild(runBtn);
    card.appendChild(closeBtn);
    card.appendChild(label);
    card.appendChild(row);
    card.appendChild(err);
    overlay.appendChild(card);
    document.body.appendChild(overlay);

    // prefill
    if (initialNumber !== undefined && initialNumber !== null && initialNumber !== '') {
      input.value = initialNumber;
    } else {
      input.value = MIN;
    }

    // helpers
    function showError(text) {
      err.style.display = 'block';
      err.textContent = text;
    }
    function clearError() {
      err.style.display = 'none';
      err.textContent = '';
    }
    function makeRandom() {
      const r = Math.floor(Math.random() * (MAX - MIN + 1)) + MIN;
      input.value = r;
      clearError();
      return r;
    }
    function runNumber(n) {
      const num = Number(n);
      if (!Number.isInteger(num) || num < MIN || num > MAX) {
        showError('Please enter an integer between ' + MIN + ' and ' + MAX + '.');
        return false;
      }
      clearError();
      const url = 'http://gmtcloud.best/1-' + encodeURIComponent(num) + '/';
      window.open(url, '_blank');
      closeModal();
      return true;
    }

    // onKeyDown needs to be a stable reference so removeEventListener works
    function onKeyDown(e) {
      if (e.key === 'Escape') closeModal();
      if (e.key === 'Enter' && document.activeElement === input) {
        e.preventDefault();
        runNumber(input.value);
      }
    }

    function closeModal() {
      // remove overlay
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
      // remove style only if no other gmt-overlay exists
      const anyOverlay = document.querySelector('.gmt-overlay');
      if (!anyOverlay) {
        const style = document.querySelector('style[data-gmt-style]');
        if (style && style.parentNode) style.parentNode.removeChild(style);
      }
      document.removeEventListener('keydown', onKeyDown);
    }

    // events
    rndBtn.addEventListener('click', () => {
      const r = makeRandom();
      // immediate run on random (same behavior as original)
      runNumber(r);
    });
    runBtn.addEventListener('click', () => runNumber(input.value));
    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', (ev) => {
      if (ev.target === overlay) closeModal();
    });
    document.addEventListener('keydown', onKeyDown);

    // focus input
    setTimeout(() => input.focus(), 40);

    // return control object
    return {
      overlay,
      input,
      run: () => runNumber(input.value),
      random: makeRandom,
      close: closeModal
    };
  }

  // ensure styles exist only once
  if (!document.querySelector('style[data-gmt-style]')) buildStyles();
  // create and return the modal control
  return createModal(predefinednumber);
}
 
/* ------mouse coordinates--- */ 
function mm() {
 // create full-screen overlay
 const overlay = document.createElement('div');
 overlay.style.cssText = `
 position: fixed;
 top: 0; left: 0;
 width: 100%; height: 100%;
 background: rgba(0,0,0,0.1);
 cursor: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16'><rect x='6' y='6' width='4' height='4' fill='none' stroke='yellow' stroke-width='1'/></svg>") 8 8, auto;
 z-index: 100100;
 `;
 // create the coordinate display
 const info = document.createElement('div');
 info.style.cssText = `
 position: absolute;
 top: 3px; left: 250px;width:100px;
 padding: 3px 6px;
 background: #fff;
 border-radius: 4px;
 font: 14px sans-serif;
 color: #333;
 `;
 info.textContent = 'X: 0 Y: 0';
 overlay.appendChild(info);
 document.body.appendChild(overlay);
 // update coords
 function onMouseMove(e) {
 info.textContent = `X: ${e.clientX} Y: ${e.clientY}`;
 }
 // cleanup listeners & DOM
 function cleanup() {
 overlay.removeEventListener('mousemove', onMouseMove);
 overlay.removeEventListener('click', cleanup);
 document.removeEventListener('keydown', onKeyDown);
 document.body.removeChild(overlay);
 }
 // exit on Esc
 function onKeyDown(e) {
 if (e.key === 'Escape') cleanup();
 }
 overlay.addEventListener('mousemove', onMouseMove);
 overlay.addEventListener('click', cleanup);
 document.addEventListener('keydown', onKeyDown);
}



 loadme('menu.js').then(()=>{
 // any follow-up code
// setTimeout(function(){xartopolemos()},3000);
// setTimeout(function(){xartopolemos()},6000);
 
 });

 

/* ---- hotkeys ------ 
πχ alt-d τρεχει το function m3ublob1 ΔΗΛΑΔΗ DROP BOX
*/
if (!isMobile) {
 // Map physical keys (KeyboardEvent.code) to handlers
 const shortcutsByCode = {
 KeyD: m3ublob1,
 KeyL: loadmenu,
 KeyK: () => loadme('menu.js'),
 KeyR: () => loadme('menu_rad.js'),
 KeyT: () => loadme('menu_tv.js'),
 KeyW: () => loadme('menu_mov.js'),
 KeyO: () => pin(),
 KeyE: epilogi,
 KeyZ: xartopolemos,
 KeyX: () => cal2('myprog.php?katalogos'),
 KeyS: () => $('#stbutton').click(),
 KeyP: () => $('#plbutton').click(),
 KeyA: () => $('#radiobutton').click(),
 KeyM: () => !($('#menu').is(':animated'))&&$('#menu').stop(true,true).fadeToggle(500),
 KeyC: () => $('#URLink').val(''),
 KeyG: () => cal2('get_'+$('#URLink').val()),
 KeyH: () => cal2('ifo_'),
 KeyB: fondo,
 KeyF: () => cal2('set_'),
 };
 window.addEventListener('keydown', (e) => {
// Trigger only on Alt + key (no Ctrl, Meta (cmd on mac), or Shift)
if (e.repeat || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
 // Look up by physical key code
 const handler = shortcutsByCode[e.code];
 if (!handler) return;
 e.preventDefault();
 handler();
 });
}else{loadme('menu.js')}
/* ----- end hotkeys ----- */ 
//rologi();

/* --- remove placeholder of input --- */
// setTimeout(function () { document.getElementById("URLink").placeholder = ""; fondo(); }, 30000); 
 
// cal2('aud_https://media.vocaroo.com/mp3/1mviBtkbRGJd');

// !($('#menu').is(':animated'))&&$('#menu').stop(true,true).fadeToggle(500);
